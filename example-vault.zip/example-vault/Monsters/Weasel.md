---
Type: Beast
CR: 0
Size: Tiny
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Weasel
size: Tiny
type: Beast
alignment: Unaligned
ac: 13
hp: 1 (1d4 - 1)
hit_dice: 1d4 - 1
speed: 30 ft., Climb 30 ft.
stats: [3, 16, 8, 2, 12, 3]
skillsaves:
  - Acrobatics: +5
  - Perception: +3
  - Stealth: +5
senses: Darkvision 60 ft.; Passive Perception 13
languages: None
cr: 0
actions:
  - name: "Bite"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 1 Piercing damage."
```

#Monster
