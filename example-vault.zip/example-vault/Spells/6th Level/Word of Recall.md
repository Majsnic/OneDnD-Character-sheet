---
Spell level: 6
School type: Conjuration
Casting Time: Action
Components:
  - Verbal
Concentration: false
Duration: Instantaneous
Range / Area: 5 feet
Attack / Save: None
Damage / Effect: Utility
Upscale: 
category: 6th level
---
_Level 6 Conjuration_

- **Casting time:** Action
- **Range:** 5 feet
- **Components:** V
- **Duration:** Instantaneous
- **Attack/Save**: None
- **Damage/Effect**: Utility

You and up to five willing creatures within 5 feet of you instantly teleport to a previously designated sanctuary. You and any creatures that teleport with you appear in the nearest unoccupied space to the spot you designated when you prepared your sanctuary (see below). If you cast this spell without first preparing a sanctuary, the spell has no effect. You must designate a location, such as a temple, as a sanctuary by casting this spell there.

#Spell
