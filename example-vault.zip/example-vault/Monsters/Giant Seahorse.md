---
Type: Beast
CR: 1/2
Size: Large
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Giant Seahorse
size: Large
type: Beast
alignment: Unaligned
ac: 14
hp: 16 (3d10)
hit_dice: 3d10
speed: 5 ft., Swim 40 ft.
stats: [15, 12, 11, 2, 12, 5]
senses: Passive Perception 11
languages: None
cr: 1/2
traits:
  - name: "Water Breathing"
    desc: "The seahorse can breathe only underwater."
actions:
  - name: "Ram"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 9 (2d6 + 2) Bludgeoning damage, or 11 (2d8 + 2) Bludgeoning damage if the seahorse moved 20+ feet straight toward the target immediately before the hit."
bonusactions:
  - name: "Bubble Dash"
    desc: "While underwater, the seahorse moves up to half its Swim Speed without provoking Opportunity Attacks."
```

#Monster
