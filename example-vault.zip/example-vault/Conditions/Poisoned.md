---
tags:
  - Condition
source: SRD 5.2.1
---

# Poisoned

You have disadvantage on attack rolls and ability checks.

*Paraphrased mechanical summary, written from general knowledge of the SRD rules — treat it as a helpful draft, not a verbatim rules quote.*

#Condition
