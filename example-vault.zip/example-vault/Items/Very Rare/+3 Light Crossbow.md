---
Rarity: Very Rare
type: object
tags:
  - Item
  - item/very-rare
  - item/weapon
item_category: Weapon
item_base: "Light Crossbow"
weapon_category: "Simple Ranged"
damage_dice: "1d8"
damage_type: Piercing
weapon_properties: [Ammunition, Loading, Two-Handed]
range_normal: 80
range_long: 320
weapon_mastery: Slow
requires_attunement: false
attunement_note: ""
attack_bonus: 3
damage_bonus: 3
---


###### +3 Light Crossbow
_Weapon (light crossbow), very rare_<span class="sub2">:FasWandMagicSparkles: Magic Item</span>
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>You have a +3 bonus to attack and damage rolls made with this magic weapon.
>
>**1d8+3 Piercing damage.** Range 80/320 ft. Properties: Loading, Two-Handed.
>
>- **Ammunition.** You can use a weapon that has the Ammunition property to make a ranged attack only if you have ammunition to fire from it.
>- **Loading.** You can fire only one piece of ammunition from this weapon when you use an action, Bonus Action, or Reaction to fire it, regardless of the number of attacks you can normally make.
>- **Two-Handed.** You must use two hands to attack with this weapon.
>
>**_Slow (Mastery)._** If you hit a creature with this weapon and deal damage to it, you can reduce the creature's Speed by 10 feet until the start of your next turn. This property doesn't work against a creature that has a Speed of 0.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
