---
type: object
tags:
  - Item
  - item/common
  - item/weapon
item_category: Weapon
weapon_category: "Martial Melee"
damage_dice: "1d10"
damage_type: Slashing
weapon_properties: [Heavy, Reach, Two-Handed]
weapon_mastery: Graze
attack_bonus: 0
damage_bonus: 0
cost: "20 GP"
weight_lb: 6
---


###### Glaive
_Martial Melee Weapon_
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>**1d10 Slashing damage.** Properties: Heavy, Reach, Two-Handed. Cost 20 GP, weight 6 lb.
>
>- **Heavy.** Small creatures have Disadvantage on attack rolls with this weapon.
>- **Reach.** This weapon adds 5 feet to your reach when you attack with it.
>- **Two-Handed.** You must use two hands to attack with this weapon.
>
>**_Graze (Mastery)._** If your attack roll with this weapon misses a creature, you can deal damage to that creature equal to the ability modifier you used to make the attack roll (once per turn).
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
