---
Type: Beast
CR: 1/4
Size: Large
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Elk
size: Large
type: Beast
alignment: Unaligned
ac: 10
hp: 11 (2d10)
hit_dice: 2d10
speed: 50 ft.
stats: [16, 10, 11, 2, 10, 6]
skillsaves:
  - Perception: +2
senses: Darkvision 60 ft.; Passive Perception 12
languages: None
cr: 1/4
actions:
  - name: "Ram"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 6 (1d6 + 3) Bludgeoning damage. If the target is a Large or smaller creature and the elk moved 20+ feet straight toward it immediately before the hit, the target takes an extra 3 (1d6) Bludgeoning damage and has the Prone condition."
```

#Monster
