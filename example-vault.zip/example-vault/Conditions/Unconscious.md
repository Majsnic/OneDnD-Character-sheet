---
tags:
  - Condition
source: SRD 5.2.1
---

# Unconscious

You are Incapacitated, can't move or speak, and are unaware of your surroundings. You drop whatever you're holding and fall Prone. You automatically fail Strength and Dexterity saving throws. Attack rolls against you have advantage, and any hit against you is a critical hit if the attacker is within 5 feet of you.

*Paraphrased mechanical summary, written from general knowledge of the SRD rules — treat it as a helpful draft, not a verbatim rules quote.*

#Condition
