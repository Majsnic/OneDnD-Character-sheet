---
tags:
  - Feat
source: SRD 5.2.1
---

# Great Weapon Fighting

**Type:** Fighting Style Feat
**Prerequisite:** A class feature that lets you choose a Fighting Style
**Repeatable:** No

When you roll a 1 or 2 on a damage die for an attack you make with a two-handed or versatile melee weapon, you can reroll the die. You must use the new roll, even if it's also a 1 or 2.

*Paraphrased mechanical summary, written from general knowledge of the SRD rules — treat it as a helpful draft, not a verbatim rules quote.*

#Feat
