---
tags:
  - Feat
source: SRD 5.2.1
---

# Boon of Truesight

**Type:** Epic Boon Feat
**Prerequisite:** Character level 19
**Repeatable:** No

You gain Truesight with a range of 120 feet.

*Paraphrased mechanical summary, written from general knowledge of the SRD rules — treat it as a helpful draft, not a verbatim rules quote.*

#Feat
