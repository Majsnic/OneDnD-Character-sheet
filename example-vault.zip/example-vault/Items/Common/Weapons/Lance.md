---
type: object
tags:
  - Item
  - item/common
  - item/weapon
item_category: Weapon
weapon_category: "Martial Melee"
damage_dice: "1d10"
damage_type: Piercing
weapon_properties: [Reach, Special]
weapon_mastery: Topple
attack_bonus: 0
damage_bonus: 0
cost: "10 GP"
weight_lb: 6
---


###### Lance
_Martial Melee Weapon_
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>**1d10 Piercing damage.** Properties: Reach, Special. Cost 10 GP, weight 6 lb.
>
>- **Reach.** This weapon adds 5 feet to your reach when you attack with it.
>- **Special.** This weapon has a special rule described in its own entry.
>
>**_Topple (Mastery)._** If you hit a creature with this weapon, you can force that creature to make a Constitution saving throw (DC 8 + your proficiency bonus + the ability modifier used for the attack). On a failed save, the creature is knocked Prone.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
