---
Spell level: 1
School type: Transmutation
Casting Time: Action
Components:
  - Verbal
  - Somatic
  - Material
Concentration: false
Duration: 1 hour
Range / Area: Touch
Attack / Save: None
Damage / Effect: Utility
Upscale: + 1 creature
category: 1st level
---
_Level 1 Transmutation_

- **Casting time:** Action
- **Range:** Touch
- **Components:** V, S, M
- **Duration:** 1 hour
- **Attack/Save**: None
- **Damage/Effect**: Utility

You touch a creature. The target’s Speed increases by 10 feet until the spell ends.

**_Using a Higher-Level Spell Slot._** You can target one additional creature for each spell slot level above 1.

#Spell
