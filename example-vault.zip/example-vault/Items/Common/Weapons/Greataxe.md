---
type: object
tags:
  - Item
  - item/common
  - item/weapon
item_category: Weapon
weapon_category: "Martial Melee"
damage_dice: "1d12"
damage_type: Slashing
weapon_properties: [Heavy, Two-Handed]
weapon_mastery: Cleave
attack_bonus: 0
damage_bonus: 0
cost: "30 GP"
weight_lb: 7
---


###### Greataxe
_Martial Melee Weapon_
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>**1d12 Slashing damage.** Properties: Heavy, Two-Handed. Cost 30 GP, weight 7 lb.
>
>- **Heavy.** Small creatures have Disadvantage on attack rolls with this weapon.
>- **Two-Handed.** You must use two hands to attack with this weapon.
>
>**_Cleave (Mastery)._** If you hit a creature with this weapon, you can make an attack with the same weapon against a second creature within 5 ft of the first that's also within your reach, using the same roll. On a hit, the second target takes the weapon's damage, but no ability modifier.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
