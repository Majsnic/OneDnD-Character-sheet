---
Type: Fey
CR: 3
Size: Medium
tags:
  - Monster
  - Fey
source: SRD 5.2.1
---

```statblock
name: Bugbear Stalker
size: Medium
type: Fey (Goblinoid)
alignment: Chaotic Evil
ac: 15
hp: 65 (10d8 + 20)
hit_dice: 10d8 + 20
speed: 30 ft.
stats: [17, 14, 14, 11, 12, 11]
saves:
  - Con: +4
  - Wis: +3
skillsaves:
  - Stealth: +6
  - Survival: +3
gear: Chain Shirt, Javelins (6), Morningstar
senses: Darkvision 60 ft.; Passive Perception 11
languages: Common, Goblin
cr: 3
traits:
  - name: "Abduct"
    desc: "The bugbear needn’t spend extra movement to move a creature it is grappling."
actions:
  - name: "Multiattack"
    desc: "The bugbear makes two Javelin or Morningstar attacks."
  - name: "Javelin"
    desc: "Melee or Ranged Attack Roll: +5, reach 10 ft. or range 30/120 ft. Hit: 13 (3d6 + 3) Piercing damage."
  - name: "Morningstar"
    desc: "Melee Attack Roll: +5 (with Advantage if the target is Grappled by the bugbear), reach 10 ft. Hit: 12 (2d8 + 3) Piercing damage."
bonusactions:
  - name: "Quick Grapple"
    desc: "Dexterity Saving Throw: DC 13, one Medium or smaller creature the bugbear can see within 10 feet. Failure: The target has the Grappled condition (escape DC 13)."
```

#Monster
