---
tags:
  - Sense
source: SRD 5.2.1
---

# Telepathy

Within a specified range, you can communicate telepathically with any creature that can understand at least one language, without needing to share a language with it. The other creature can't reply telepathically unless it also has telepathy.

*Paraphrased mechanical summary, written from general knowledge of the SRD rules — treat it as a helpful draft, not a verbatim rules quote.*

#Sense
