---
Type: Beast
CR: 1/2
Size: Large
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Giant Goat
size: Large
type: Beast
alignment: Unaligned
ac: 11
hp: 19 (3d10 + 3)
hit_dice: 3d10 + 3
speed: 40 ft., Climb 30 ft.
stats: [17, 13, 12, 3, 12, 6]
saves:
  - Str: +5
skillsaves:
  - Perception: +3
senses: Darkvision 60 ft.; Passive Perception 13
languages: None
cr: 1/2
actions:
  - name: "Ram"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 6 (1d6 + 3) Bludgeoning damage. If the target is a Large or smaller creature and the goat moved 20+ feet straight toward it immediately before the hit, the target takes an extra 5 (2d4) Bludgeoning damage and has the Prone condition."
```

#Monster
