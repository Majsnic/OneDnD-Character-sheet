---
Spell level: 1
School type: Conjuration
Casting Time: Action or Ritual
Components:
  - Verbal
  - Somatic
  - Material
Concentration: false
Duration: 1 hour
Range / Area: 60 feet
Attack / Save: None
Damage / Effect: Utility
Upscale: 
category: 1st level
---
_Level 1 Conjuration_

- **Casting time:** Action or Ritual
- **Range:** 60 feet
- **Components:** V, S, M
- **Duration:** 1 hour
- **Attack/Save**: None
- **Damage/Effect**: Utility

This spell creates an Invisible, mindless, shapeless, Medium force that performs simple tasks at your command until the spell ends. The servant springs into existence in an unoccupied space on the ground within range. It has AC 10, 1 Hit Point, and a Strength of 2, and it can’t attack. If it drops to 0 Hit Points, the spell ends. Once on each of your turns as a Bonus Action, you can mentally command the servant to move up to 15 feet and interact with an object. The servant can perform simple tasks that a human could do, such as fetching things, cleaning, mending, folding clothes, lighting fires, serving food, and pouring drinks. Once you give the command, the servant performs the task to the best of its ability until it completes the task, then waits for your next command. If you command the servant to perform a task that would move it more than 60 feet away from you, the spell ends.

#Spell
