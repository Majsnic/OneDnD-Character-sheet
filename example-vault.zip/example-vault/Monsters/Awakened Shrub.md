---
Type: Plant
CR: 0
Size: Small
tags:
  - Monster
  - Plant
source: SRD 5.2.1
---

```statblock
name: Awakened Shrub
size: Small
type: Plant
alignment: Neutral
ac: 9
hp: 10 (3d6)
hit_dice: 3d6
speed: 20 ft.
stats: [3, 8, 11, 10, 10, 6]
damage_vulnerabilities: Fire
damage_resistances: Piercing
senses: Passive Perception 10
languages: Common plus one other language
cr: 0
actions:
  - name: "Rake"
    desc: "Melee Attack Roll: +1, reach 5 ft. Hit: 1 Slashing damage."
```

#Monster
