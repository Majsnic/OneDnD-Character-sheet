---
tags:
  - Condition
source: SRD 5.2.1
---

# Petrified

You and any nonmagical objects you're wearing or carrying are turned to a solid substance such as stone. You are Incapacitated, can't move or speak, and are unaware of your surroundings. Attack rolls against you have advantage. You automatically fail Strength and Dexterity saving throws, have resistance to all damage, and are immune to poison and disease.

*Paraphrased mechanical summary, written from general knowledge of the SRD rules — treat it as a helpful draft, not a verbatim rules quote.*

#Condition
