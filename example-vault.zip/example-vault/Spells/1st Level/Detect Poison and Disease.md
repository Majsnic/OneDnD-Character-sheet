---
Spell level: 1
School type: Divination
Casting Time: Action or Ritual
Components:
  - Verbal
  - Somatic
  - Material
Concentration: true
Duration: 10 minutes
Range / Area: Self
Attack / Save: None
Damage / Effect: Utility
Upscale: 
category: 1st level
---
_Level 1 Divination_

- **Casting time:** Action or Ritual
- **Range:** Self
- **Components:** V, S, M
- **Duration:** 10 minutes
- **Attack/Save**: None
- **Damage/Effect**: Utility

For the duration, you sense the location of poisons, poisonous or venomous creatures, and magical contagions within 30 feet of yourself. You sense the kind of poison, creature, or contagion in each case. The spell is blocked by 1 foot of stone, dirt, or wood; 1 inch of metal; or a thin sheet of lead.

#Spell
