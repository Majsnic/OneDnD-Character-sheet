---
Spell level: 6
School type: Abjuration
Casting Time: Action
Components:
  - Verbal
  - Somatic
Concentration: false
Duration: Instantaneous
Range / Area: 60 feet
Attack / Save: None
Damage / Effect: Poisoned
Upscale: + 10 for each spell slot level above 6
category: 6th level
---
_Level 6 Abjuration_

- **Casting time:** Action
- **Range:** 60 feet
- **Components:** V, S
- **Duration:** Instantaneous
- **Attack/Save**: None
- **Damage/Effect**: Poisoned

Choose a creature that you can see within range. Positive energy washes through the target, restoring 70 Hit Points. This spell also ends the Blinded, Deafened, and Poisoned conditions on the target.

**_Using a Higher-Level Spell Slot._** The healing increases by 10 for each spell slot level above 6.

#Spell
