---
Spell level: 6
School type: Evocation
Casting Time: Action
Components:
  - Verbal
  - Somatic
Concentration: true
Duration: 10 minutes
Range / Area: 90 feet
Attack / Save: DEX Save
Damage / Effect: 6d10 Force
Upscale: 
category: 6th level
---
_Level 6 Evocation_

- **Casting time:** Action
- **Range:** 90 feet
- **Components:** V, S
- **Duration:** 10 minutes
- **Attack/Save**: DEX Save
- **Damage/Effect**: Force

You create a wall of whirling blades made of magical energy. The wall appears within range and lasts for the duration. You make a straight wall up to 100 feet long, 20 feet high, and 5 feet thick, or a ringed wall up to 60 feet in diameter, 20 feet high, and 5 feet thick. The wall provides Three-Quarters Cover, and its space is Difficult Terrain. Any creature in the wall’s space makes a Dexterity saving throw, taking 6d10 Force damage on a failed save or half as much damage on a successful one. A creature also makes that save if it enters the wall’s space or ends it turn there. A creature makes that save only once per turn.

#Spell
