---
Type: Dragon
CR: 8
Size: Large
tags:
  - Monster
  - Dragon
source: SRD 5.2.1
---

```statblock
name: Young Green Dragon
size: Large
type: Dragon (Chromatic)
alignment: Lawful Evil
ac: 18
hp: 136 (16d10 + 48)
hit_dice: 16d10 + 48
speed: 40 ft., Fly 80 ft., Swim 40 ft.
stats: [19, 12, 17, 16, 13, 15]
saves:
  - Dex: +4
  - Wis: +4
skillsaves:
  - Deception: +5
  - Perception: +7
  - Stealth: +4
damage_immunities: Poison
condition_immunities: Poisoned
senses: Blindsight 30 ft., Darkvision 120 ft.; Passive Perception 17
languages: Common, Draconic
cr: 8
traits:
  - name: "Amphibious"
    desc: "The dragon can breathe air and water."
actions:
  - name: "Multiattack"
    desc: "The dragon makes three Rend attacks."
  - name: "Rend"
    desc: "Melee Attack Roll: +7, reach 10 ft. Hit: 11 (2d6 + 4) Slashing damage plus 7 (2d6) Poison damage."
  - name: "Poison Breath (Recharge 5–6)"
    desc: "Constitution Saving Throw: DC 14, each creature in a 30-foot Cone. Failure: 42 (12d6) Poison damage. Success: Half damage."
```

#Monster
