---
tags:
  - Condition
source: SRD 5.2.1
---

# Invisible

You can't be seen without the aid of magic or a special sense, and for the purpose of hiding you're heavily obscured. Attack rolls against you have disadvantage, and your own attack rolls have advantage.

*Paraphrased mechanical summary, written from general knowledge of the SRD rules — treat it as a helpful draft, not a verbatim rules quote.*

#Condition
