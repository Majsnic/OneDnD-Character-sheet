---
Rarity: Very Rare
type: object
tags:
  - Item
  - item/very-rare
  - item/weapon
item_category: Weapon
item_base: "Javelin"
weapon_category: "Simple Melee"
damage_dice: "1d6"
damage_type: Piercing
weapon_properties: [Thrown]
range_normal: 30
range_long: 120
weapon_mastery: Slow
requires_attunement: false
attunement_note: ""
attack_bonus: 3
damage_bonus: 3
---


###### +3 Javelin
_Weapon (javelin), very rare_<span class="sub2">:FasWandMagicSparkles: Magic Item</span>
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>You have a +3 bonus to attack and damage rolls made with this magic weapon.
>
>**1d6+3 Piercing damage.** Range 30/120 ft.
>
>- **Thrown.** You can throw this weapon to make a ranged attack, using the same ability modifier for the attack and damage rolls that you use for a melee attack with the weapon.
>
>**_Slow (Mastery)._** If you hit a creature with this weapon and deal damage to it, you can reduce the creature's Speed by 10 feet until the start of your next turn. This property doesn't work against a creature that has a Speed of 0.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
