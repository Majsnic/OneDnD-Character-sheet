---
type: object
tags:
  - Item
  - item/common
  - item/gear
item_category: "Adventuring Gear"
cost: "25 GP"
weight_lb: 12
---


###### Climber's Kit
_Adventuring Gear_
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>This kit includes special pitons, boot tips, gloves, and a harness. As an action, you can anchor yourself; while anchored, you can't fall more than 25 feet from the point you anchored, and the kit gives you advantage on Strength (Athletics) checks made to climb. Cost 25 GP, weight 12 lb.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
