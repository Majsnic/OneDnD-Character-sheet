---
Type: Beast
CR: 8
Size: Huge
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Tyrannosaurus Rex
size: Huge
type: Beast (Dinosaur)
alignment: Unaligned
ac: 13
hp: 136 (13d12 + 52)
hit_dice: 13d12 + 52
speed: 50 ft.
stats: [25, 10, 19, 2, 12, 9]
saves:
  - Str: +10
  - Wis: +4
skillsaves:
  - Perception: +4
senses: Passive Perception 14
languages: None
cr: 8
actions:
  - name: "Multiattack"
    desc: "The tyrannosaurus makes one Bite attack and one Tail attack."
  - name: "Bite"
    desc: "Melee Attack Roll: +10, reach 10 ft. Hit: 33 (4d12 + 7) Piercing damage. If the target is a Large or smaller creature, it has the Grappled condition (escape DC 17). While Grappled, the target has the Restrained condition and can’t be targeted by the tyrannosaurus’s Tail."
  - name: "Tail"
    desc: "Melee Attack Roll: +10, reach 15 ft. Hit: 25 (4d8 + 7) Bludgeoning damage. If the target is a Huge or smaller creature, it has the Prone condition."
```

#Monster
