---
type: object
tags:
  - Item
  - item/common
  - item/weapon
item_category: Weapon
weapon_category: "Martial Melee"
damage_dice: "1d8"
damage_type: Piercing
weapon_properties: []
weapon_mastery: Sap
attack_bonus: 0
damage_bonus: 0
cost: "5 GP"
weight_lb: 2
---


###### War Pick
_Martial Melee Weapon_
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>**1d8 Piercing damage.** Cost 5 GP, weight 2 lb.
>
>**_Sap (Mastery)._** If you hit a creature with this weapon, that creature has Disadvantage on its next attack roll before the start of your next turn.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
