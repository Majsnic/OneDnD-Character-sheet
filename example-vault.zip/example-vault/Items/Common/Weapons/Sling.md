---
type: object
tags:
  - Item
  - item/common
  - item/weapon
item_category: Weapon
weapon_category: "Simple Ranged"
damage_dice: "1d4"
damage_type: Bludgeoning
weapon_properties: [Ammunition]
range_normal: 30
range_long: 120
attack_bonus: 0
damage_bonus: 0
cost: "1 GP"
weight_lb: 0
---


###### Sling
_Simple Ranged Weapon_
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>**1d4 Bludgeoning damage.** Range 30/120 ft. Cost 1 GP, weight 0 lb.
>
>- **Ammunition.** You can use a weapon that has the Ammunition property to make a ranged attack only if you have ammunition to fire from it.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
