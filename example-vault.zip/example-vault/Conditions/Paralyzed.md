---
tags:
  - Condition
source: SRD 5.2.1
---

# Paralyzed

You are Incapacitated and can't move or speak. You automatically fail Strength and Dexterity saving throws. Attack rolls against you have advantage, and any hit against you is a critical hit if the attacker is within 5 feet of you.

*Paraphrased mechanical summary, written from general knowledge of the SRD rules — treat it as a helpful draft, not a verbatim rules quote.*

#Condition
