---
Type: Celestial
CR: 16
Size: Large
tags:
  - Monster
  - Celestial
source: SRD 5.2.1
---

```statblock
name: Planetar
size: Large
type: Celestial (Angel)
alignment: Lawful Good
ac: 19
hp: 262 (21d10 + 147)
hit_dice: 21d10 + 147
speed: 40 ft., Fly 120 ft. (hover)
stats: [24, 20, 24, 19, 22, 25]
saves:
  - Str: +12
  - Con: +12
  - Wis: +11
  - Cha: +12
skillsaves:
  - Perception: +11
damage_resistances: Radiant
condition_immunities: Charmed, Exhaustion, Frightened
senses: Truesight 120 ft.; Passive Perception 21
languages: All; telepathy 120 ft.
cr: 16
traits:
  - name: "Divine Awareness"
    desc: "The planetar knows if it hears a lie."
  - name: "Exalted Restoration"
    desc: "If the planetar dies outside Mount Celestia, its body disappears, and it gains a new body instantly, reviving with all its Hit Points somewhere in Mount Celestia."
  - name: "Magic Resistance"
    desc: "The planetar has Advantage on saving throws against spells and other magical effects."
actions:
  - name: "Multiattack"
    desc: "The planetar makes three Radiant Sword attacks or uses Holy Burst twice."
  - name: "Radiant Sword"
    desc: "Melee Attack Roll: +12, reach 10 ft. Hit: 14 (2d6 + 7) Slashing damage plus 18 (4d8) Radiant damage."
  - name: "Holy Burst"
    desc: "Dexterity Saving Throw: DC 20, each enemy in a 20-foot-radius Sphere centered on a point the planetar can see within 120 feet. Failure: 24 (7d6) Radiant damage. Success: Half damage."
  - name: "Spellcasting"
    desc: "The planetar casts one of the following spells, requiring no Material components and using Charisma as spellcasting ability (spell save DC 20): At Will: Detect Evil and Good 1/Day Each: Commune, Control Weather, Dispel Evil and Good, Raise Dead"
bonusactions:
  - name: "Divine Aid (2/Day)"
    desc: "The planetar casts Cure Wounds, Invisibility, Lesser Restoration, or Remove Curse, using the same spellcasting ability as Spellcasting."
```

#Monster
