---
Type: Fiend
CR: 1
Size: Tiny
tags:
  - Monster
  - Fiend
source: SRD 5.2.1
---

```statblock
name: Imp
size: Tiny
type: Fiend (Devil)
alignment: Lawful Evil
ac: 13
hp: 21 (6d4 + 6)
hit_dice: 6d4 + 6
speed: 20 ft., Fly 40 ft.
stats: [6, 17, 13, 11, 12, 14]
skillsaves:
  - Deception: +4
  - Insight: +3
  - Stealth: +5
damage_resistances: Cold
damage_immunities: Fire, Poison
condition_immunities: Poisoned
senses: Darkvision 120 ft. (unimpeded by magical Darkness); Passive Perception 11
languages: Common, Infernal
cr: 1
traits:
  - name: "Magic Resistance"
    desc: "The imp has Advantage on saving throws against spells and other magical effects."
actions:
  - name: "Sting"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 6 (1d6 + 3) Piercing damage plus 7 (2d6) Poison damage."
  - name: "Invisibility"
    desc: "The imp casts Invisibility on itself, requiring no spell components and using Charisma as the spellcasting ability."
  - name: "Shape-Shift"
    desc: "The imp shape-shifts to resemble a rat (Speed 20 ft.), a raven (20 ft., Fly 60 ft.), or a spider (20 ft., Climb 20 ft.), or it returns to its true form. Its game statistics are the same in each form, except for its Speed. Any equipment it is wearing or carrying isn’t transformed."
```

#Monster
