---
Type: Beast
CR: 4
Size: Large
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Hippopotamus
size: Large
type: Beast
alignment: Unaligned
ac: 14
hp: 82 (11d10 + 22)
hit_dice: 11d10 + 22
speed: 30 ft., Swim 30 ft.
stats: [21, 7, 15, 2, 12, 4]
saves:
  - Str: +7
skillsaves:
  - Perception: +3
senses: Passive Perception 13
languages: None
cr: 4
traits:
  - name: "Hold Breath"
    desc: "The hippopotamus can hold its breath for 10 minutes."
actions:
  - name: "Multiattack"
    desc: "The hippopotamus makes two Bite attacks."
  - name: "Bite"
    desc: "Melee Attack Roll: +7, reach 5 ft. Hit: 16 (2d10 + 5) Piercing damage."
```

#Monster
