---
Type: Monstrosity
CR: 3
Size: Large
tags:
  - Monster
  - Monstrosity
source: SRD 5.2.1
---

```statblock
name: Owlbear
size: Large
type: Monstrosity
alignment: Unaligned
ac: 13
hp: 59 (7d10 + 21)
hit_dice: 7d10 + 21
speed: 40 ft., Climb 40 ft.
stats: [20, 12, 17, 3, 12, 7]
skillsaves:
  - Perception: +5
senses: Darkvision 60 ft.; Passive Perception 15
languages: None
cr: 3
actions:
  - name: "Multiattack"
    desc: "The owlbear makes two Rend attacks."
  - name: "Rend"
    desc: "Melee Attack Roll: +7, reach 5 ft. Hit: 14 (2d8 + 5) Slashing damage."
```

#Monster
