---
Type: Monstrosity
CR: 2
Size: Medium
tags:
  - Monster
  - Monstrosity
source: SRD 5.2.1
---

```statblock
name: Ettercap
size: Medium
type: Monstrosity
alignment: Neutral Evil
ac: 13
hp: 44 (8d8 + 8)
hit_dice: 8d8 + 8
speed: 30 ft., Climb 30 ft.
stats: [14, 15, 13, 7, 12, 8]
skillsaves:
  - Perception: +3
  - Stealth: +4
  - Survival: +3
senses: Darkvision 60 ft.; Passive Perception 13
languages: None
cr: 2
traits:
  - name: "Spider Climb"
    desc: "The ettercap can climb difficult surfaces, including along ceilings, without needing to make an ability check."
  - name: "Web Walker"
    desc: "The ettercap ignores movement restrictions caused by webs, and the ettercap knows the location of any other creature in contact with the same web."
actions:
  - name: "Multiattack"
    desc: "The ettercap makes one Bite attack and one Claw attack."
  - name: "Bite"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 5 (1d6 + 2) Piercing damage plus 2 (1d4) Poison damage, and the target has the Poisoned condition until the start of the ettercap’s next turn."
  - name: "Claw"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 7 (2d4 + 2) Slashing damage."
  - name: "Web Strand (Recharge 5–6)"
    desc: "Dexterity Saving Throw: DC 12, one Large or smaller creature the ettercap can see within 30 feet. Failure: The target has the Restrained condition until the web is destroyed (AC 10; HP 5; Vulnerability to Fire damage; Immunity to Bludgeoning, Poison, and Psychic damage)."
bonusactions:
  - name: "Reel"
    desc: "The ettercap pulls one creature within 30 feet of itself that is Restrained by its Web Strand up to 25 feet straight toward itself."
```

#Monster
