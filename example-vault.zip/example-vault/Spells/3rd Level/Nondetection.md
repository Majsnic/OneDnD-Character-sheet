---
Spell level: 3
School type: Abjuration
Casting Time: Action
Components:
  - Verbal
  - Somatic
  - Material
Concentration: false
Duration: 8 hours
Range / Area: Touch
Attack / Save: None
Damage / Effect: Utility
Upscale: 
category: 3rd level
---
_Level 3 Abjuration_

- **Casting time:** Action
- **Range:** Touch
- **Components:** V, S, M
- **Duration:** 8 hours
- **Attack/Save**: None
- **Damage/Effect**: Utility

For the duration, you hide a target that you touch from Divination spells. The target can be a willing creature, or it can be a place or an object no larger than 10 feet in any dimension. The target can’t be targeted by any Divination spell or perceived through magical scrying sensors.

#Spell
