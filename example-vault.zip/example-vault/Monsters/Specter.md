---
Type: Undead
CR: 1
Size: Medium
tags:
  - Monster
  - Undead
source: SRD 5.2.1
---

```statblock
name: Specter
size: Medium
type: Undead
alignment: Chaotic Evil
ac: 12
hp: 22 (5d8)
hit_dice: 5d8
speed: 30 ft., Fly 50 ft. (hover)
stats: [1, 14, 11, 10, 10, 11]
damage_resistances: Acid, Bludgeoning, Cold, Fire, Lightning, Piercing, Slashing, Thunder
damage_immunities: Necrotic, Poison
condition_immunities: Charmed, Exhaustion, Grappled, Paralyzed, Petrified, Poisoned, Prone, Restrained, Unconscious
senses: Darkvision 60 ft.; Passive Perception 10
languages: Understands Common plus one other language but can’t speak
cr: 1
traits:
  - name: "Incorporeal Movement"
    desc: "The specter can move through other creatures and objects as if they were Difficult Terrain. It takes 5 (1d10) Force damage if it ends its turn inside an object."
  - name: "Sunlight Sensitivity"
    desc: "While in sunlight, the specter has Disadvantage on ability checks and attack rolls."
actions:
  - name: "Life Drain"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 7 (2d6) Necrotic damage. If the target is a creature, its Hit Point maximum decreases by an amount equal to the damage taken."
```

#Monster
