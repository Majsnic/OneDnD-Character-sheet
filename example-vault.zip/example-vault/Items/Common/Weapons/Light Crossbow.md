---
type: object
tags:
  - Item
  - item/common
  - item/weapon
item_category: Weapon
weapon_category: "Simple Ranged"
damage_dice: "1d8"
damage_type: Piercing
weapon_properties: [Ammunition, Loading, Two-Handed]
range_normal: 80
range_long: 320
attack_bonus: 0
damage_bonus: 0
cost: "25 GP"
weight_lb: 5
---


###### Light Crossbow
_Simple Ranged Weapon_
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>**1d8 Piercing damage.** Range 80/320 ft. Properties: Loading, Two-Handed. Cost 25 GP, weight 5 lb.
>
>- **Ammunition.** You can use a weapon that has the Ammunition property to make a ranged attack only if you have ammunition to fire from it.
>- **Loading.** You can fire only one piece of ammunition from this weapon when you use an action, Bonus Action, or Reaction to fire it, regardless of the number of attacks you can normally make.
>- **Two-Handed.** You must use two hands to attack with this weapon.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
