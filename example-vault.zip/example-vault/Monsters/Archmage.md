---
Type: Humanoid
CR: 12
Size: Medium or Small
tags:
  - Monster
  - Humanoid
source: SRD 5.2.1
---

```statblock
name: Archmage
size: Medium or Small
type: Humanoid (Wizard)
alignment: Neutral
ac: 17
hp: 170 (31d8 + 31)
hit_dice: 31d8 + 31
speed: 30 ft.
stats: [10, 14, 12, 20, 15, 16]
saves:
  - Int: +9
  - Wis: +6
skillsaves:
  - Arcana: +13
  - History: +9
  - Perception: +6
damage_immunities: Psychic
condition_immunities: Charmed (with Mind Blank)
gear: Wand
senses: Passive Perception 16
languages: Common plus five other languages
cr: 12
traits:
  - name: "Magic Resistance"
    desc: "The archmage has Advantage on saving throws against spells and other magical effects."
actions:
  - name: "Multiattack"
    desc: "The archmage makes four Arcane Burst attacks."
  - name: "Arcane Burst"
    desc: "Melee or Ranged Attack Roll: +9, reach 5 ft. or range 150 ft. Hit: 27 (4d10 + 5) Force damage."
  - name: "Spellcasting"
    desc: "The archmage casts one of the following spells, using Intelligence as the spellcasting ability (spell save DC 17): At Will: Detect Magic, Detect Thoughts, Disguise Self, Invisibility, Light, Mage Armor (included in AC), Mage Hand, Prestidigitation 2/Day Each: Fly, Lightning Bolt (level 7 version) 1/Day Each: Cone of Cold (level 9 version), Mind Blank (cast before combat), Scrying, Teleport"
bonusactions:
  - name: "Misty Step (3/Day)"
    desc: "The mage casts Misty Step, using the same spellcasting ability as Spellcasting."
reactions:
  - name: "Protective Magic (3/Day)"
    desc: "The archmage casts Counterspell or Shield in response to the spell’s trigger, using the same spellcasting ability as Spellcasting."
```

#Monster
