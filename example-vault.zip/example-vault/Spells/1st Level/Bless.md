---
Spell level: 1
School type: Enchantment
Casting Time: Action
Components:
  - Verbal
  - Somatic
  - Material
Concentration: true
Duration: 1 minute
Range / Area: 30 feet
Attack / Save: None
Damage / Effect: Utility
Upscale: + 1 creature
category: 1st level
---
_Level 1 Enchantment_

- **Casting time:** Action
- **Range:** 30 feet
- **Components:** V, S, M
- **Duration:** 1 minute
- **Attack/Save**: None
- **Damage/Effect**: Utility

You bless up to three creatures within range. Whenever a target makes an attack roll or a saving throw before the spell ends, the target adds 1d4 to the attack roll or save.

**_Using a Higher-Level Spell Slot._** You can target one additional creature for each spell slot level above 1.

#Spell
