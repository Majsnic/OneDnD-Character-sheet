---
Type: Dragon
CR: 2
Size: Medium
tags:
  - Monster
  - Dragon
source: SRD 5.2.1
---

```statblock
name: White Dragon Wyrmling
size: Medium
type: Dragon (Chromatic)
alignment: Chaotic Evil
ac: 16
hp: 32 (5d8 + 10)
hit_dice: 5d8 + 10
speed: 30 ft., Burrow 15 ft., Fly 60 ft., Swim 30 ft.
stats: [14, 10, 14, 5, 10, 11]
saves:
  - Dex: +2
  - Wis: +2
skillsaves:
  - Perception: +4
  - Stealth: +2
damage_immunities: Cold
senses: Blindsight 10 ft., Darkvision 60 ft.; Passive Perception 14
languages: Draconic
cr: 2
traits:
  - name: "Ice Walk"
    desc: "The dragon can move across and climb icy surfaces without needing to make an ability check. Additionally, Difficult Terrain composed of ice or snow doesn’t cost it extra movement."
actions:
  - name: "Multiattack"
    desc: "The dragon makes two Rend attacks."
  - name: "Rend"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 6 (1d8 + 2) Slashing damage plus 2 (1d4) Cold damage."
  - name: "Cold Breath (Recharge 5–6)"
    desc: "Constitution Saving Throw: DC 12, each creature in a 15-foot Cone. Failure: 22 (5d8) Cold damage. Success: Half damage."
```

#Monster
