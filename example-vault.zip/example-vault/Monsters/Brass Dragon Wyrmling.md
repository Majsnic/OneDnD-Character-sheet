---
Type: Dragon
CR: 1
Size: Medium
tags:
  - Monster
  - Dragon
source: SRD 5.2.1
---

```statblock
name: Brass Dragon Wyrmling
size: Medium
type: Dragon (Metallic)
alignment: Chaotic Good
ac: 15
hp: 22 (4d8 + 4)
hit_dice: 4d8 + 4
speed: 30 ft., Burrow 15 ft., Fly 60 ft.
stats: [15, 10, 13, 10, 11, 13]
saves:
  - Dex: +2
  - Wis: +2
skillsaves:
  - Perception: +4
  - Stealth: +2
damage_immunities: Fire
senses: Blindsight 10 ft., Darkvision 60 ft.; Passive Perception 14
languages: Draconic
cr: 1
actions:
  - name: "Rend"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 7 (1d10 + 2) Slashing damage."
  - name: "Fire Breath (Recharge 5–6)"
    desc: "Dexterity Saving Throw: DC 11, each creature in a 20-foot-long, 5-footwide Line. Failure: 14 (4d6) Fire damage. Success: Half damage."
  - name: "Sleep Breath"
    desc: "Constitution Saving Throw: DC 11, each creature in a 15-foot Cone. Failure: The target has the Incapacitated condition until the end of its next turn, at which point it repeats the save. Second Failure: The target has the Unconscious condition for 1 minute. This effect ends for the target if it takes damage or a creature within 5 feet of it takes an action to wake it."
```

#Monster
