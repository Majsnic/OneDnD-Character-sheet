---
Type: Humanoid
CR: 1
Size: Medium or Small
tags:
  - Monster
  - Humanoid
source: SRD 5.2.1
---

```statblock
name: Spy
size: Medium or Small
type: Humanoid
alignment: Neutral
ac: 12
hp: 27 (6d8)
hit_dice: 6d8
speed: 30 ft., Climb 30 ft.
stats: [10, 15, 10, 12, 14, 16]
skillsaves:
  - Deception: +5
  - Insight: +4
  - Investigation: +5
  - Perception: +6
  - Sleight of Hand: +4
  - Stealth: +6
gear: Hand Crossbow, Shortsword, Thieves’ Tools
senses: Passive Perception 16
languages: Common plus one other language
cr: 1
actions:
  - name: "Shortsword"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 5 (1d6 + 2) Piercing damage plus 7 (2d6) Poison damage."
  - name: "Hand Crossbow"
    desc: "Ranged Attack Roll: +4, range 30/120 ft. Hit: 5 (1d6 + 2) Piercing damage plus 7 (2d6) Poison damage."
bonusactions:
  - name: "Cunning Action"
    desc: "The spy takes the Dash, Disengage, or Hide action."
```

#Monster
