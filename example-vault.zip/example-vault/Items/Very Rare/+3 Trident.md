---
Rarity: Very Rare
type: object
tags:
  - Item
  - item/very-rare
  - item/weapon
item_category: Weapon
item_base: "Trident"
weapon_category: "Martial Melee"
damage_dice: "1d6"
damage_type: Piercing
weapon_properties: [Thrown, Versatile]
range_normal: 20
range_long: 60
versatile_dice: "1d8"
weapon_mastery: Topple
requires_attunement: false
attunement_note: ""
attack_bonus: 3
damage_bonus: 3
---


###### +3 Trident
_Weapon (trident), very rare_<span class="sub2">:FasWandMagicSparkles: Magic Item</span>
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>You have a +3 bonus to attack and damage rolls made with this magic weapon.
>
>**1d6+3 Piercing damage.** Range 20/60 ft. Versatile (1d8+3).
>
>- **Thrown.** You can throw this weapon to make a ranged attack, using the same ability modifier for the attack and damage rolls that you use for a melee attack with the weapon.
>- **Versatile.** This weapon can be used with one or two hands. A damage value in parentheses appears with the property - the weapon deals that damage when used with two hands to make a melee attack.
>
>**_Topple (Mastery)._** If you hit a creature with this weapon and deal damage to it, you can force the creature to make a Constitution saving throw (DC = 8 + your proficiency bonus + the ability modifier used for the attack roll). On a failed save, the creature has the Prone condition.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
