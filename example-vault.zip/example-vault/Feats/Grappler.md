---
tags:
  - Feat
source: SRD 5.2.1
---

# Grappler

**Type:** General Feat
**Prerequisite:** Strength 13 or higher
**Repeatable:** No

While you are grappling a creature, you have advantage on attack rolls against that creature. You can also use your action to try to pin a creature you are grappling: make a Strength (Athletics) check contested by the target's Strength (Athletics) or Dexterity (Acrobatics) check. On a success, both you and the target are Restrained until the grapple ends.

*Paraphrased mechanical summary, written from general knowledge of the SRD rules — treat it as a helpful draft, not a verbatim rules quote.*

#Feat
