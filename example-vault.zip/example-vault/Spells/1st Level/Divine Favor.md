---
Spell level: 1
School type: Transmutation
Casting Time: Bonus Action
Components:
  - Verbal
  - Somatic
Concentration: false
Duration: 1 minute
Range / Area: Self
Attack / Save: Auto-hit
Damage / Effect: 1d4 Radiant
Upscale: 
category: 1st level
---
_Level 1 Transmutation_

- **Casting time:** Bonus Action
- **Range:** Self
- **Components:** V, S
- **Duration:** 1 minute
- **Attack/Save**: Auto-hit
- **Damage/Effect**: Radiant

Until the spell ends, your attacks with weapons deal an extra 1d4 Radiant damage on a hit.

#Spell
