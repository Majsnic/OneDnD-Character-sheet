---
Type: Beast
CR: 1/2
Size: Medium
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Giant Wasp
size: Medium
type: Beast
alignment: Unaligned
ac: 13
hp: 22 (5d8)
hit_dice: 5d8
speed: 10 ft., Fly 50 ft.
stats: [10, 14, 10, 1, 10, 3]
senses: Passive Perception 10
languages: None
cr: 1/2
traits:
  - name: "Flyby"
    desc: "The wasp doesn’t provoke an Opportunity Attack when it flies out of an enemy’s reach."
actions:
  - name: "Sting"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 5 (1d6 + 2) Piercing damage plus 5 (2d4) Poison damage."
```

#Monster
