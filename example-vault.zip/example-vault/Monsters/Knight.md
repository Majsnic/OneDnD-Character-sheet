---
Type: Humanoid
CR: 3
Size: Medium or Small
tags:
  - Monster
  - Humanoid
source: SRD 5.2.1
---

```statblock
name: Knight
size: Medium or Small
type: Humanoid
alignment: Neutral
ac: 18
hp: 52 (8d8 + 16)
hit_dice: 8d8 + 16
speed: 30 ft.
stats: [16, 11, 14, 11, 11, 15]
saves:
  - Con: +4
  - Wis: +2
condition_immunities: Frightened
gear: Greatsword, Heavy Crossbow, Plate Armor
senses: Passive Perception 10
languages: Common plus one other language
cr: 3
actions:
  - name: "Multiattack"
    desc: "The knight makes two attacks, using Greatsword or Heavy Crossbow in any combination."
  - name: "Greatsword"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 10 (2d6 + 3) Slashing damage plus 4 (1d8) Radiant damage."
  - name: "Heavy Crossbow"
    desc: "Ranged Attack Roll: +2, range 100/400 ft. Hit: 11 (2d10) Piercing damage plus 4 (1d8) Radiant damage."
reactions:
  - name: "Parry"
    desc: "Trigger: The knight is hit by a melee attack roll while holding a weapon. Response: The knight adds 2 to its AC against that attack, possibly causing it to miss."
```

#Monster
