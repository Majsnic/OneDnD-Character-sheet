---
Type: Fey
CR: 1/2
Size: Medium
tags:
  - Monster
  - Fey
source: SRD 5.2.1
---

```statblock
name: Hobgoblin Warrior
size: Medium
type: Fey (Goblinoid)
alignment: Lawful Evil
ac: 18
hp: 11 (2d8 + 2)
hit_dice: 2d8 + 2
speed: 30 ft.
stats: [13, 12, 12, 10, 10, 9]
gear: Half Plate Armor, Longbow, Longsword, Shield
senses: Darkvision 60 ft.; Passive Perception 10
languages: Common, Goblin
cr: 1/2
traits:
  - name: "Pack Tactics"
    desc: "The hobgoblin has Advantage on an attack roll against a creature if at least one of the hobgoblin’s allies is within 5 feet of the creature and the ally doesn’t have the Incapacitated condition."
actions:
  - name: "Longsword"
    desc: "Melee Attack Roll: +3, reach 5 ft. Hit: 12 (2d10 + 1) Slashing damage."
  - name: "Longbow"
    desc: "Ranged Attack Roll: +3, range 150/600 ft. Hit: 5 (1d8 + 1) Piercing damage plus 7 (3d4) Poison damage."
```

#Monster
