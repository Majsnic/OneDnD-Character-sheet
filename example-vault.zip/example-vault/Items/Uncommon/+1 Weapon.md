---
Rarity: Uncommon
type: object
tags:
  - Item
  - item/uncommon
item_category: Weapon
item_base: "Any weapon"
requires_attunement: false
attunement_note: ""
attack_bonus: 1
damage_bonus: 1
---


###### +1 Weapon
_Weapon (any), uncommon_<span class="sub2">:FasWandMagicSparkles: Magic Item</span>
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>You have a +1 bonus to attack and damage rolls made with this magic weapon.
>
>This is the generic 2024 rules pattern for a basic magic weapon: pick the mundane weapon it's forged from (any type, any mastery property), give it a +1 bonus, and it counts as magical for the purpose of overcoming resistance/immunity to nonmagical attacks.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
