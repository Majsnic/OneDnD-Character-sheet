---
Type: Beast
CR: 2
Size: Large
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Hunter Shark
size: Large
type: Beast
alignment: Unaligned
ac: 12
hp: 45 (6d10 + 12)
hit_dice: 6d10 + 12
speed: 5 ft., Swim 40 ft.
stats: [18, 14, 15, 1, 10, 4]
skillsaves:
  - Perception: +2
senses: Blindsight 60 ft.; Passive Perception 12
languages: None
cr: 2
traits:
  - name: "Water Breathing"
    desc: "The shark can breathe only underwater."
actions:
  - name: "Bite"
    desc: "Melee Attack Roll: +6 (with Advantage if the target doesn’t have all its Hit Points), reach 5 ft. Hit: 14 (3d6 + 4) Piercing damage."
```

#Monster
