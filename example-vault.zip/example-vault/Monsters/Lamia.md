---
Type: Fiend
CR: 4
Size: Large
tags:
  - Monster
  - Fiend
source: SRD 5.2.1
---

```statblock
name: Lamia
size: Large
type: Fiend
alignment: Chaotic Evil
ac: 13
hp: 97 (13d10 + 26)
hit_dice: 13d10 + 26
speed: 40 ft.
stats: [16, 13, 15, 14, 15, 16]
skillsaves:
  - Deception: +7
  - Insight: +4
  - Stealth: +5
senses: Darkvision 60 ft.; Passive Perception 12
languages: Abyssal, Common
cr: 4
actions:
  - name: "Multiattack"
    desc: "The lamia makes two Claw attacks. It can replace one attack with a use of Corrupting Touch."
  - name: "Claw"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 7 (1d8 + 3) Slashing damage plus 7 (2d6) Psychic damage."
  - name: "Corrupting Touch"
    desc: "Wisdom Saving Throw: DC 13, one creature the lamia can see within 5 feet. Failure: 13 (3d8) Psychic damage, and the target is cursed for 1 hour. Until the curse ends, the target has the Charmed and Poisoned conditions."
  - name: "Spellcasting"
    desc: "The lamia casts one of the following spells, requiring no Material components and using Charisma as the spellcasting ability (spell save DC 13): At Will: Disguise Self (can appear as a Large or Medium biped), Minor Illusion 1/Day Each: Geas, Major Image, Scrying"
bonusactions:
  - name: "Leap"
    desc: "The lamia jumps up to 30 feet by spending 10 feet of movement."
```

#Monster
