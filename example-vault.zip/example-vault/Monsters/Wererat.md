---
Type: Monstrosity
CR: 2
Size: Medium or Small
tags:
  - Monster
  - Monstrosity
source: SRD 5.2.1
---

```statblock
name: Wererat
size: Medium or Small
type: Monstrosity (Lycanthrope)
alignment: Lawful Evil
ac: 13
hp: 60 (11d8 + 11)
hit_dice: 11d8 + 11
speed: 30 ft., Climb 30 ft.
stats: [10, 16, 12, 11, 10, 8]
skillsaves:
  - Perception: +4
  - Stealth: +5
gear: Hand Crossbow
senses: Darkvision 60 ft.; Passive Perception 14
languages: Common (can’t speak in rat form)
cr: 2
actions:
  - name: "Multiattack"
    desc: "The wererat makes two attacks, using Scratch or Hand Crossbow in any combination. It can replace one attack with a Bite attack."
  - name: "Bite (Rat or Hybrid Form Only)"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 8 (2d4 + 3) Piercing damage. If the target is a Humanoid, it is subjected to the following effect. Constitution Saving Throw: DC 11. Failure: The target is cursed. If the cursed target drops to 0 Hit Points, it instead becomes a Wererat under the GM’s control and has 10 Hit Points. Success: The target is immune to this wererat’s curse for 24 hours."
  - name: "Scratch"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 6 (1d6 + 3) Slashing damage. Hand Crossbow (Humanoid or Hybrid Form Only). Ranged Attack Roll: +5, range 30/120 ft. Hit: 6 (1d6 + 3) Piercing damage."
bonusactions:
  - name: "Shape-Shift"
    desc: "The wererat shape-shifts into a Medium rat-humanoid hybrid or a Small rat, or it returns to its true humanoid form. Its game statistics, other than its size, are the same in each form. Any equipment it is wearing or carrying isn’t transformed."
```

#Monster
