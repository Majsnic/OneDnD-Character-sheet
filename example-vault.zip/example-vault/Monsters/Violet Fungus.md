---
Type: Plant
CR: 1/4
Size: Medium
tags:
  - Monster
  - Plant
source: SRD 5.2.1
---

```statblock
name: Violet Fungus
size: Medium
type: Plant
alignment: Unaligned
ac: 5
hp: 18 (4d8)
hit_dice: 4d8
speed: 5 ft.
stats: [3, 1, 10, 1, 3, 1]
condition_immunities: Blinded, Charmed, Deafened, Frightened
senses: Blindsight 30 ft.; Passive Perception 6
languages: None
cr: 1/4
actions:
  - name: "Multiattack"
    desc: "The fungus makes two Rotting Touch attacks."
  - name: "Rotting Touch"
    desc: "Melee Attack Roll: +2, reach 10 ft. Hit: 4 (1d8) Necrotic damage."
```

#Monster
