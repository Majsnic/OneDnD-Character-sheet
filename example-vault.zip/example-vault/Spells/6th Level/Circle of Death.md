---
Spell level: 6
School type: Necromancy
Casting Time: Action
Components:
  - Verbal
  - Somatic
  - Material
Concentration: false
Duration: Instantaneous
Range / Area: 150 feet
Attack / Save: CON Save
Damage / Effect: 8d8 Necrotic
Upscale: + 2d8
category: 6th level
---
_Level 6 Necromancy_

- **Casting time:** Action
- **Range:** 150 feet
- **Components:** V, S, M
- **Duration:** Instantaneous
- **Attack/Save**: CON Save
- **Damage/Effect**: Necrotic

Negative energy ripples out in a 60-foot-radius Sphere from a point you choose within range. Each creature in that area makes a Constitution saving throw, taking 8d8 Necrotic damage on a failed save or half as much damage on a successful one.

**_Using a Higher-Level Spell Slot._** The damage increases by 2d8 for each spell slot level above 6.

#Spell
