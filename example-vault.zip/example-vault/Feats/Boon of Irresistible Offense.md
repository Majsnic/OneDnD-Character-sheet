---
tags:
  - Feat
source: SRD 5.2.1
---

# Boon of Irresistible Offense

**Type:** Epic Boon Feat
**Prerequisite:** Character level 19
**Repeatable:** No

Your weapon attacks ignore resistance to the damage type they deal. In addition, a number of times equal to your proficiency bonus, you can cause one such attack to treat a target's immunity to that damage type as resistance instead. You regain all expended uses after a long rest.

*Paraphrased mechanical summary, written from general knowledge of the SRD rules — treat it as a helpful draft, not a verbatim rules quote.*

#Feat
