---
Type: Dragon
CR: 6
Size: Large
tags:
  - Monster
  - Dragon
source: SRD 5.2.1
---

```statblock
name: Young White Dragon
size: Large
type: Dragon (Chromatic)
alignment: Chaotic Evil
ac: 17
hp: 123 (13d10 + 52)
hit_dice: 13d10 + 52
speed: 40 ft., Burrow 20 ft., Fly 80 ft., Swim 40 ft.
stats: [18, 10, 18, 6, 11, 12]
saves:
  - Dex: +3
  - Wis: +3
skillsaves:
  - Perception: +6
  - Stealth: +3
damage_immunities: Cold
senses: Blindsight 30 ft., Darkvision 120 ft.; Passive Perception 16
languages: Common, Draconic
cr: 6
traits:
  - name: "Ice Walk"
    desc: "The dragon can move across and climb icy surfaces without needing to make an ability check. Additionally, Difficult Terrain composed of ice or snow doesn’t cost it extra movement."
actions:
  - name: "Multiattack"
    desc: "The dragon makes three Rend attacks."
  - name: "Rend"
    desc: "Melee Attack Roll: +7, reach 10 ft. Hit: 9 (2d4 + 4) Slashing damage plus 2 (1d4) Cold damage."
  - name: "Cold Breath (Recharge 5–6)"
    desc: "Constitution Saving Throw: DC 15, each creature in a 30-foot Cone. Failure: 40 (9d8) Cold damage. Success: Half damage."
```

#Monster
