---
Rarity: Rare
type: object
tags:
  - Item
  - item/rare
  - item/weapon
item_category: Weapon
item_base: "Warhammer"
weapon_category: "Martial Melee"
damage_dice: "1d8"
damage_type: Bludgeoning
weapon_properties: [Versatile]
versatile_dice: "1d10"
weapon_mastery: Push
requires_attunement: false
attunement_note: ""
attack_bonus: 2
damage_bonus: 2
---


###### +2 Warhammer
_Weapon (warhammer), rare_<span class="sub2">:FasWandMagicSparkles: Magic Item</span>
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>You have a +2 bonus to attack and damage rolls made with this magic weapon.
>
>**1d8+2 Bludgeoning damage.** Versatile (1d10+2).
>
>- **Versatile.** This weapon can be used with one or two hands. A damage value in parentheses appears with the property - the weapon deals that damage when used with two hands to make a melee attack.
>
>**_Push (Mastery)._** If you hit a creature with this weapon and deal damage to it, you can push the creature up to 10 feet straight away from yourself if it is Large or smaller.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
