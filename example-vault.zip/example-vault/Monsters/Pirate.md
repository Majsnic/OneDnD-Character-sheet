---
Type: Humanoid
CR: 1
Size: Medium or Small
tags:
  - Monster
  - Humanoid
source: SRD 5.2.1
---

```statblock
name: Pirate
size: Medium or Small
type: Humanoid
alignment: Neutral
ac: 14
hp: 33 (6d8 + 6)
hit_dice: 6d8 + 6
speed: 30 ft.
stats: [10, 16, 12, 8, 12, 14]
saves:
  - Dex: +5
  - Cha: +4
gear: Daggers (6), Leather Armor
senses: Passive Perception 11
languages: Common plus one other language
cr: 1
actions:
  - name: "Multiattack"
    desc: "The pirate makes two Dagger attacks. It can replace one attack with a use of Enthralling Panache."
  - name: "Dagger"
    desc: "Melee or Ranged Attack Roll: +5, reach 5 ft. or range 20/60 ft. Hit: 5 (1d4 + 3) Piercing damage."
  - name: "Enthralling Panache"
    desc: "Wisdom Saving Throw: DC 12, one creature the pirate can see within 30 feet. Failure: The target has the Charmed condition until the start of the pirate’s next turn."
```

#Monster
