---
Type: Fiend
CR: 9
Size: Large
tags:
  - Monster
  - Fiend
source: SRD 5.2.1
---

```statblock
name: Bone Devil
size: Large
type: Fiend (Devil)
alignment: Lawful Evil
ac: 16
hp: 161 (17d10 + 68)
hit_dice: 17d10 + 68
speed: 40 ft., Fly 40 ft.
stats: [18, 16, 18, 13, 14, 16]
saves:
  - Str: +8
  - Int: +5
  - Wis: +6
  - Cha: +7
skillsaves:
  - Deception: +7
  - Insight: +6
damage_resistances: Cold
damage_immunities: Fire, Poison
condition_immunities: Poisoned
senses: Darkvision 120 ft. (unimpeded by magical Darkness); Passive Perception 12
languages: Infernal; telepathy 120 ft.
cr: 9
traits:
  - name: "Diabolical Restoration"
    desc: "If the devil dies outside the Nine Hells, its body disappears in sulfurous smoke, and it gains a new body instantly, reviving with all its Hit Points somewhere in the Nine Hells."
  - name: "Magic Resistance"
    desc: "The devil has Advantage on saving throws against spells and other magical effects."
actions:
  - name: "Multiattack"
    desc: "The devil makes two Claw attacks and one Infernal Sting attack."
  - name: "Claw"
    desc: "Melee Attack Roll: +8, reach 10 ft. Hit: 13 (2d8 + 4) Slashing damage."
  - name: "Infernal Sting"
    desc: "Melee Attack Roll: +8, reach 10 ft. Hit: 15 (2d10 + 4) Piercing damage plus 18 (4d8) Poison damage, and the target has the Poisoned condition until the start of the devil’s next turn. While Poisoned, the target can’t regain Hit Points."
```

#Monster
