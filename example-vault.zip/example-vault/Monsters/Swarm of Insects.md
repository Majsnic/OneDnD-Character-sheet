---
Type: Beast
CR: 1/2
Size: Medium
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Swarm of Insects
size: Medium
type: Swarm of Tiny Beasts
alignment: Unaligned
ac: 11
hp: 19 (3d8 + 6)
hit_dice: 3d8 + 6
speed: 20 ft., Climb or Fly 20 ft. (GM’s choice)
stats: [3, 13, 14, 1, 7, 1]
damage_resistances: Bludgeoning, Piercing, Slashing
condition_immunities: Charmed, Frightened, Grappled, Paralyzed, Petrified, Prone, Restrained, Stunned
senses: Blindsight 30 ft.; Passive Perception 8
languages: None
cr: 1/2
traits:
  - name: "Spider Climb"
    desc: "If the swarm has a Climb Speed, the swarm can climb difficult surfaces, including along ceilings, without needing to make an ability check."
  - name: "Swarm"
    desc: "The swarm can occupy another creature’s space and vice versa, and the swarm can move through any opening large enough for a Tiny insect. The swarm can’t regain Hit Points or gain Temporary Hit Points."
actions:
  - name: "Bites"
    desc: "Melee Attack Roll: +3, reach 5 ft. Hit: 6 (2d4 + 1) Poison damage, or 3 (1d4 + 1) Poison damage if the swarm is Bloodied."
```

#Monster
