---
Type: Fiend
CR: 1/4
Size: Small
tags:
  - Monster
  - Fiend
source: SRD 5.2.1
---

```statblock
name: Dretch
size: Small
type: Fiend (Demon)
alignment: Chaotic Evil
ac: 11
hp: 18 (4d6 + 4)
hit_dice: 4d6 + 4
speed: 20 ft.
stats: [12, 11, 12, 5, 8, 3]
damage_resistances: Cold, Fire, Lightning
damage_immunities: Poison
condition_immunities: Poisoned
senses: Darkvision 60 ft.; Passive Perception 9
languages: Abyssal; telepathy 60 ft. (works only with creatures that understand Abyssal)
cr: 1/4
actions:
  - name: "Rend"
    desc: "Melee Attack Roll: +3, reach 5 ft. Hit: 4 (1d6 + 1) Slashing damage."
  - name: "Fetid Cloud (1/Day)"
    desc: "Constitution Saving Throw: DC 11, each creature in a 10-foot Emanation originating from the dretch. Failure: The target has the Poisoned condition until the end of its next turn. While Poisoned, the creature can take either an action or a Bonus Action on its turn, not both, and it can’t take Reactions."
```

#Monster
