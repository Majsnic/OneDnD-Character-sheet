---
Spell level: 3
School type: Conjuration
Casting Time: Action
Components:
  - Verbal
  - Somatic
  - Material
Concentration: true
Duration: 1 minute
Range / Area: 90 feet
Attack / Save: CON Save
Damage / Effect: Poisoned
Upscale: 
category: 3rd level
---
_Level 3 Conjuration_

- **Casting time:** Action
- **Range:** 90 feet
- **Components:** V, S, M
- **Duration:** 1 minute
- **Attack/Save**: CON Save
- **Damage/Effect**: Poisoned

You create a 20-foot-radius Sphere of yellow, nauseating gas centered on a point within range. The cloud is Heavily Obscured. The cloud lingers in the air for the duration or until a strong wind (such as the one created by Gust of Wind) disperses it. Each creature that starts its turn in the Sphere must succeed on a Constitution saving throw or have the Poisoned condition until the end of the current turn. While Poisoned in this way, the creature can’t take an action or a Bonus Action.

#Spell
