---
Type: Beast
CR: 0
Size: Medium
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Vulture
size: Medium
type: Beast
alignment: Unaligned
ac: 10
hp: 5 (1d8 + 1)
hit_dice: 1d8 + 1
speed: 10 ft., Fly 50 ft.
stats: [7, 10, 13, 2, 12, 4]
skillsaves:
  - Perception: +3
senses: Passive Perception 13
languages: None
cr: 0
traits:
  - name: "Pack Tactics"
    desc: "The vulture has Advantage on an attack roll against a creature if at least one of the vulture’s allies is within 5 feet of the creature and the ally doesn’t have the Incapacitated condition."
actions:
  - name: "Beak"
    desc: "Melee Attack Roll: +2, reach 5 ft. Hit: 2 (1d4) Piercing damage."
```

#Monster
