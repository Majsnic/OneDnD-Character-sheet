---
Spell level: 6
School type: Transmutation
Casting Time: Action
Components:
  - Verbal
  - Somatic
  - Material
Concentration: true
Duration: 1 minute
Range / Area: 60 feet
Attack / Save: CON Save
Damage / Effect: Petrified
Upscale: 
category: 6th level
---
_Level 6 Transmutation_

- **Casting time:** Action
- **Range:** 60 feet
- **Components:** V, S, M
- **Duration:** 1 minute
- **Attack/Save**: CON Save
- **Damage/Effect**: Petrified

You attempt to turn one creature that you can see within range into stone. The target makes a Constitution saving throw. On a failed save, it has the Restrained condition for the duration. On a successful save, its Speed is 0 until the start of your next turn. Constructs automatically succeed on the save. A Restrained target makes another Constitution saving throw at the end of each of its turns. If it successfully saves against this spell three times, the spell ends. If it fails its saves three times, it is turned to stone and has the Petrified condition for the duration. The successes and failures needn’t be consecutive; keep track of both until the target collects three of a kind. If you maintain your Concentration on this spell for the entire possible duration, the target is Petrified until the condition is ended by Greater Restoration or similar magic.

#Spell
