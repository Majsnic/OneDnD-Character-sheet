---
Spell level: 1
School type: Abjuration
Casting Time: Bonus Action
Components:
  - Verbal
  - Somatic
  - Material
Concentration: false
Duration: 1 minute
Range / Area: 30 feet
Attack / Save: WIS Save
Damage / Effect: Utility
Upscale: 
category: 1st level
---
_Level 1 Abjuration_

- **Casting time:** Bonus Action
- **Range:** 30 feet
- **Components:** V, S, M
- **Duration:** 1 minute
- **Attack/Save**: WIS Save
- **Damage/Effect**: Utility

You ward a creature within range. Until the spell ends, any creature who targets the warded creature with an attack roll or a damaging spell must succeed on a Wisdom saving throw or either choose a new target or lose the attack or spell. This spell doesn’t protect the warded creature from areas of effect. The spell ends if the warded creature makes an attack roll, casts a spell, or deals damage.

#Spell
