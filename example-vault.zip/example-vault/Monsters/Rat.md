---
Type: Beast
CR: 0
Size: Tiny
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Rat
size: Tiny
type: Beast
alignment: Unaligned
ac: 10
hp: 1 (1d4 - 1)
hit_dice: 1d4 - 1
speed: 20 ft., Climb 20 ft.
stats: [2, 11, 9, 2, 10, 4]
skillsaves:
  - Perception: +2
senses: Darkvision 30 ft.; Passive Perception 12
languages: None
cr: 0
traits:
  - name: "Agile"
    desc: "The rat doesn’t provoke an Opportunity Attack when it moves out of an enemy’s reach."
actions:
  - name: "Bite"
    desc: "Melee Attack Roll: +2, reach 5 ft. Hit: 1 Piercing damage."
```

#Monster
