---
Type: Beast
CR: 0
Size: Small
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Baboon
size: Small
type: Beast
alignment: Unaligned
ac: 12
hp: 3 (1d6)
hit_dice: 1d6
speed: 30 ft., Climb 30 ft.
stats: [8, 14, 11, 4, 12, 6]
senses: Passive Perception 11
languages: None
cr: 0
traits:
  - name: "Pack Tactics"
    desc: "The baboon has Advantage on an attack roll against a creature if at least one of the baboon’s allies is within 5 feet of the creature and the ally doesn’t have the Incapacitated condition."
actions:
  - name: "Bite"
    desc: "Melee Attack Roll: +1, reach 5 ft. Hit: 1 (1d4 - 1) Piercing damage."
```

#Monster
