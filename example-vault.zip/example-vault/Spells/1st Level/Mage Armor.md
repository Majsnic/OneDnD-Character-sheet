---
Spell level: 1
School type: Abjuration
Casting Time: Action
Components:
  - Verbal
  - Somatic
  - Material
Concentration: false
Duration: 8 hours
Range / Area: Touch
Attack / Save: None
Damage / Effect: Utility
Upscale: 
category: 1st level
---
_Level 1 Abjuration_

- **Casting time:** Action
- **Range:** Touch
- **Components:** V, S, M
- **Duration:** 8 hours
- **Attack/Save**: None
- **Damage/Effect**: Utility

You touch a willing creature who isn’t wearing armor. Until the spell ends, the target’s base AC becomes 13 plus its Dexterity modifier. The spell ends early if the target dons armor.

#Spell
