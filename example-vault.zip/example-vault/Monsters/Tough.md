---
Type: Humanoid
CR: 1/2
Size: Medium or Small
tags:
  - Monster
  - Humanoid
source: SRD 5.2.1
---

```statblock
name: Tough
size: Medium or Small
type: Humanoid
alignment: Neutral
ac: 12
hp: 32 (5d8 + 10)
hit_dice: 5d8 + 10
speed: 30 ft.
stats: [15, 12, 14, 10, 10, 11]
gear: Heavy Crossbow, Leather Armor, Mace
senses: Passive Perception 10
languages: Common
cr: 1/2
traits:
  - name: "Pack Tactics"
    desc: "The tough has Advantage on an attack roll against a creature if at least one of the tough’s allies is within 5 feet of the creature and the ally doesn’t have the Incapacitated condition."
actions:
  - name: "Mace"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 5 (1d6 + 2) Bludgeoning damage."
  - name: "Heavy Crossbow"
    desc: "Ranged Attack Roll: +3, range 100/400 ft. Hit: 6 (1d10 + 1) Piercing damage."
```

#Monster
