---
Type: Beast
CR: 5
Size: Huge
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Giant Shark
size: Huge
type: Beast
alignment: Unaligned
ac: 13
hp: 92 (8d12 + 40)
hit_dice: 8d12 + 40
speed: 5 ft., Swim 60 ft.
stats: [23, 11, 21, 1, 10, 5]
skillsaves:
  - Perception: +3
senses: Blindsight 60 ft.; Passive Perception 13
languages: None
cr: 5
traits:
  - name: "Water Breathing"
    desc: "The shark can breathe only underwater."
actions:
  - name: "Multiattack"
    desc: "The shark makes two Bite attacks."
  - name: "Bite"
    desc: "Melee Attack Roll: +9 (with Advantage if the target doesn’t have all its Hit Points), reach 5 ft. Hit: 22 (3d10 + 6) Piercing damage."
```

#Monster
