---
Type: Beast
CR: 1/4
Size: Large
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Giant Lizard
size: Large
type: Beast
alignment: Unaligned
ac: 12
hp: 19 (3d10 + 3)
hit_dice: 3d10 + 3
speed: 40 ft., Climb 40 ft.
stats: [15, 12, 13, 2, 10, 5]
saves:
  - Dex: +3
senses: Darkvision 60 ft.; Passive Perception 10
languages: None
cr: 1/4
traits:
  - name: "Spider Climb"
    desc: "The lizard can climb difficult surfaces, including along ceilings, without needing to make an ability check."
actions:
  - name: "Bite"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 6 (1d8 + 2) Piercing damage."
```

#Monster
