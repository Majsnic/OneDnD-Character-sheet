---
Type: Undead
CR: 1/4
Size: Medium
tags:
  - Monster
  - Undead
source: SRD 5.2.1
---

```statblock
name: Skeleton
size: Medium
type: Undead
alignment: Lawful Evil
ac: 14
hp: 13 (2d8 + 4)
hit_dice: 2d8 + 4
speed: 30 ft.
stats: [10, 16, 15, 6, 8, 5]
damage_vulnerabilities: Bludgeoning
damage_immunities: Poison
condition_immunities: Exhaustion, Poisoned
gear: Shortbow, Shortsword
senses: Darkvision 60 ft.; Passive Perception 9
languages: Understands Common plus one other language but can’t speak
cr: 1/4
actions:
  - name: "Shortsword"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 6 (1d6 + 3) Piercing damage."
  - name: "Shortbow"
    desc: "Ranged Attack Roll: +5, range 80/320 ft. Hit: 6 (1d6 + 3) Piercing damage."
```

#Monster
