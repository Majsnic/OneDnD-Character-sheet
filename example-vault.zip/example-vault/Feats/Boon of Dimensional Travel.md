---
tags:
  - Feat
source: SRD 5.2.1
---

# Boon of Dimensional Travel

**Type:** Epic Boon Feat
**Prerequisite:** Character level 19
**Repeatable:** No

A number of times equal to your proficiency bonus, you can cast Plane Shift, targeting only yourself, without expending a spell slot or using material components (this boon serves as your spellcasting focus). You regain all expended uses when you finish a long rest.

*Paraphrased mechanical summary, written from general knowledge of the SRD rules — treat it as a helpful draft, not a verbatim rules quote.*

#Feat
