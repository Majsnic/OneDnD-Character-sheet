---
Spell level: 6
School type: Abjuration
Casting Time: 10 minutes
Components:
  - Verbal
  - Somatic
  - Material
Concentration: false
Duration: 10 days
Range / Area: Self
Attack / Save: None
Damage / Effect: Utility
Upscale: 
category: 6th level
---
_Level 6 Abjuration_

- **Casting time:** 10 minutes
- **Range:** Self
- **Components:** V, S, M
- **Duration:** 10 days
- **Attack/Save**: None
- **Damage/Effect**: Utility

Choose a spell of level 5 or lower that you can cast, that has a casting time of an action, and that can target you. You cast that spell—called the contingent spell—as part of casting Contingency, expending spell slots for both, but the contingent spell doesn’t come into effect. Instead, it takes effect when a certain trigger occurs. You describe that trigger when you cast the two spells. For example, a Contingency cast with Water Breathing might stipulate that Water Breathing comes into effect when you are engulfed in water or a similar liquid. The contingent spell takes effect immediately after the trigger occurs for the first time, whether or not you want it to, and then Contingency ends. The contingent spell takes effect only on you, even if it can normally target others. You can use only one Contingency spell at a time. If you cast this spell again, the effect of another Contingency spell on you ends. Also, Contingency ends on you if its material component is ever not on your person.

#Spell
