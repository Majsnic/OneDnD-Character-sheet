---
Type: Beast
CR: 3
Size: Huge
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Killer Whale
size: Huge
type: Beast
alignment: Unaligned
ac: 12
hp: 90 (12d12 + 12)
hit_dice: 12d12 + 12
speed: 5 ft., Swim 60 ft.
stats: [19, 14, 13, 3, 12, 7]
skillsaves:
  - Perception: +3
  - Stealth: +4
senses: Blindsight 120 ft.; Passive Perception 13
languages: None
cr: 3
traits:
  - name: "Hold Breath"
    desc: "The whale can hold its breath for 30 minutes."
actions:
  - name: "Bite"
    desc: "Melee Attack Roll: +6, reach 5 ft. Hit: 21 (5d6 + 4) Piercing damage."
```

#Monster
