---
Type: Dragon
CR: 2
Size: Medium
tags:
  - Monster
  - Dragon
source: SRD 5.2.1
---

```statblock
name: Black Dragon Wyrmling
size: Medium
type: Dragon (Chromatic)
alignment: Chaotic Evil
ac: 17
hp: 33 (6d8 + 6)
hit_dice: 6d8 + 6
speed: 30 ft., Fly 60 ft., Swim 30 ft.
stats: [15, 14, 13, 10, 11, 13]
saves:
  - Dex: +4
  - Wis: +2
skillsaves:
  - Perception: +4
  - Stealth: +4
damage_immunities: Acid
senses: Blindsight 10 ft., Darkvision 60 ft.; Passive Perception 14
languages: Draconic
cr: 2
traits:
  - name: "Amphibious"
    desc: "The dragon can breathe air and water."
actions:
  - name: "Multiattack"
    desc: "The dragon makes two Rend attacks."
  - name: "Rend"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 5 (1d6 + 2) Slashing damage plus 2 (1d4) Acid damage."
  - name: "Acid Breath (Recharge 5–6)"
    desc: "Dexterity Saving Throw: DC 11, each creature in a 15-foot-long, 5-footwide Line. Failure: 22 (5d8) Acid damage. Success: Half damage."
```

#Monster
