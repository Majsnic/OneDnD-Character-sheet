---
Type: Beast
CR: 1/2
Size: Large
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Warhorse
size: Large
type: Beast
alignment: Unaligned
ac: 11
hp: 19 (3d10 + 3)
hit_dice: 3d10 + 3
speed: 60 ft.
stats: [18, 12, 13, 2, 12, 7]
saves:
  - Wis: +3
senses: Passive Perception 11
languages: None
cr: 1/2
actions:
  - name: "Hooves"
    desc: "Melee Attack Roll: +6, reach 5 ft. Hit: 9 (2d4 + 4) Bludgeoning damage. If the target is a Large or smaller creature and the horse moved 20+ feet straight toward it immediately before the hit, the target takes an extra 5 (2d4) Bludgeoning damage and has the Prone condition."
```

#Monster
