---
Type: Monstrosity
CR: 3
Size: Large
tags:
  - Monster
  - Monstrosity
source: SRD 5.2.1
---

```statblock
name: Winter Wolf
size: Large
type: Monstrosity
alignment: Neutral Evil
ac: 13
hp: 75 (10d10 + 20)
hit_dice: 10d10 + 20
speed: 50 ft.
stats: [18, 13, 14, 7, 12, 8]
skillsaves:
  - Perception: +5
  - Stealth: +5
damage_immunities: Cold
senses: Passive Perception 15
languages: Common, Giant
cr: 3
traits:
  - name: "Pack Tactics"
    desc: "The wolf has Advantage on an attack roll against a creature if at least one of the wolf’s allies is within 5 feet of the creature and the ally doesn’t have the Incapacitated condition."
actions:
  - name: "Bite"
    desc: "Melee Attack Roll: +6, reach 5 ft. Hit: 11 (2d6 + 4) Piercing damage. If the target is a Large or smaller creature, it has the Prone condition."
  - name: "Cold Breath (Recharge 5–6)"
    desc: "Constitution Saving Throw: DC 12, each creature in a 15-foot Cone. Failure: 18 (4d8) Cold damage. Success: Half damage."
```

#Monster
