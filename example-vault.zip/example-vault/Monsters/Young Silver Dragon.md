---
Type: Dragon
CR: 9
Size: Large
tags:
  - Monster
  - Dragon
source: SRD 5.2.1
---

```statblock
name: Young Silver Dragon
size: Large
type: Dragon (Metallic)
alignment: Lawful Good
ac: 18
hp: 168 (16d10 + 80)
hit_dice: 16d10 + 80
speed: 40 ft., Fly 80 ft.
stats: [23, 10, 21, 14, 11, 19]
saves:
  - Dex: +4
  - Wis: +4
skillsaves:
  - History: +6
  - Perception: +8
  - Stealth: +4
damage_immunities: Cold
senses: Blindsight 30 ft., Darkvision 120 ft.; Passive Perception 18
languages: Common, Draconic
cr: 9
actions:
  - name: "Multiattack"
    desc: "The dragon makes three Rend attacks. It can replace one attack with a use of Paralyzing Breath."
  - name: "Rend"
    desc: "Melee Attack Roll: +10, reach 10 ft. Hit: 15 (2d8 + 6) Slashing damage."
  - name: "Cold Breath (Recharge 5–6)"
    desc: "Constitution Saving Throw: DC 17, each creature in a 30-foot Cone. Failure: 49 (11d8) Cold damage. Success: Half damage."
  - name: "Paralyzing Breath"
    desc: "Constitution Saving Throw: DC 17, each creature in a 30-foot Cone. First Failure: The target has the Incapacitated condition until the end of its next turn, when it repeats the save. Second Failure: The target has the Paralyzed condition, and it repeats the save at the end of each of its turns, ending the effect on itself on a success. After 1 minute, it succeeds automatically."
```

#Monster
