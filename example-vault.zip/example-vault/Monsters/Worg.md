---
Type: Fey
CR: 1/2
Size: Large
tags:
  - Monster
  - Fey
source: SRD 5.2.1
---

```statblock
name: Worg
size: Large
type: Fey
alignment: Neutral Evil
ac: 13
hp: 26 (4d10 + 4)
hit_dice: 4d10 + 4
speed: 50 ft.
stats: [16, 13, 13, 7, 11, 8]
skillsaves:
  - Perception: +4
senses: Darkvision 60 ft.; Passive Perception 14
languages: Goblin, Worg
cr: 1/2
actions:
  - name: "Bite"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 7 (1d8 + 3) Piercing damage, and the next attack roll made against the target before the start of the worg’s next turn has Advantage."
```

#Monster
