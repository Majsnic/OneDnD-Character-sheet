---
tags:
  - Feat
source: SRD 5.2.1
---

# Alert

**Type:** Origin Feat
**Repeatable:** No

You're always ready for trouble. You gain a bonus to initiative rolls equal to your proficiency bonus. In addition, you can't be surprised while you are conscious, and when you roll initiative, you can swap your initiative with that of a willing, non-incapacitated ally in the same combat.

*Paraphrased mechanical summary, written from general knowledge of the SRD rules — treat it as a helpful draft, not a verbatim rules quote.*

#Feat
