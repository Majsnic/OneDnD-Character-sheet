---
tags:
  - Condition
source: SRD 5.2.1
---

# Incapacitated

You can't take actions, bonus actions, or reactions. Your concentration is broken, and you can't speak.

*Paraphrased mechanical summary, written from general knowledge of the SRD rules — treat it as a helpful draft, not a verbatim rules quote.*

#Condition
