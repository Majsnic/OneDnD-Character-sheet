---
tags:
  - Feat
source: SRD 5.2.1
---

# Boon of Combat Prowess

**Type:** Epic Boon Feat
**Prerequisite:** Character level 19
**Repeatable:** No

You gain a reservoir of combat mastery with a number of charges equal to your proficiency bonus. When you make a weapon attack roll and miss, you can expend one charge to turn that miss into a hit instead. You regain all expended charges when you finish a long rest.

*Paraphrased mechanical summary, written from general knowledge of the SRD rules — treat it as a helpful draft, not a verbatim rules quote.*

#Feat
