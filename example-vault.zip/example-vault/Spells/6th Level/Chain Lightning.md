---
Spell level: 6
School type: Evocation
Casting Time: Action
Components:
  - Verbal
  - Somatic
  - Material
Concentration: false
Duration: Instantaneous
Range / Area: 150 feet
Attack / Save: DEX Save
Damage / Effect: 10d8 Lightning
Upscale: 
category: 6th level
---
_Level 6 Evocation_

- **Casting time:** Action
- **Range:** 150 feet
- **Components:** V, S, M
- **Duration:** Instantaneous
- **Attack/Save**: DEX Save
- **Damage/Effect**: Lightning

You launch a lightning bolt toward a target you can see within range. Three bolts then leap from that target to as many as three other targets of your choice, each of which must be within 30 feet of the first target. A target can be a creature or an object and can be targeted by only one of the bolts. Each target makes a Dexterity saving throw, taking 10d8 Lightning damage on a failed save or half as much damage on a successful one.

**_Using a Higher-Level Spell Slot._** One additional bolt leaps from the first target to another target for each spell slot level above 6.

#Spell
