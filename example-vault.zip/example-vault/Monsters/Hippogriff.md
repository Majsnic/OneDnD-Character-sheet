---
Type: Monstrosity
CR: 1
Size: Large
tags:
  - Monster
  - Monstrosity
source: SRD 5.2.1
---

```statblock
name: Hippogriff
size: Large
type: Monstrosity
alignment: Unaligned
ac: 11
hp: 26 (4d10 + 4)
hit_dice: 4d10 + 4
speed: 40 ft., Fly 60 ft.
stats: [17, 13, 13, 2, 12, 8]
skillsaves:
  - Perception: +5
senses: Passive Perception 15
languages: None
cr: 1
traits:
  - name: "Flyby"
    desc: "The hippogriff doesn’t provoke an Opportunity Attack when it flies out of an enemy’s reach."
actions:
  - name: "Multiattack"
    desc: "The hippogriff makes two Rend attacks."
  - name: "Rend"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 7 (1d8 + 3) Slashing damage."
```

#Monster
