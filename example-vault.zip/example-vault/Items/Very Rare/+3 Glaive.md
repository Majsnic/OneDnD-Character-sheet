---
Rarity: Very Rare
type: object
tags:
  - Item
  - item/very-rare
  - item/weapon
item_category: Weapon
item_base: "Glaive"
weapon_category: "Martial Melee"
damage_dice: "1d10"
damage_type: Slashing
weapon_properties: [Heavy, Reach, Two-Handed]
weapon_mastery: Graze
requires_attunement: false
attunement_note: ""
attack_bonus: 3
damage_bonus: 3
---


###### +3 Glaive
_Weapon (glaive), very rare_<span class="sub2">:FasWandMagicSparkles: Magic Item</span>
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>You have a +3 bonus to attack and damage rolls made with this magic weapon.
>
>**1d10+3 Slashing damage.** Properties: Heavy, Reach, Two-Handed.
>
>- **Heavy.** Small creatures have Disadvantage on attack rolls with this weapon.
>- **Reach.** This weapon adds 5 feet to your reach when you attack with it.
>- **Two-Handed.** You must use two hands to attack with this weapon.
>
>**_Graze (Mastery)._** If you make an attack roll with this weapon against a creature and miss, you can deal damage to that creature equal to the ability modifier used to make the attack roll. This damage is of the same type dealt by the weapon.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
