---
Type: Monstrosity
CR: 2
Size: Large
tags:
  - Monster
  - Monstrosity
source: SRD 5.2.1
---

```statblock
name: Merrow
size: Large
type: Monstrosity
alignment: Chaotic Evil
ac: 13
hp: 45 (6d10 + 12)
hit_dice: 6d10 + 12
speed: 10 ft., Swim 40 ft.
stats: [18, 15, 15, 8, 10, 9]
senses: Darkvision 60 ft.; Passive Perception 10
languages: Abyssal, Primordial (Aquan)
cr: 2
traits:
  - name: "Amphibious"
    desc: "The merrow can breathe air and water."
actions:
  - name: "Multiattack"
    desc: "The merrow makes two attacks, using Bite, Claw, or Harpoon in any combination."
  - name: "Bite"
    desc: "Melee Attack Roll: +6, reach 5 ft. Hit: 6 (1d4 + 4) Piercing damage, and the target has the Poisoned condition until the end of the merrow’s next turn."
  - name: "Claw"
    desc: "Melee Attack Roll: +6, reach 5 ft. Hit: 9 (2d4 + 4) Slashing damage."
  - name: "Harpoon"
    desc: "Melee or Ranged Attack Roll: +6, reach 5 ft. or range 20/60 ft. Hit: 11 (2d6 + 4) Piercing damage. If the target is a Large or smaller creature, the merrow pulls the target up to 15 feet straight toward itself."
```

#Monster
