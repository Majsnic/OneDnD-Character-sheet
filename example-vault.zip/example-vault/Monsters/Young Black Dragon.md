---
Type: Dragon
CR: 7
Size: Large
tags:
  - Monster
  - Dragon
source: SRD 5.2.1
---

```statblock
name: Young Black Dragon
size: Large
type: Dragon (Chromatic)
alignment: Chaotic Evil
ac: 18
hp: 127 (15d10 + 45)
hit_dice: 15d10 + 45
speed: 40 ft., Fly 80 ft., Swim 40 ft.
stats: [19, 14, 17, 12, 11, 15]
saves:
  - Dex: +5
  - Wis: +3
skillsaves:
  - Perception: +6
  - Stealth: +5
damage_immunities: Acid
senses: Blindsight 30 ft., Darkvision 120 ft.; Passive Perception 16
languages: Common, Draconic
cr: 7
traits:
  - name: "Amphibious"
    desc: "The dragon can breathe air and water."
actions:
  - name: "Multiattack"
    desc: "The dragon makes three Rend attacks."
  - name: "Rend"
    desc: "Melee Attack Roll: +7, reach 10 ft. Hit: 9 (2d4 + 4) Slashing damage plus 3 (1d6) Acid damage."
  - name: "Acid Breath (Recharge 5–6)"
    desc: "Dexterity Saving Throw: DC 14, each creature in a 30-foot-long, 5-footwide Line. Failure: 49 (14d6) Acid damage. Success: Half damage."
```

#Monster
