---
tags:
  - Condition
source: SRD 5.2.1
---

# Blinded

You can't see, and you automatically fail any ability check that requires sight. Attack rolls against you have advantage, and your own attack rolls have disadvantage.

*Paraphrased mechanical summary, written from general knowledge of the SRD rules — treat it as a helpful draft, not a verbatim rules quote.*

#Condition
