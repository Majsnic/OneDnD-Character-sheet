---
Type: Beast
CR: 1/4
Size: Medium
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Wolf
size: Medium
type: Beast
alignment: Unaligned
ac: 12
hp: 11 (2d8 + 2)
hit_dice: 2d8 + 2
speed: 40 ft.
stats: [14, 15, 12, 3, 12, 6]
skillsaves:
  - Perception: +5
  - Stealth: +4
senses: Darkvision 60 ft.; Passive Perception 15
languages: None
cr: 1/4
traits:
  - name: "Pack Tactics"
    desc: "The wolf has Advantage on attack rolls against a creature if at least one of the wolf’s allies is within 5 feet of the creature and the ally doesn’t have the Incapacitated condition."
actions:
  - name: "Bite"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 5 (1d6 + 2) Piercing damage. If the target is a Medium or smaller creature, it has the Prone condition."
```

#Monster
