---
Type: Beast
CR: 0
Size: Tiny
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Bat
size: Tiny
type: Beast
alignment: Unaligned
ac: 12
hp: 1 (1d4 - 1)
hit_dice: 1d4 - 1
speed: 5 ft., Fly 30 ft.
stats: [2, 15, 8, 2, 12, 4]
senses: Blindsight 60 ft.; Passive Perception 11
languages: None
cr: 0
actions:
  - name: "Bite"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 1 Piercing damage."
```

#Monster
