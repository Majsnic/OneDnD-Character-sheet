---
Spell level: 1
School type: Conjuration
Casting Time: Bonus Action, which you take immediately after hitting a creature with a weapon
Components:
  - Verbal
Concentration: true
Duration: 1 minute
Range / Area: Self
Attack / Save: STR Save
Damage / Effect: 1d6 Piercing
Upscale: + 1d6
category: 1st level
---
_Level 1 Conjuration_

- **Casting time:** Bonus Action, which you take immediately after hitting a creature with a weapon
- **Range:** Self
- **Components:** V
- **Duration:** 1 minute
- **Attack/Save**: STR Save
- **Damage/Effect**: Piercing

As you hit the target, grasping vines appear on it, and it makes a Strength saving throw. A Large or larger creature has Advantage on this save. On a failed save, the target has the Restrained condition until the spell ends. On a successful save, the vines shrivel away, and the spell ends. While Restrained, the target takes 1d6 Piercing damage at the start of each of its turns. The target or a creature within reach of it can take an action to make a Strength (Athletics) check against your spell save DC. On a success, the spell ends.

**_Using a Higher-Level Spell Slot._** The damage increases by 1d6 for each spell slot level above 1.

#Spell
