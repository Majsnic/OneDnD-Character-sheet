---
Type: Monstrosity
CR: 1
Size: Large
tags:
  - Monster
  - Monstrosity
source: SRD 5.2.1
---

```statblock
name: Giant Vulture
size: Large
type: Monstrosity
alignment: Neutral Evil
ac: 10
hp: 25 (3d10 + 9)
hit_dice: 3d10 + 9
speed: 10 ft., Fly 60 ft.
stats: [15, 10, 16, 6, 12, 7]
skillsaves:
  - Perception: +3
damage_resistances: Necrotic
senses: Darkvision 60 ft.; Passive Perception 13
languages: Understands Common but can’t speak
cr: 1
traits:
  - name: "Pack Tactics"
    desc: "The vulture has Advantage on an attack roll against a creature if at least one of the vulture’s allies is within 5 feet of the creature and the ally doesn’t have the Incapacitated condition."
actions:
  - name: "Gouge"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 9 (2d6 + 2) Piercing damage, and the target has the Poisoned condition until the end of its next turn."
```

#Monster
