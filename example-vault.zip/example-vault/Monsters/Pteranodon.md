---
Type: Beast
CR: 1/4
Size: Medium
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Pteranodon
size: Medium
type: Beast (Dinosaur)
alignment: Unaligned
ac: 13
hp: 13 (3d8)
hit_dice: 3d8
speed: 10 ft., Fly 60 ft.
stats: [12, 15, 10, 2, 9, 5]
skillsaves:
  - Perception: +1
senses: Passive Perception 11
languages: None
cr: 1/4
traits:
  - name: "Flyby"
    desc: "The pteranodon doesn’t provoke an Opportunity Attack when it flies out of an enemy’s reach."
actions:
  - name: "Bite"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 6 (1d8 + 2) Piercing damage."
```

#Monster
