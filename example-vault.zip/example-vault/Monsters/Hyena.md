---
Type: Beast
CR: 0
Size: Medium
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Hyena
size: Medium
type: Beast
alignment: Unaligned
ac: 11
hp: 5 (1d8 + 1)
hit_dice: 1d8 + 1
speed: 50 ft.
stats: [11, 13, 12, 2, 12, 5]
skillsaves:
  - Perception: +3
senses: Darkvision 60 ft.; Passive Perception 13
languages: None
cr: 0
traits:
  - name: "Pack Tactics"
    desc: "The hyena has Advantage on an attack roll against a creature if at least one of the hyena’s allies is within 5 feet of the creature and the ally doesn’t have the Incapacitated condition."
actions:
  - name: "Bite"
    desc: "Melee Attack Roll: +2, reach 5 ft. Hit: 3 (1d6) Piercing damage."
```

#Monster
