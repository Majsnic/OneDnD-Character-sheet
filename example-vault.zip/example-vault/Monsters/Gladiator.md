---
Type: Humanoid
CR: 5
Size: Medium or Small
tags:
  - Monster
  - Humanoid
source: SRD 5.2.1
---

```statblock
name: Gladiator
size: Medium or Small
type: Humanoid
alignment: Neutral
ac: 16
hp: 112 (15d8 + 45)
hit_dice: 15d8 + 45
speed: 30 ft.
stats: [18, 15, 16, 10, 12, 15]
saves:
  - Str: +7
  - Dex: +5
  - Con: +6
  - Wis: +4
skillsaves:
  - Athletics: +10
  - Performance: +5
gear: Shield, Spears (3), Studded Leather Armor
senses: Passive Perception 11
languages: Common
cr: 5
actions:
  - name: "Multiattack"
    desc: "The gladiator makes three Spear attacks. It can replace one attack with a use of Shield Bash."
  - name: "Spear"
    desc: "Melee or Ranged Attack Roll: +7, reach 5 ft. or range 20/60 ft. Hit: 11 (2d6 + 4) Piercing damage."
  - name: "Shield Bash"
    desc: "Strength Saving Throw: DC 15, one creature within 5 feet that the gladiator can see. Failure: 9 (2d4 + 4) Bludgeoning damage. If the target is a Medium or smaller creature, it has the Prone condition."
reactions:
  - name: "Parry"
    desc: "Trigger: The gladiator is hit by a melee attack roll while holding a weapon. Response: The gladiator adds 3 to its AC against that attack, possibly causing it to miss."
```

#Monster
