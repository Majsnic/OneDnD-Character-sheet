---
Spell level: 1
School type: Divination
Casting Time: 1 minute or Ritual
Components:
  - Verbal
  - Somatic
  - Material
Concentration: false
Duration: Instantaneous
Range / Area: Touch
Attack / Save: None
Damage / Effect: Utility
Upscale: 
category: 1st level
---
_Level 1 Divination_

- **Casting time:** 1 minute or Ritual
- **Range:** Touch
- **Components:** V, S, M
- **Duration:** Instantaneous
- **Attack/Save**: None
- **Damage/Effect**: Utility

You touch an object throughout the spell’s casting. If the object is a magic item or some other magical object, you learn its properties and how to use them, whether it requires Attunement, and how many charges it has, if any. You learn whether any ongoing spells are affecting the item and what they are. If the item was created by a spell, you learn that spell’s name. If you instead touch a creature throughout the casting, you learn which ongoing spells, if any, are currently affecting it.

#Spell
