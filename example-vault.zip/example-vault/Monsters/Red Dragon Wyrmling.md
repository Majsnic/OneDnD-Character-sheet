---
Type: Dragon
CR: 4
Size: Medium
tags:
  - Monster
  - Dragon
source: SRD 5.2.1
---

```statblock
name: Red Dragon Wyrmling
size: Medium
type: Dragon (Chromatic)
alignment: Chaotic Evil
ac: 17
hp: 75 (10d8 + 30)
hit_dice: 10d8 + 30
speed: 30 ft., Climb 30 ft., Fly 60 ft.
stats: [19, 10, 17, 12, 11, 15]
saves:
  - Dex: +2
  - Wis: +2
skillsaves:
  - Perception: +4
  - Stealth: +2
damage_immunities: Fire
senses: Blindsight 10 ft., Darkvision 60 ft.; Passive Perception 14
languages: Draconic
cr: 4
actions:
  - name: "Multiattack"
    desc: "The dragon makes two Rend attacks."
  - name: "Rend"
    desc: "Melee Attack Roll: +6, reach 5 ft. Hit: 9 (1d10 + 4) Slashing damage plus 3 (1d6) Fire damage."
  - name: "Fire Breath (Recharge 5–6)"
    desc: "Dexterity Saving Throw: DC 13, each creature in a 15-foot Cone. Failure: 24 (7d6) Fire damage. Success: Half damage."
```

#Monster
