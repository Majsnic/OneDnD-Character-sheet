---
Type: Beast
CR: 0
Size: Tiny
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Cat
size: Tiny
type: Beast
alignment: Unaligned
ac: 12
hp: 2 (1d4)
hit_dice: 1d4
speed: 40 ft., Climb 40 ft.
stats: [3, 15, 10, 3, 12, 7]
saves:
  - Dex: +4
skillsaves:
  - Perception: +3
  - Stealth: +4
senses: Darkvision 60 ft.; Passive Perception 13
languages: None
cr: 0
traits:
  - name: "Jumper"
    desc: "The cat’s jump distance is determined using its Dexterity rather than its Strength."
actions:
  - name: "Scratch"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 1 Slashing damage."
```

#Monster
