---
tags:
  - Feat
source: SRD 5.2.1
---

# Boon of the Night Spirit

**Type:** Epic Boon Feat
**Prerequisite:** Character level 19
**Repeatable:** No

You gain Blindsight with a range of 60 feet, you don't need to breathe, and you have resistance to Necrotic damage. In addition, a number of times equal to your proficiency bonus, you can cast Invisibility on yourself without expending a spell slot or using material components. You regain all expended uses after a long rest.

*Paraphrased mechanical summary, written from general knowledge of the SRD rules — treat it as a helpful draft, not a verbatim rules quote.*

#Feat
