---
Type: Beast
CR: 1/2
Size: Large
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Crocodile
size: Large
type: Beast
alignment: Unaligned
ac: 12
hp: 13 (2d10 + 2)
hit_dice: 2d10 + 2
speed: 20 ft., Swim 30 ft.
stats: [15, 10, 13, 2, 10, 5]
saves:
  - Con: +3
skillsaves:
  - Stealth: +2
senses: Passive Perception 10
languages: None
cr: 1/2
traits:
  - name: "Hold Breath"
    desc: "The crocodile can hold its breath for 1 hour."
actions:
  - name: "Bite"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 6 (1d8 + 2) Piercing damage. If the target is a Medium or smaller creature, it has the Grappled condition (escape DC 12). While Grappled, the target has the Restrained condition."
```

#Monster
