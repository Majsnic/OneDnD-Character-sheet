---
Type: Beast
CR: 2
Size: Medium
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Swarm of Venomous Snakes
size: Medium
type: Swarm of Tiny Beasts
alignment: Unaligned
ac: 14
hp: 36 (8d8)
hit_dice: 8d8
speed: 30 ft., Swim 30 ft.
stats: [8, 18, 11, 1, 10, 3]
damage_resistances: Bludgeoning, Piercing, Slashing
condition_immunities: Charmed, Frightened, Grappled, Paralyzed, Petrified, Prone, Restrained, Stunned
senses: Blindsight 10 ft.; Passive Perception 10
languages: None
cr: 2
traits:
  - name: "Swarm"
    desc: "The swarm can occupy another creature’s space and vice versa, and the swarm can move through any opening large enough for a Tiny snake. The swarm can’t regain Hit Points or gain Temporary Hit Points."
actions:
  - name: "Bites"
    desc: "Melee Attack Roll: +6, reach 5 ft. Hit: 8 (1d8 + 4) Piercing damage—or 6 (1d4 + 4) Piercing damage if the swarm is Bloodied—plus 10 (3d6) Poison damage."
```

#Monster
