---
Type: Beast
CR: 1/4
Size: Large
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Swarm of Bats
size: Large
type: Swarm of Tiny Beasts
alignment: Unaligned
ac: 12
hp: 11 (2d10)
hit_dice: 2d10
speed: 5 ft., Fly 30 ft.
stats: [5, 15, 10, 2, 12, 4]
damage_resistances: Bludgeoning, Piercing, Slashing
condition_immunities: Charmed, Frightened, Grappled, Paralyzed, Petrified, Prone, Restrained, Stunned
senses: Blindsight 60 ft.; Passive Perception 11
languages: None
cr: 1/4
traits:
  - name: "Swarm"
    desc: "The swarm can occupy another creature’s space and vice versa, and the swarm can move through any opening large enough for a Tiny bat. The swarm can’t regain Hit Points or gain Temporary Hit Points."
actions:
  - name: "Bites"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 5 (2d4) Piercing damage, or 2 (1d4) Piercing damage if the swarm is Bloodied."
```

#Monster
