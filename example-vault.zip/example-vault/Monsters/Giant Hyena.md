---
Type: Beast
CR: 1
Size: Large
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Giant Hyena
size: Large
type: Beast
alignment: Unaligned
ac: 12
hp: 45 (6d10 + 12)
hit_dice: 6d10 + 12
speed: 50 ft.
stats: [16, 14, 14, 2, 12, 7]
skillsaves:
  - Perception: +3
senses: Darkvision 60 ft.; Passive Perception 13
languages: None
cr: 1
actions:
  - name: "Bite"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 10 (2d6 + 3) Piercing damage."
bonusactions:
  - name: "Rampage (1/Day)"
    desc: "Immediately after dealing damage to a creature that was already Bloodied, the hyena can move up to half its Speed, and it makes one Bite attack."
```

#Monster
