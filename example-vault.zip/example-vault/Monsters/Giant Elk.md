---
Type: Celestial
CR: 2
Size: Huge
tags:
  - Monster
  - Celestial
source: SRD 5.2.1
---

```statblock
name: Giant Elk
size: Huge
type: Celestial
alignment: Neutral Good
ac: 14
hp: 42 (5d12 + 10)
hit_dice: 5d12 + 10
speed: 60 ft.
stats: [19, 18, 14, 7, 14, 10]
saves:
  - Str: +6
  - Dex: +6
skillsaves:
  - Perception: +4
damage_resistances: Necrotic, Radiant
senses: Darkvision 90 ft.; Passive Perception 14
languages: Celestial; understands Common, Elvish, and Sylvan but can’t speak them
cr: 2
actions:
  - name: "Ram"
    desc: "Melee Attack Roll: +6, reach 10 ft. Hit: 11 (2d6 + 4) Bludgeoning damage plus 5 (2d4) Radiant damage. If the target is a Huge or smaller creature and the elk moved 20+ feet straight toward it immediately before the hit, the target takes an extra 5 (2d4) Bludgeoning damage and has the Prone condition."
```

#Monster
