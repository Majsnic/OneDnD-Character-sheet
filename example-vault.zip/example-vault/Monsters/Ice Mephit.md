---
Type: Elemental
CR: 1/2
Size: Small
tags:
  - Monster
  - Elemental
source: SRD 5.2.1
---

```statblock
name: Ice Mephit
size: Small
type: Elemental
alignment: Neutral Evil
ac: 11
hp: 21 (6d6)
hit_dice: 6d6
speed: 30 ft., Fly 30 ft.
stats: [7, 13, 10, 9, 11, 12]
skillsaves:
  - Perception: +2
  - Stealth: +3
damage_vulnerabilities: Fire
damage_immunities: Cold, Poison
condition_immunities: Exhaustion, Poisoned
senses: Darkvision 60 ft.; Passive Perception 12
languages: Primordial (Aquan, Auran)
cr: 1/2
traits:
  - name: "Death Burst"
    desc: "The mephit explodes when it dies. Constitution Saving Throw: DC 10, each creature in a 5-foot Emanation originating from the mephit. Failure: 5 (2d4) Cold damage. Success: Half damage."
actions:
  - name: "Claw"
    desc: "Melee Attack Roll: +3, reach 5 ft. Hit: 3 (1d4 + 1) Slashing damage plus 2 (1d4) Cold damage."
  - name: "Fog Cloud (1/Day)"
    desc: "The mephit casts Fog Cloud, requiring no spell components and using Charisma as the spellcasting ability."
  - name: "Frost Breath (Recharge 6)"
    desc: "Constitution Saving Throw: DC 10, each creature in a 15-foot Cone. Failure: 7 (3d4) Cold damage. Success: Half damage."
```

#Monster
