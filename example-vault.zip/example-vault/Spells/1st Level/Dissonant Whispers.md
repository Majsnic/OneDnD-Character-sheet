---
Spell level: 1
School type: Enchantment
Casting Time: Action
Components:
  - Verbal
Concentration: false
Duration: Instantaneous
Range / Area: 60 feet
Attack / Save: WIS Save
Damage / Effect: 3d6 Psychic
Upscale: + 1d6
category: 1st level
---
_Level 1 Enchantment_

- **Casting time:** Action
- **Range:** 60 feet
- **Components:** V
- **Duration:** Instantaneous
- **Attack/Save**: WIS Save
- **Damage/Effect**: Psychic

One creature of your choice that you can see within range hears a discordant melody in its mind. The target makes a Wisdom saving throw. On a failed save, it takes 3d6 Psychic damage and must immediately use its Reaction, if available, to move as far away from you as it can, using the safest route. On a successful save, the target takes half as much damage only.

**_Using a Higher-Level Spell Slot._** The damage increases by 1d6 for each spell slot level above 1.

#Spell
