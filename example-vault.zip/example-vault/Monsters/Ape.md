---
Type: Beast
CR: 1/2
Size: Medium
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Ape
size: Medium
type: Beast
alignment: Unaligned
ac: 12
hp: 19 (3d8 + 6)
hit_dice: 3d8 + 6
speed: 30 ft., Climb 30 ft.
stats: [16, 14, 14, 6, 12, 7]
skillsaves:
  - Athletics: +5
  - Perception: +3
senses: Passive Perception 13
languages: None
cr: 1/2
actions:
  - name: "Multiattack"
    desc: "The ape makes two Fist attacks."
  - name: "Fist"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 5 (1d4 + 3) Bludgeoning damage."
  - name: "Rock (Recharge 6)"
    desc: "Ranged Attack Roll: +5, range 25/50 ft. Hit: 10 (2d6 + 3) Bludgeoning damage."
```

#Monster
