---
Spell level: 3
School type: Evocation
Casting Time: Action
Components:
  - Verbal
  - Somatic
  - Material
Concentration: false
Duration: Instantaneous
Range / Area: Self
Attack / Save: DEX Save
Damage / Effect: 8d6 Lightning
Upscale: + 1d6
category: 3rd level
---
_Level 3 Evocation_

- **Casting time:** Action
- **Range:** Self
- **Components:** V, S, M
- **Duration:** Instantaneous
- **Attack/Save**: DEX Save
- **Damage/Effect**: Lightning

A stroke of lightning forming a 100-foot-long, 5-foot-wide Line blasts out from you in a direction you choose. Each creature in the Line makes a Dexterity saving throw, taking 8d6 Lightning damage on a failed save or half as much damage on a successful one.

**_Using a Higher-Level Spell Slot._** The damage increases by 1d6 for each spell slot level above 3.

#Spell
