---
Type: Monstrosity
CR: 3
Size: Large
tags:
  - Monster
  - Monstrosity
source: SRD 5.2.1
---

```statblock
name: Minotaur of Baphomet
size: Large
type: Monstrosity
alignment: Chaotic Evil
ac: 14
hp: 85 (10d10 + 30)
hit_dice: 10d10 + 30
speed: 40 ft.
stats: [18, 11, 16, 6, 16, 9]
skillsaves:
  - Perception: +7
  - Survival: +7
senses: Darkvision 60 ft.; Passive Perception 17
languages: Abyssal
cr: 3
actions:
  - name: "Abyssal Glaive"
    desc: "Melee Attack Roll: +6, reach 10 ft. Hit: 10 (1d12 + 4) Slashing damage plus 10 (3d6) Necrotic damage."
  - name: "Gore (Recharge 5–6)"
    desc: "Melee Attack Roll: +6, reach 5 ft. Hit: 18 (4d6 + 4) Piercing damage. If the target is a Large or smaller creature and the minotaur moved 10+ feet straight toward it immediately before the hit, the target takes an extra 10 (3d6) Piercing damage and has the Prone condition."
```

#Monster
