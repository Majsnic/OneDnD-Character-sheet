---
Rarity: Very Rare
type: object
tags:
  - Item
  - item/very-rare
  - item/weapon
item_category: Weapon
item_base: "Shortsword"
weapon_category: "Martial Melee"
damage_dice: "1d6"
damage_type: Piercing
weapon_properties: [Finesse, Light]
weapon_mastery: Vex
requires_attunement: false
attunement_note: ""
attack_bonus: 3
damage_bonus: 3
---


###### +3 Shortsword
_Weapon (shortsword), very rare_<span class="sub2">:FasWandMagicSparkles: Magic Item</span>
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>You have a +3 bonus to attack and damage rolls made with this magic weapon.
>
>**1d6+3 Piercing damage.** Properties: Finesse, Light.
>
>- **Finesse.** You can use your Strength or Dexterity modifier for attack and damage rolls with this weapon.
>- **Light.** You can make an extra attack with a second Light weapon as a Bonus Action (Two-Weapon Fighting) without adding your ability modifier to the extra attack's damage unless it's negative.
>
>**_Vex (Mastery)._** If you hit a creature with this weapon and deal damage to it, you can give yourself Advantage on your next attack roll against that creature before the end of your next turn.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
