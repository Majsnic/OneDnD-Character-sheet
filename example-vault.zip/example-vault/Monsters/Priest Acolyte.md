---
Type: Humanoid
CR: 1/4
Size: Medium or Small
tags:
  - Monster
  - Humanoid
source: SRD 5.2.1
---

```statblock
name: Priest Acolyte
size: Medium or Small
type: Humanoid (Cleric)
alignment: Neutral
ac: 13
hp: 11 (2d8 + 2)
hit_dice: 2d8 + 2
speed: 30 ft.
stats: [14, 10, 12, 10, 14, 11]
skillsaves:
  - Medicine: +4
  - Religion: +2
gear: Chain Shirt, Holy Symbol, Mace
senses: Passive Perception 12
languages: Common
cr: 1/4
actions:
  - name: "Mace"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 5 (1d6 + 2) Bludgeoning damage plus 2 (1d4) Radiant damage."
  - name: "Radiant Flame"
    desc: "Ranged Attack Roll: +4, range 60 ft. Hit: 7 (2d6) Radiant damage."
  - name: "Spellcasting"
    desc: "The priest casts one of the following spells, using Wisdom as the spellcasting ability: At Will: Light, Thaumaturgy"
bonusactions:
  - name: "Divine Aid (1/Day)"
    desc: "The priest casts Bless, Healing Word, or Sanctuary, using the same spellcasting ability as Spellcasting."
```

#Monster
