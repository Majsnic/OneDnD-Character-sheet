---
tags:
  - Condition
source: SRD 5.2.1
---

# Stunned

You are Incapacitated, can't move, and can speak only falteringly. You automatically fail Strength and Dexterity saving throws, and attack rolls against you have advantage.

*Paraphrased mechanical summary, written from general knowledge of the SRD rules — treat it as a helpful draft, not a verbatim rules quote.*

#Condition
