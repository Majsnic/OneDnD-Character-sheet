---
Spell level: 3
School type: Transmutation
Casting Time: Action
Components:
  - Verbal
  - Somatic
  - Material
Concentration: true
Duration: 10 minutes
Range / Area: Touch
Attack / Save: None
Damage / Effect: Utility
Upscale: + 1 creature
category: 3rd level
---
_Level 3 Transmutation_

- **Casting time:** Action
- **Range:** Touch
- **Components:** V, S, M
- **Duration:** 10 minutes
- **Attack/Save**: None
- **Damage/Effect**: Utility

You touch a willing creature. For the duration, the target gains a Fly Speed of 60 feet and can hover. When the spell ends, the target falls if it is still aloft unless it can stop the fall.

**_Using a Higher-Level Spell Slot._** You can target one additional creature for each spell slot level above 3.

#Spell
