---
Type: Ooze
CR: 1/2
Size: Medium
tags:
  - Monster
  - Ooze
source: SRD 5.2.1
---

```statblock
name: Gray Ooze
size: Medium
type: Ooze
alignment: Unaligned
ac: 9
hp: 22 (3d8 + 9)
hit_dice: 3d8 + 9
speed: 10 ft., Climb 10 ft.
stats: [12, 6, 16, 1, 6, 2]
skillsaves:
  - Stealth: +2
damage_resistances: Acid, Cold, Fire
condition_immunities: Blinded, Charmed, Deafened, Exhaustion, Frightened, Grappled, Prone, Restrained
senses: Blindsight 60 ft.; Passive Perception 8
languages: None
cr: 1/2
traits:
  - name: "Amorphous"
    desc: "The ooze can move through a space as narrow as 1 inch without expending extra movement to do so."
  - name: "Corrosive Form"
    desc: "Nonmagical ammunition is destroyed immediately after hitting the ooze and dealing any damage. Any nonmagical weapon takes a cumulative -1 penalty to attack rolls immediately after dealing damage to the ooze and coming into contact with it. The weapon is destroyed if the penalty reaches -5. The penalty can be removed by casting the Mending spell on the weapon. The ooze can eat through 2-inch-thick, nonmagical metal or wood in 1 round."
actions:
  - name: "Pseudopod"
    desc: "Melee Attack Roll: +3, reach 5 ft. Hit: 10 (2d8 + 1) Acid damage. Nonmagical armor worn by the target takes a -1 penalty to the AC it offers. The armor is destroyed if the penalty reduces its AC to 10. The penalty can be removed by casting the Mending spell on the armor."
```

#Monster
