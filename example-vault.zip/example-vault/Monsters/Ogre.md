---
Type: Giant
CR: 2
Size: Large
tags:
  - Monster
  - Giant
source: SRD 5.2.1
---

```statblock
name: Ogre
size: Large
type: Giant
alignment: Chaotic Evil
ac: 11
hp: 68 (8d10 + 24)
hit_dice: 8d10 + 24
speed: 40 ft.
stats: [19, 8, 16, 5, 7, 7]
gear: Greatclub, Javelins (3)
senses: Darkvision 60 ft.; Passive Perception 8
languages: Common, Giant
cr: 2
actions:
  - name: "Greatclub"
    desc: "Melee Attack Roll: +6, reach 5 ft. Hit: 13 (2d8 + 4) Bludgeoning damage."
  - name: "Javelin"
    desc: "Melee or Ranged Attack Roll: +6, reach 5 ft. or range 30/120 ft. Hit: 11 (2d6 + 4) Piercing damage."
```

#Monster
