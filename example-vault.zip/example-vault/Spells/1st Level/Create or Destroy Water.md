---
Spell level: 1
School type: Transmutation
Casting Time: Action
Components:
  - Verbal
  - Somatic
  - Material
Concentration: false
Duration: Instantaneous
Range / Area: 30 feet
Attack / Save: None
Damage / Effect: Utility
Upscale: + 5 feet
category: 1st level
---
_Level 1 Transmutation_

- **Casting time:** Action
- **Range:** 30 feet
- **Components:** V, S, M
- **Duration:** Instantaneous
- **Attack/Save**: None
- **Damage/Effect**: Utility

You do one of the following: Create Water. You create up to 10 gallons of clean water within range in an open container. Alternatively, the water falls as rain in a 30-foot Cube within range, extinguishing exposed flames there. Destroy Water. You destroy up to 10 gallons of water in an open container within range. Alternatively, you destroy fog in a 30-foot Cube within range.

**_Using a Higher-Level Spell Slot._** You create or destroy 10 additional gallons of water, or the size of the Cube increases by 5 feet, for each spell slot level above 1.

#Spell
