---
tags:
  - Feat
source: SRD 5.2.1
---

# Ability Score Improvement

**Type:** General Feat
**Repeatable:** Yes
**Ability Score Increase:** Increase one ability score of your choice by 2, or two ability scores of your choice by 1 each. An ability score can't be increased above 20 this way.

You can further tailor your capabilities as you grow in experience.

*Paraphrased mechanical summary, written from general knowledge of the SRD rules — treat it as a helpful draft, not a verbatim rules quote.*

#Feat
