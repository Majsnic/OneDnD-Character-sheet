---
Type: Giant
CR: 9
Size: Huge
tags:
  - Monster
  - Giant
source: SRD 5.2.1
---

```statblock
name: Cloud Giant
size: Huge
type: Giant
alignment: Neutral
ac: 14
hp: 200 (16d12 + 96)
hit_dice: 16d12 + 96
speed: 40 ft., Fly 20 ft. (hover)
stats: [27, 10, 22, 12, 16, 16]
saves:
  - Con: +10
  - Wis: +7
skillsaves:
  - Insight: +7
  - Perception: +11
senses: Passive Perception 21
languages: Common, Giant
cr: 9
actions:
  - name: "Multiattack"
    desc: "The giant makes two attacks, using Thunderous Mace or Thundercloud in any combination. It can replace one attack with a use of Spellcasting to cast Fog Cloud."
  - name: "Thunderous Mace"
    desc: "Melee Attack Roll: +12, reach 10 ft. Hit: 21 (3d8 + 8) Bludgeoning damage plus 7 (2d6) Thunder damage."
  - name: "Thundercloud"
    desc: "Ranged Attack Roll: +12, range 240 ft. Hit: 18 (3d6 + 8) Thunder damage, and the target has the Incapacitated condition until the end of its next turn."
  - name: "Spellcasting"
    desc: "The giant casts one of the following spells, requiring no Material components and using Charisma as the spellcasting ability (spell save DC 15): At Will: Detect Magic, Fog Cloud, Light 1/Day Each: Control Weather, Gaseous Form, Telekinesis"
bonusactions:
  - name: "Misty Step"
    desc: "The giant casts the Misty Step spell, using the same spellcasting ability as Spellcasting."
```

#Monster
