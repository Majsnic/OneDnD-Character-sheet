---
Spell level: 6
School type: Conjuration
Casting Time: 10 minutes
Components:
  - Verbal
  - Somatic
  - Material
Concentration: false
Duration: Instantaneous
Range / Area: Self
Attack / Save: None
Damage / Effect: Poisoned
Upscale: 
category: 6th level
---
_Level 6 Conjuration_

- **Casting time:** 10 minutes
- **Range:** Self
- **Components:** V, S, M
- **Duration:** Instantaneous
- **Attack/Save**: None
- **Damage/Effect**: Poisoned

You conjure a feast that appears on a surface in an unoccupied 10-foot Cube next to you. The feast takes 1 hour to consume and disappears at the end of that time, and the beneficial effects don’t set in until this hour is over. Up to twelve creatures can partake of the feast. A creature that partakes gains several benefits, which last for 24 hours. The creature has Resistance to Poison damage, and it has Immunity to the Frightened and Poisoned conditions. Its Hit Point maximum also increases by 2d10, and it gains the same number of Hit Points.

#Spell
