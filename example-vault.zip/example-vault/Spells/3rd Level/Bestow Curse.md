---
Spell level: 3
School type: Necromancy
Casting Time: Action
Components:
  - Verbal
  - Somatic
Concentration: true
Duration: 1 minute
Range / Area: Touch
Attack / Save: WIS Save
Damage / Effect: 1d8 Necrotic
Upscale: 
category: 3rd level
---
_Level 3 Necromancy_

- **Casting time:** Action
- **Range:** Touch
- **Components:** V, S
- **Duration:** 1 minute
- **Attack/Save**: WIS Save
- **Damage/Effect**: Necrotic

You touch a creature, which must succeed on a Wisdom saving throw or become cursed for the duration. Until the curse ends, the target suffers one of the following effects of your choice:

- Choose one ability. The target has Disadvantage on ability checks and saving throws made with that ability.
- The target has Disadvantage on attack rolls against you.
- In combat, the target must succeed on a Wisdom saving throw at the start of each of its turns or be forced to take the Dodge action on that turn.
- If you deal damage to the target with an attack roll or a spell, the target takes an extra 1d8 Necrotic damage.

**_Using a Higher-Level Spell Slot._** If you cast this spell using a level 4 spell slot, you can maintain Concentration on it for up to 10 minutes. If you use a level 5+ spell slot, the spell doesn’t require Concentration, and the duration becomes 8 hours (level 5–6 slot) or 24 hours (level 7–8 slot). If you use a level 9 spell slot, the spell lasts until dispelled.

#Spell
