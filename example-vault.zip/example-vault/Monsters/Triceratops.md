---
Type: Beast
CR: 5
Size: Huge
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Triceratops
size: Huge
type: Beast (Dinosaur)
alignment: Unaligned
ac: 14
hp: 114 (12d12 + 36)
hit_dice: 12d12 + 36
speed: 50 ft.
stats: [22, 9, 17, 2, 11, 5]
senses: Passive Perception 10
languages: None
cr: 5
actions:
  - name: "Multiattack"
    desc: "The triceratops makes two Gore attacks."
  - name: "Gore"
    desc: "Melee Attack Roll: +9, reach 5 ft. Hit: 19 (2d12 + 6) Piercing damage. If the target is Huge or smaller and the triceratops moved 20+ feet straight toward it immediately before the hit, the target takes an extra 9 (2d8) Piercing damage and has the Prone condition."
```

#Monster
