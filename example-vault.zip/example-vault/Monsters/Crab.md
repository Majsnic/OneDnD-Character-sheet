---
Type: Beast
CR: 0
Size: Tiny
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Crab
size: Tiny
type: Beast
alignment: Unaligned
ac: 11
hp: 3 (1d4 + 1)
hit_dice: 1d4 + 1
speed: 20 ft., Swim 20 ft.
stats: [6, 11, 12, 1, 8, 2]
skillsaves:
  - Stealth: +2
senses: Blindsight 30 ft.; Passive Perception 9
languages: None
cr: 0
traits:
  - name: "Amphibious"
    desc: "The crab can breathe air and water."
actions:
  - name: "Claw"
    desc: "Melee Attack Roll: +2, reach 5 ft. Hit: 1 Bludgeoning damage."
```

#Monster
