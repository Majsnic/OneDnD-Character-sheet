---
Type: Aberration
CR: 1/4
Size: Medium
tags:
  - Monster
  - Aberration
source: SRD 5.2.1
---

```statblock
name: Grimlock
size: Medium
type: Aberration
alignment: Neutral Evil
ac: 11
hp: 11 (2d8 + 2)
hit_dice: 2d8 + 2
speed: 30 ft., Climb 30 ft.
stats: [16, 12, 12, 9, 8, 6]
skillsaves:
  - Athletics: +5
  - Perception: +3
  - Stealth: +5
senses: Blindsight 30 ft.; Passive Perception 13
languages: None
cr: 1/4
actions:
  - name: "Bone Cudgel"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 6 (1d6 + 3) Bludgeoning damage plus 2 (1d4) Psychic damage."
```

#Monster
