---
Type: Humanoid
CR: 2
Size: Medium or Small
tags:
  - Monster
  - Humanoid
source: SRD 5.2.1
---

```statblock
name: Bandit Captain
size: Medium or Small
type: Humanoid
alignment: Neutral
ac: 15
hp: 52 (8d8 + 16)
hit_dice: 8d8 + 16
speed: 30 ft.
stats: [15, 16, 14, 14, 11, 14]
saves:
  - Str: +4
  - Dex: +5
  - Wis: +2
skillsaves:
  - Athletics: +4
  - Deception: +4
gear: Pistol, Scimitar, Studded Leather Armor
senses: Passive Perception 10
languages: Common, Thieves’ Cant
cr: 2
actions:
  - name: "Multiattack"
    desc: "The bandit makes two attacks, using Scimitar and Pistol in any combination."
  - name: "Scimitar"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 6 (1d6 + 3) Slashing damage."
  - name: "Pistol"
    desc: "Ranged Attack Roll: +5, range 30/90 ft. Hit: 8 (1d10 + 3) Piercing damage."
reactions:
  - name: "Parry"
    desc: "Trigger: The bandit is hit by a melee attack roll while holding a weapon. Response: The bandit adds 2 to its AC against that attack, possibly causing it to miss."
```

#Monster
