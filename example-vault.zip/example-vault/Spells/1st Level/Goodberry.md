---
Spell level: 1
School type: Conjuration
Casting Time: Action
Components:
  - Verbal
  - Somatic
  - Material
Concentration: false
Duration: 24 hours
Range / Area: Self
Attack / Save: None
Damage / Effect: Utility
Upscale: 
category: 1st level
---
_Level 1 Conjuration_

- **Casting time:** Action
- **Range:** Self
- **Components:** V, S, M
- **Duration:** 24 hours
- **Attack/Save**: None
- **Damage/Effect**: Utility

Ten berries appear in your hand and are infused with magic for the duration. A creature can take a Bonus Action to eat one berry. Eating a berry restores 1 Hit Point, and the berry provides enough nourishment to sustain a creature for one day. Uneaten berries disappear when the spell ends.

#Spell
