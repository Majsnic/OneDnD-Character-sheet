---
Type: Beast
CR: 0
Size: Tiny
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Owl
size: Tiny
type: Beast
alignment: Unaligned
ac: 11
hp: 1 (1d4 - 1)
hit_dice: 1d4 - 1
speed: 5 ft., Fly 60 ft.
stats: [3, 13, 8, 2, 12, 7]
skillsaves:
  - Perception: +5
  - Stealth: +5
senses: Darkvision 120 ft.; Passive Perception 15
languages: None
cr: 0
traits:
  - name: "Flyby"
    desc: "The owl doesn’t provoke an Opportunity Attack when it flies out of an enemy’s reach."
actions:
  - name: "Talons"
    desc: "Melee Attack Roll: +3, reach 5 ft. Hit: 1 Slashing damage."
```

#Monster
