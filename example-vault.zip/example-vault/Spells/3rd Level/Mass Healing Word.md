---
Spell level: 3
School type: Abjuration
Casting Time: Bonus Action
Components:
  - Verbal
Concentration: false
Duration: Instantaneous
Range / Area: 60 feet
Attack / Save: None
Damage / Effect: 2d4 Healing + spellcasting ability modifier
Upscale: + 1d4
category: 3rd level
---
_Level 3 Abjuration_

- **Casting time:** Bonus Action
- **Range:** 60 feet
- **Components:** V
- **Duration:** Instantaneous
- **Attack/Save**: None
- **Damage/Effect**: Healing

Up to six creatures of your choice that you can see within range regain Hit Points equal to 2d4 plus your spellcasting ability modifier.

**_Using a Higher-Level Spell Slot._** The healing increases by 1d4 for each spell slot level above 3.

#Spell
