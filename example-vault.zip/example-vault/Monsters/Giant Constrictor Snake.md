---
Type: Beast
CR: 2
Size: Huge
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Giant Constrictor Snake
size: Huge
type: Beast
alignment: Unaligned
ac: 12
hp: 60 (8d12 + 8)
hit_dice: 8d12 + 8
speed: 30 ft., Swim 30 ft.
stats: [19, 14, 12, 1, 10, 3]
skillsaves:
  - Perception: +2
senses: Blindsight 10 ft.; Passive Perception 12
languages: None
cr: 2
actions:
  - name: "Multiattack"
    desc: "The snake makes one Bite attack and uses Constrict."
  - name: "Bite"
    desc: "Melee Attack Roll: +6, reach 10 ft. Hit: 11 (2d6 + 4) Piercing damage."
  - name: "Constrict"
    desc: "Strength Saving Throw: DC 14, one Large or smaller creature the snake can see within 10 feet. Failure: 13 (2d8 + 4) Bludgeoning damage, and the target has the Grappled condition (escape DC 14)."
```

#Monster
