---
Type: Beast
CR: 1/4
Size: Medium
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Panther
size: Medium
type: Beast
alignment: Unaligned
ac: 13
hp: 13 (3d8)
hit_dice: 3d8
speed: 50 ft., Climb 40 ft.
stats: [14, 16, 10, 3, 14, 7]
skillsaves:
  - Perception: +4
  - Stealth: +7
senses: Darkvision 60 ft.; Passive Perception 14
languages: None
cr: 1/4
actions:
  - name: "Rend"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 6 (1d6 + 3) Slashing damage."
bonusactions:
  - name: "Nimble Escape"
    desc: "The panther takes the Disengage or Hide action."
```

#Monster
