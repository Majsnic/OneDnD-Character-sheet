---
Type: Beast
CR: 1/4
Size: Large
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Constrictor Snake
size: Large
type: Beast
alignment: Unaligned
ac: 13
hp: 13 (2d10 + 2)
hit_dice: 2d10 + 2
speed: 30 ft., Swim 30 ft.
stats: [15, 14, 12, 1, 10, 3]
skillsaves:
  - Perception: +2
  - Stealth: +4
senses: Blindsight 10 ft.; Passive Perception 12
languages: None
cr: 1/4
actions:
  - name: "Bite"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 6 (1d8 + 2) Piercing damage."
  - name: "Constrict"
    desc: "Strength Saving Throw: DC 12, one Medium or smaller creature the snake can see within 5 feet. Failure: 7 (3d4) Bludgeoning damage, and the target has the Grappled condition (escape DC 12)."
```

#Monster
