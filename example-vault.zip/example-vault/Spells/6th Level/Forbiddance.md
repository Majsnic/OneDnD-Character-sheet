---
Spell level: 6
School type: Abjuration
Casting Time: 10 minutes or Ritual
Components:
  - Verbal
  - Somatic
  - Material
Concentration: false
Duration: 1 day
Range / Area: Touch
Attack / Save: None
Damage / Effect: Utility
Upscale: 
category: 6th level
---
_Level 6 Abjuration_

- **Casting time:** 10 minutes or Ritual
- **Range:** Touch
- **Components:** V, S, M
- **Duration:** 1 day
- **Attack/Save**: None
- **Damage/Effect**: Utility

You create a ward against magical travel that protects up to 40,000 square feet of floor space to a height of 30 feet above the floor. For the duration, creatures can’t teleport into the area or use portals, such as those created by the Gate spell, to enter the area. The spell proofs the area against planar travel, and therefore prevents creatures from accessing the area by way of the Astral Plane, the Ethereal Plane, the Feywild, the Shadowfell, or the Plane Shift spell. In addition, the spell damages types of creatures that you choose when you cast it. Choose one or more of the following: Aberrations, Celestials, Elementals, Fey, Fiends, and Undead. When a creature of a chosen type enters the spell’s area for the first time on a turn or ends its turn there, the creature takes 5d10 Radiant or Necrotic damage (your choice when you cast this spell). You can designate a password when you cast the spell. A creature that speaks the password as it enters the area takes no damage from the spell. The spell’s area can’t overlap with the area of another Forbiddance spell. If you cast Forbiddance every day for 30 days in the same location, the spell lasts until it is dispelled, and the Material components are consumed on the last casting.

#Spell
