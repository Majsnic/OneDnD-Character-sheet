---
Spell level: 1
School type: Enchantment
Casting Time: Bonus Action
Components:
  - Verbal
  - Somatic
  - Material
Concentration: true
Duration: 1 hour
Range / Area: 90 feet
Attack / Save: Auto-hit
Damage / Effect: 1d6 Necrotic
Upscale: 
category: 1st level
---
_Level 1 Enchantment_

- **Casting time:** Bonus Action
- **Range:** 90 feet
- **Components:** V, S, M
- **Duration:** 1 hour
- **Attack/Save**: Auto-hit
- **Damage/Effect**: Necrotic

You place a curse on a creature that you can see within range. Until the spell ends, you deal an extra 1d6 Necrotic damage to the target whenever you hit it with an attack roll. Also, choose one ability when you cast the spell. The target has Disadvantage on ability checks made with the chosen ability. If the target drops to 0 Hit Points before this spell ends, you can take a Bonus Action on a later turn to curse a new creature.

**_Using a Higher-Level Spell Slot._** Your Concentration can last longer with a spell slot of level 2 (up to 4 hours), 3–4 (up to 8 hours), or 5+ (24 hours).

#Spell
