---
Type: Monstrosity
CR: 3
Size: Large
tags:
  - Monster
  - Monstrosity
source: SRD 5.2.1
---

```statblock
name: Manticore
size: Large
type: Monstrosity
alignment: Lawful Evil
ac: 14
hp: 68 (8d10 + 24)
hit_dice: 8d10 + 24
speed: 30 ft., Fly 50 ft.
stats: [17, 16, 17, 7, 12, 8]
senses: Darkvision 60 ft.; Passive Perception 11
languages: Common
cr: 3
actions:
  - name: "Multiattack"
    desc: "The manticore makes three attacks, using Rend or Tail Spike in any combination."
  - name: "Rend"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 7 (1d8 + 3) Slashing damage."
  - name: "Tail Spike"
    desc: "Ranged Attack Roll: +5, range 100/200 ft. Hit: 7 (1d8 + 3) Piercing damage."
```

#Monster
