---
Type: Dragon
CR: 1
Size: Medium
tags:
  - Monster
  - Dragon
source: SRD 5.2.1
---

```statblock
name: Copper Dragon Wyrmling
size: Medium
type: Dragon (Metallic)
alignment: Chaotic Good
ac: 16
hp: 22 (4d8 + 4)
hit_dice: 4d8 + 4
speed: 30 ft., Climb 30 ft., Fly 60 ft.
stats: [15, 12, 13, 14, 11, 13]
saves:
  - Dex: +3
  - Wis: +2
skillsaves:
  - Perception: +4
  - Stealth: +3
damage_immunities: Acid
senses: Blindsight 10 ft., Darkvision 60 ft.; Passive Perception 14
languages: Draconic
cr: 1
actions:
  - name: "Rend"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 7 (1d10 + 2) Slashing damage."
  - name: "Acid Breath (Recharge 5–6)"
    desc: "Dexterity Saving Throw: DC 11, each creature in a 20-foot-long, 5-footwide Line. Failure: 18 (4d8) Acid damage. Success: Half damage."
  - name: "Slowing Breath"
    desc: "Constitution Saving Throw: DC 11, each creature in a 15-foot Cone. Failure: The target can’t take Reactions; its Speed is halved; and it can take either an action or a Bonus Action on its turn, not both. This effect lasts until the end of its next turn."
```

#Monster
