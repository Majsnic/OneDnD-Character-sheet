---
type: object
tags:
  - Item
  - item/common
  - item/weapon
item_category: Weapon
weapon_category: "Simple Ranged"
damage_dice: "1d6"
damage_type: Piercing
weapon_properties: [Ammunition, Two-Handed]
range_normal: 80
range_long: 320
attack_bonus: 0
damage_bonus: 0
cost: "25 GP"
weight_lb: 2
---


###### Shortbow
_Simple Ranged Weapon_
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>**1d6 Piercing damage.** Range 80/320 ft. Properties: Two-Handed. Cost 25 GP, weight 2 lb.
>
>- **Ammunition.** You can use a weapon that has the Ammunition property to make a ranged attack only if you have ammunition to fire from it.
>- **Two-Handed.** You must use two hands to attack with this weapon.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
