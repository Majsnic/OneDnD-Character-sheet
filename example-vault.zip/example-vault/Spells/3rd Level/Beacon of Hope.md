---
Spell level: 3
School type: Abjuration
Casting Time: Action
Components:
  - Verbal
  - Somatic
Concentration: true
Duration: 1 minute
Range / Area: 30 feet
Attack / Save: None
Damage / Effect: Utility
Upscale: 
category: 3rd level
---
_Level 3 Abjuration_

- **Casting time:** Action
- **Range:** 30 feet
- **Components:** V, S
- **Duration:** 1 minute
- **Attack/Save**: None
- **Damage/Effect**: Utility

Choose any number of creatures within range. For the duration, each target has Advantage on Wisdom saving throws and Death Saving Throws and regains the maximum number of Hit Points possible from any healing.

#Spell
