---
Type: Plant
CR: 2
Size: Huge
tags:
  - Monster
  - Plant
source: SRD 5.2.1
---

```statblock
name: Awakened Tree
size: Huge
type: Plant
alignment: Neutral
ac: 13
hp: 59 (7d12 + 14)
hit_dice: 7d12 + 14
speed: 20 ft.
stats: [19, 6, 15, 10, 10, 7]
damage_vulnerabilities: Fire
damage_resistances: Bludgeoning, Piercing
senses: Passive Perception 10
languages: Common plus one other language
cr: 2
actions:
  - name: "Slam"
    desc: "Melee Attack Roll: +6, reach 10 ft. Hit: 14 (3d6 + 4) Bludgeoning damage."
```

#Monster
