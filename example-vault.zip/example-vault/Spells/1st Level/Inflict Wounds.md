---
Spell level: 1
School type: Necromancy
Casting Time: Action
Components:
  - Verbal
  - Somatic
Concentration: false
Duration: Instantaneous
Range / Area: Touch
Attack / Save: CON Save
Damage / Effect: 2d10 Necrotic
Upscale: + 1d10
category: 1st level
---
_Level 1 Necromancy_

- **Casting time:** Action
- **Range:** Touch
- **Components:** V, S
- **Duration:** Instantaneous
- **Attack/Save**: CON Save
- **Damage/Effect**: Necrotic

A creature you touch makes a Constitution saving throw, taking 2d10 Necrotic damage on a failed save or half as much damage on a successful one.

**_Using a Higher-Level Spell Slot._** The damage increases by 1d10 for each spell slot level above 1.

#Spell
