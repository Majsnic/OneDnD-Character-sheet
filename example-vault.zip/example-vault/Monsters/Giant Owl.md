---
Type: Celestial
CR: 1/4
Size: Large
tags:
  - Monster
  - Celestial
source: SRD 5.2.1
---

```statblock
name: Giant Owl
size: Large
type: Celestial
alignment: Neutral
ac: 12
hp: 19 (3d10 + 3)
hit_dice: 3d10 + 3
speed: 5 ft., Fly 60 ft.
stats: [13, 15, 12, 10, 14, 10]
saves:
  - Wis: +4
skillsaves:
  - Perception: +6
  - Stealth: +6
damage_resistances: Necrotic, Radiant
senses: Darkvision 120 ft.; Passive Perception 16
languages: Celestial; understands Common, Elvish, and Sylvan but can’t speak them
cr: 1/4
traits:
  - name: "Flyby"
    desc: "The owl doesn’t provoke an Opportunity Attack when it flies out of an enemy’s reach."
actions:
  - name: "Talons"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 7 (1d10 + 2) Slashing damage."
  - name: "Spellcasting"
    desc: "The owl casts one of the following spells, requiring no spell components and using Wisdom as the spellcasting ability: At Will: Detect Evil and Good, Detect Magic 1/Day: Clairvoyance"
```

#Monster
