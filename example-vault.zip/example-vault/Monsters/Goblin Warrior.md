---
Type: Fey
CR: 1/4
Size: Small
tags:
  - Monster
  - Fey
source: SRD 5.2.1
---

```statblock
name: Goblin Warrior
size: Small
type: Fey (Goblinoid)
alignment: Chaotic Neutral
ac: 15
hp: 10 (3d6)
hit_dice: 3d6
speed: 30 ft.
stats: [8, 15, 10, 10, 8, 8]
skillsaves:
  - Stealth: +6
gear: Leather Armor, Scimitar, Shield, Shortbow
senses: Darkvision 60 ft.; Passive Perception 9
languages: Common, Goblin
cr: 1/4
actions:
  - name: "Scimitar"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 5 (1d6 + 2) Slashing damage, plus 2 (1d4) Slashing damage if the attack roll had Advantage."
  - name: "Shortbow"
    desc: "Ranged Attack Roll: +4, range 80/320 ft. Hit: 5 (1d6 + 2) Piercing damage, plus 2 (1d4) Piercing damage if the attack roll had Advantage."
bonusactions:
  - name: "Nimble Escape"
    desc: "The goblin takes the Disengage or Hide action."
```

#Monster
