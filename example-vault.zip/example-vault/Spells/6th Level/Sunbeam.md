---
Spell level: 6
School type: Evocation
Casting Time: Action
Components:
  - Verbal
  - Somatic
  - Material
Concentration: true
Duration: 1 minute
Range / Area: Self
Attack / Save: CON Save
Damage / Effect: 6d8 Radiant
Upscale: 
category: 6th level
---
_Level 6 Evocation_

- **Casting time:** Action
- **Range:** Self
- **Components:** V, S, M
- **Duration:** 1 minute
- **Attack/Save**: CON Save
- **Damage/Effect**: Radiant

You launch a sunbeam in a 5-foot-wide, 60-foot-long Line. Each creature in the Line makes a Constitution saving throw. On a failed save, a creature takes 6d8 Radiant damage and has the Blinded condition until the start of your next turn. On a successful save, it takes half as much damage only. Until the spell ends, you can take a Magic action to create a new Line of radiance. For the duration, a mote of brilliant radiance shines above you. It sheds Bright Light in a 30-foot radius and Dim Light for an additional 30 feet. This light is sunlight.

#Spell
