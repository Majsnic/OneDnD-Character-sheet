---
Rarity: Uncommon
type: object
tags:
  - Item
  - item/uncommon
  - item/weapon
item_category: Weapon
item_base: "Longbow"
weapon_category: "Martial Ranged"
damage_dice: "1d8"
damage_type: Piercing
weapon_properties: [Ammunition, Heavy, Two-Handed]
range_normal: 150
range_long: 600
weapon_mastery: Slow
requires_attunement: false
attunement_note: ""
attack_bonus: 1
damage_bonus: 1
---


###### +1 Longbow
_Weapon (longbow), uncommon_<span class="sub2">:FasWandMagicSparkles: Magic Item</span>
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>You have a +1 bonus to attack and damage rolls made with this magic weapon.
>
>**1d8+1 Piercing damage.** Range 150/600 ft. Properties: Heavy, Two-Handed.
>
>- **Ammunition.** You can use a weapon that has the Ammunition property to make a ranged attack only if you have ammunition to fire from it.
>- **Heavy.** Small creatures have Disadvantage on attack rolls with this weapon.
>- **Two-Handed.** You must use two hands to attack with this weapon.
>
>**_Slow (Mastery)._** If you hit a creature with this weapon and deal damage to it, you can reduce the creature's Speed by 10 feet until the start of your next turn. This property doesn't work against a creature that has a Speed of 0.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
