---
Type: Undead
CR: 2
Size: Large
tags:
  - Monster
  - Undead
source: SRD 5.2.1
---

```statblock
name: Minotaur Skeleton
size: Large
type: Undead
alignment: Lawful Evil
ac: 12
hp: 45 (6d10 + 12)
hit_dice: 6d10 + 12
speed: 40 ft.
stats: [18, 11, 15, 6, 8, 5]
damage_vulnerabilities: Bludgeoning
damage_immunities: Poison
condition_immunities: Exhaustion, Poisoned
senses: Darkvision 60 ft.; Passive Perception 9
languages: Understands Abyssal but can’t speak
cr: 2
actions:
  - name: "Gore"
    desc: "Melee Attack Roll: +6, reach 5 ft. Hit: 11 (2d6 + 4) Piercing damage. If the target is a Large or smaller creature and the skeleton moved 20+ feet straight toward it immediately before the hit, the target takes an extra 9 (2d8) Piercing damage and has the Prone condition."
  - name: "Slam"
    desc: "Melee Attack Roll: +6, reach 5 ft. Hit: 15 (2d10 + 4) Bludgeoning damage."
```

#Monster
