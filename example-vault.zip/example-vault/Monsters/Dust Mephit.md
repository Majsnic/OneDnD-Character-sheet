---
Type: Elemental
CR: 1/2
Size: Small
tags:
  - Monster
  - Elemental
source: SRD 5.2.1
---

```statblock
name: Dust Mephit
size: Small
type: Elemental
alignment: Neutral Evil
ac: 12
hp: 17 (5d6)
hit_dice: 5d6
speed: 30 ft., Fly 30 ft.
stats: [5, 14, 10, 9, 11, 10]
skillsaves:
  - Perception: +2
  - Stealth: +4
damage_vulnerabilities: Fire
damage_immunities: Poison
condition_immunities: Exhaustion, Poisoned
senses: Darkvision 60 ft.; Passive Perception 12
languages: Primordial (Auran, Terran)
cr: 1/2
traits:
  - name: "Death Burst"
    desc: "The mephit explodes when it dies. Dexterity Saving Throw: DC 10, each creature in a 5-foot Emanation originating from the mephit. Failure: 5 (2d4) Bludgeoning damage. Success: Half damage."
actions:
  - name: "Claw"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 4 (1d4 + 2) Slashing damage."
  - name: "Blinding Breath (Recharge 6)"
    desc: "Dexterity Saving Throw: DC 10, each creature in a 15-foot Cone. Failure: The target has the Blinded condition until the end of the mephit’s next turn."
  - name: "Sleep (1/Day)"
    desc: "The mephit casts the Sleep spell, requiring no spell components and using Charisma as the spellcasting ability (spell save DC 10)."
```

#Monster
