---
Type: Beast
CR: 0
Size: Small
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Octopus
size: Small
type: Beast
alignment: Unaligned
ac: 12
hp: 3 (1d6)
hit_dice: 1d6
speed: 5 ft., Swim 30 ft.
stats: [4, 15, 11, 3, 10, 4]
skillsaves:
  - Perception: +2
  - Stealth: +6
senses: Darkvision 30 ft.; Passive Perception 12
languages: None
cr: 0
traits:
  - name: "Compression"
    desc: "The octopus can move through a space as narrow as 1 inch without expending extra movement to do so."
  - name: "Water Breathing"
    desc: "The octopus can breathe only underwater."
actions:
  - name: "Tentacles"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 1 Bludgeoning damage."
reactions:
  - name: "Ink Cloud (1/Day)"
    desc: "Trigger: A creature ends its turn within 5 feet of the octopus while underwater. Response: The octopus releases ink that fills a 5-foot Cube centered on itself, and the octopus moves up to its Swim Speed. The Cube is Heavily Obscured for 1 minute or until a strong current or similar effect disperses the ink."
```

#Monster
