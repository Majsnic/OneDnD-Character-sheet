---
type: object
tags:
  - Item
  - item/common
  - item/gear
item_category: "Adventuring Gear"
cost: "1 GP"
weight_lb: 10
---


###### Rope, Hempen (50 feet)
_Adventuring Gear_
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>This rope has 2 Hit Points and can be burst with a successful DC 17 Strength check. Cost 1 GP, weight 10 lb.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
