---
Type: Undead
CR: 2
Size: Medium
tags:
  - Monster
  - Undead
source: SRD 5.2.1
---

```statblock
name: Ghast
size: Medium
type: Undead
alignment: Chaotic Evil
ac: 13
hp: 36 (8d8)
hit_dice: 8d8
speed: 30 ft.
stats: [16, 17, 10, 11, 10, 8]
saves:
  - Wis: +2
damage_resistances: Necrotic
damage_immunities: Poison
condition_immunities: Charmed, Exhaustion, Poisoned
senses: Darkvision 60 ft.; Passive Perception 10
languages: Common
cr: 2
traits:
  - name: "Stench"
    desc: "Constitution Saving Throw: DC 10, any creature that starts its turn in a 5-foot Emanation originating from the ghast. Failure: The target has the Poisoned condition until the start of its next turn. Success: The target is immune to this ghast’s Stench for 24 hours."
actions:
  - name: "Bite"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 7 (1d8 + 3) Piercing damage plus 9 (2d8) Necrotic damage."
  - name: "Claw"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 10 (2d6 + 3) Slashing damage. If the target is a non-Undead creature, it is subjected to the following effect. Constitution Saving Throw: DC 10. Failure: The target has the Paralyzed condition until the end of its next turn."
```

#Monster
