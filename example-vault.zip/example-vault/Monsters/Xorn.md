---
Type: Elemental
CR: 5
Size: Medium
tags:
  - Monster
  - Elemental
source: SRD 5.2.1
---

```statblock
name: Xorn
size: Medium
type: Elemental
alignment: Neutral
ac: 19
hp: 84 (8d8 + 48)
hit_dice: 8d8 + 48
speed: 20 ft., Burrow 20 ft.
stats: [17, 10, 22, 11, 10, 11]
skillsaves:
  - Perception: +6
  - Stealth: +6
damage_immunities: Poison
condition_immunities: Paralyzed, Petrified, Poisoned
senses: Darkvision 60 ft., Tremorsense 60 ft.; Passive Perception 16
languages: Primordial (Terran)
cr: 5
traits:
  - name: "Earth Glide"
    desc: "The xorn can burrow through nonmagical, unworked earth and stone. While doing so, the xorn doesn’t disturb the material it moves through."
  - name: "Treasure Sense"
    desc: "The xorn can pinpoint the location of precious metals and stones within 60 feet of itself."
actions:
  - name: "Multiattack"
    desc: "The xorn makes one Bite attack and three Claw attacks."
  - name: "Bite"
    desc: "Melee Attack Roll: +6, reach 5 ft. Hit: 17 (4d6 + 3) Piercing damage."
  - name: "Claw"
    desc: "Melee Attack Roll: +6, reach 5 ft. Hit: 8 (1d10 + 3) Slashing damage."
bonusactions:
  - name: "Charge"
    desc: "The xorn moves up to its Speed or Burrow Speed straight toward an enemy it can sense."
```

#Monster
