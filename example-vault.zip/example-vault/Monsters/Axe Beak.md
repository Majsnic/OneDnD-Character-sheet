---
Type: Monstrosity
CR: 1/4
Size: Large
tags:
  - Monster
  - Monstrosity
source: SRD 5.2.1
---

```statblock
name: Axe Beak
size: Large
type: Monstrosity
alignment: Unaligned
ac: 11
hp: 19 (3d10 + 3)
hit_dice: 3d10 + 3
speed: 50 ft.
stats: [14, 12, 12, 2, 10, 5]
senses: Passive Perception 10
languages: None
cr: 1/4
actions:
  - name: "Beak"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 6 (1d8 + 2) Slashing damage."
```

#Monster
