---
Type: Beast
CR: 1/4
Size: Medium
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Giant Wolf Spider
size: Medium
type: Beast
alignment: Unaligned
ac: 13
hp: 11 (2d8 + 2)
hit_dice: 2d8 + 2
speed: 40 ft., Climb 40 ft.
stats: [12, 16, 13, 3, 12, 4]
skillsaves:
  - Perception: +3
  - Stealth: +7
senses: Blindsight 10 ft., Darkvision 60 ft.; Passive Perception 13
languages: None
cr: 1/4
traits:
  - name: "Spider Climb"
    desc: "The spider can climb difficult surfaces, including along ceilings, without needing to make an ability check."
actions:
  - name: "Bite"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 5 (1d4 + 3) Piercing damage plus 5 (2d4) Poison damage."
```

#Monster
