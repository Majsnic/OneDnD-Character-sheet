---
Type: Giant
CR: 9
Size: Huge
tags:
  - Monster
  - Giant
source: SRD 5.2.1
---

```statblock
name: Fire Giant
size: Huge
type: Giant
alignment: Lawful Evil
ac: 18
hp: 162 (13d12 + 78)
hit_dice: 13d12 + 78
speed: 30 ft.
stats: [25, 9, 23, 10, 14, 13]
saves:
  - Dex: +3
  - Con: +10
  - Cha: +5
skillsaves:
  - Athletics: +11
  - Perception: +6
damage_immunities: Fire
senses: Passive Perception 16
languages: Giant
cr: 9
actions:
  - name: "Multiattack"
    desc: "The giant makes two attacks, using Flame Sword or Hammer Throw in any combination."
  - name: "Flame Sword"
    desc: "Melee Attack Roll: +11, reach 10 ft. Hit: 21 (4d6 + 7) Slashing damage plus 10 (3d6) Fire damage."
  - name: "Hammer Throw"
    desc: "Ranged Attack Roll: +11, range 60/240 ft. Hit: 23 (3d10 + 7) Bludgeoning damage plus 4 (1d8) Fire damage, and the target is pushed up to 15 feet straight away from the giant and has Disadvantage on the next attack roll it makes before the end of its next turn."
```

#Monster
