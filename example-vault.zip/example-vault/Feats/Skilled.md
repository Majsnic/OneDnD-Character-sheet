---
tags:
  - Feat
source: SRD 5.2.1
---

# Skilled

**Type:** Origin Feat
**Repeatable:** Yes

You gain proficiency in any combination of three skills or tools of your choice.

*Paraphrased mechanical summary, written from general knowledge of the SRD rules — treat it as a helpful draft, not a verbatim rules quote.*

#Feat
