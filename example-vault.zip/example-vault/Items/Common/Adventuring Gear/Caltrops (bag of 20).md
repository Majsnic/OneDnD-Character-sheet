---
type: object
tags:
  - Item
  - item/common
  - item/gear
item_category: "Adventuring Gear"
cost: "1 GP"
weight_lb: 2
---


###### Caltrops (bag of 20)
_Adventuring Gear_
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>As an action, you can spread these spiked metal stars across a 5-foot-square area. A creature that enters the area must succeed on a DC 15 Dexterity saving throw or stop moving and take 1 piercing damage, reducing its walking speed by 10 feet until the creature regains at least 1 hit point. Cost 1 GP, weight 2 lb.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
