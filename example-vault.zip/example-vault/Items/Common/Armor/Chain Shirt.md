---
type: object
tags:
  - Item
  - item/common
  - item/armor
item_category: Armor
armor_category: Medium
armor_class_base: 13
armor_class_dex_cap: 2
stealth_disadvantage: false
cost: "50 GP"
weight_lb: 20
---


###### Chain Shirt
_Medium Armor_
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>**AC 13 + Dex modifier (max 2).** Cost 50 GP, weight 20 lb.
>
>Donning this armor takes 5 minutes; doffing takes 1 minute.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
