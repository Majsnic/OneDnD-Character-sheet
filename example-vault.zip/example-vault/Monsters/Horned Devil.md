---
Type: Fiend
CR: 11
Size: Large
tags:
  - Monster
  - Fiend
source: SRD 5.2.1
---

```statblock
name: Horned Devil
size: Large
type: Fiend (Devil)
alignment: Lawful Evil
ac: 18
hp: 199 (19d10 + 95)
hit_dice: 19d10 + 95
speed: 30 ft., Fly 60 ft.
stats: [22, 17, 21, 12, 16, 18]
saves:
  - Str: +10
  - Dex: +7
  - Wis: +7
  - Cha: +8
damage_resistances: Cold
damage_immunities: Fire, Poison
condition_immunities: Poisoned
senses: Darkvision 150 ft. (unimpeded by magical Darkness); Passive Perception 13
languages: Infernal; telepathy 120 ft.
cr: 11
traits:
  - name: "Diabolical Restoration"
    desc: "If the devil dies outside the Nine Hells, its body disappears in sulfurous smoke, and it gains a new body instantly, reviving with all its Hit Points somewhere in the Nine Hells."
  - name: "Magic Resistance"
    desc: "The devil has Advantage on saving throws against spells and other magical effects."
actions:
  - name: "Multiattack"
    desc: "The devil makes three attacks, using Searing Fork or Hurl Flame in any combination. It can replace one attack with a use of Infernal Tail."
  - name: "Searing Fork"
    desc: "Melee Attack Roll: +10, reach 10 ft. Hit: 15 (2d8 + 6) Piercing damage plus 9 (2d8) Fire damage."
  - name: "Hurl Flame"
    desc: "Ranged Attack Roll: +8, range 150 ft. Hit: 26 (5d8 + 4) Fire damage. If the target is a flammable object that isn’t being worn or carried, it starts burning."
  - name: "Infernal Tail"
    desc: "Dexterity Saving Throw: DC 17, one creature the devil can see within 10 feet. Failure: 10 (1d8 + 6) Necrotic damage, and the target receives an infernal wound if it doesn’t have one. While wounded, the target loses 10 (3d6) Hit Points at the start of each of its turns. The wound closes after 1 minute, after a spell restores Hit Points to the target, or after the target or a creature within 5 feet of it takes an action to stanch the wound, doing so by succeeding on a DC 17 Wisdom (Medicine) check."
```

#Monster
