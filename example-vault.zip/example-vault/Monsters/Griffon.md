---
Type: Monstrosity
CR: 2
Size: Large
tags:
  - Monster
  - Monstrosity
source: SRD 5.2.1
---

```statblock
name: Griffon
size: Large
type: Monstrosity
alignment: Unaligned
ac: 12
hp: 59 (7d10 + 21)
hit_dice: 7d10 + 21
speed: 30 ft., Fly 80 ft.
stats: [18, 15, 16, 2, 13, 8]
skillsaves:
  - Perception: +5
senses: Darkvision 60 ft.; Passive Perception 15
languages: None
cr: 2
actions:
  - name: "Multiattack"
    desc: "The griffon makes two Rend attacks."
  - name: "Rend"
    desc: "Melee Attack Roll: +6, reach 5 ft. Hit: 8 (1d8 + 4) Piercing damage. If the target is a Medium or smaller creature, it has the Grappled condition (escape DC 14) from both of the griffon’s front claws."
```

#Monster
