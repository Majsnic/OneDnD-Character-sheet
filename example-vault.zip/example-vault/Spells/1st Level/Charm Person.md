---
Spell level: 1
School type: Enchantment
Casting Time: Action
Components:
  - Verbal
  - Somatic
Concentration: false
Duration: 1 hour
Range / Area: 30 feet
Attack / Save: WIS Save
Damage / Effect: Charmed
Upscale: + 1 creature
category: 1st level
---
_Level 1 Enchantment_

- **Casting time:** Action
- **Range:** 30 feet
- **Components:** V, S
- **Duration:** 1 hour
- **Attack/Save**: WIS Save
- **Damage/Effect**: Charmed

One Humanoid you can see within range makes a Wisdom saving throw. It does so with Advantage if you or your allies are fighting it. On a failed save, the target has the Charmed condition until the spell ends or until you or your allies damage it. The Charmed creature is Friendly to you. When the spell ends, the target knows it was Charmed by you.

**_Using a Higher-Level Spell Slot._** You can target one additional creature for each spell slot level above 1.

#Spell
