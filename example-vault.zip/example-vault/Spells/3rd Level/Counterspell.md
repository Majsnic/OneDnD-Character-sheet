---
Spell level: 3
School type: Abjuration
Casting Time: Reaction*
Components:
  - Somatic
Concentration: false
Duration: Instantaneous
Range / Area: 60 feet
Attack / Save: CON Save
Damage / Effect: Utility
Upscale: 
category: 3rd level
---
_Level 3 Abjuration_

- **Casting time:** Reaction*
- **Range:** 60 feet
- **Components:** S
- **Duration:** Instantaneous
- **Attack/Save**: CON Save
- **Damage/Effect**: Utility

_* - which you take when you see a creature within 60 feet of yourself casting a spell with Verbal, Somatic, or Material components_

You attempt to interrupt a creature in the process of casting a spell. The creature makes a Constitution saving throw. On a failed save, the spell dissipates with no effect, and the action, Bonus Action, or Reaction used to cast it is wasted. If that spell was cast with a spell slot, the slot isn’t expended.

#Spell
