---
Type: Beast
CR: 4
Size: Huge
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Elephant
size: Huge
type: Beast
alignment: Unaligned
ac: 12
hp: 76 (8d12 + 24)
hit_dice: 8d12 + 24
speed: 40 ft.
stats: [22, 9, 17, 3, 11, 6]
senses: Passive Perception 10
languages: None
cr: 4
actions:
  - name: "Multiattack"
    desc: "The elephant makes two Gore attacks."
  - name: "Gore"
    desc: "Melee Attack Roll: +8, reach 5 ft. Hit: 15 (2d8 + 6) Piercing damage. If the target is a Huge or smaller creature and the elephant moved 20+ feet straight toward it immediately before the hit, the target has the Prone condition."
bonusactions:
  - name: "Trample"
    desc: "Dexterity Saving Throw: DC 16, one creature within 5 feet that has the Prone condition. Failure: 17 (2d10 + 6) Bludgeoning damage. Success: Half damage."
```

#Monster
