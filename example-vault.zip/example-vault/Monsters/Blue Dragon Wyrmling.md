---
Type: Dragon
CR: 3
Size: Medium
tags:
  - Monster
  - Dragon
source: SRD 5.2.1
---

```statblock
name: Blue Dragon Wyrmling
size: Medium
type: Dragon (Chromatic)
alignment: Lawful Evil
ac: 17
hp: 65 (10d8 + 20)
hit_dice: 10d8 + 20
speed: 30 ft., Burrow 15 ft., Fly 60 ft.
stats: [17, 10, 15, 12, 11, 15]
saves:
  - Dex: +2
  - Wis: +2
skillsaves:
  - Perception: +4
  - Stealth: +2
damage_immunities: Lightning
senses: Blindsight 10 ft., Darkvision 60 ft.; Passive Perception 14
languages: Draconic
cr: 3
actions:
  - name: "Multiattack"
    desc: "The dragon makes two Rend attacks."
  - name: "Rend"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 8 (1d10 + 3) Slashing damage plus 3 (1d6) Lightning damage."
  - name: "Lightning Breath (Recharge 5–6)"
    desc: "Dexterity Saving Throw: DC 12, each creature in a 30-foot-long, 5-footwide Line. Failure: 21 (6d6) Lightning damage. Success: Half damage."
```

#Monster
