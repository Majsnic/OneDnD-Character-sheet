---
Spell level: 3
School type: Abjuration
Casting Time: Action
Components:
  - Verbal
  - Somatic
Concentration: true
Duration: 1 hour
Range / Area: Touch
Attack / Save: None
Damage / Effect: Utility
Upscale: 
category: 3rd level
---
_Level 3 Abjuration_

- **Casting time:** Action
- **Range:** Touch
- **Components:** V, S
- **Duration:** 1 hour
- **Attack/Save**: None
- **Damage/Effect**: Utility

For the duration, the willing creature you touch has Resistance to one damage type of your choice: Acid, Cold, Fire, Lightning, or Thunder.

#Spell
