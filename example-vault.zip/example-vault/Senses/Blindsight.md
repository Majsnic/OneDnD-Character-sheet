---
tags:
  - Sense
source: SRD 5.2.1
---

# Blindsight

Within a specified range, you perceive your surroundings without relying on sight, through sound, vibration, or other senses. This works even if you're blinded or in darkness, and creatures entirely outside that range are effectively invisible to this sense.

*Paraphrased mechanical summary, written from general knowledge of the SRD rules — treat it as a helpful draft, not a verbatim rules quote.*

#Sense
