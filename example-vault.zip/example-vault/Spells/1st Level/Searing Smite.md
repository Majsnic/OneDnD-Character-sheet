---
Spell level: 1
School type: Evocation
Casting Time: Bonus Action, which you take immediately after hitting a target with a Melee weapon or an Unarmed Strike
Components:
  - Verbal
Concentration: false
Duration: 1 minute
Range / Area: Self
Attack / Save: CON Save
Damage / Effect: 1d6 Fire
Upscale: + 1d6
category: 1st level
---
_Level 1 Evocation_

- **Casting time:** Bonus Action, which you take immediately after hitting a target with a Melee weapon or an Unarmed Strike
- **Range:** Self
- **Components:** V
- **Duration:** 1 minute
- **Attack/Save**: CON Save
- **Damage/Effect**: Fire

As you hit the target, it takes an extra 1d6 Fire damage from the attack. At the start of each of its turns until the spell ends, the target takes 1d6 Fire damage and then makes a Constitution saving throw. On a failed save, the spell continues. On a successful save, the spell ends.

**_Using a Higher-Level Spell Slot._** All the damage increases by 1d6 for each spell slot level above 1.

#Spell
