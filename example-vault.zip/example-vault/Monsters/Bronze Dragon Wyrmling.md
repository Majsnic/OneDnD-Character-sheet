---
Type: Dragon
CR: 2
Size: Medium
tags:
  - Monster
  - Dragon
source: SRD 5.2.1
---

```statblock
name: Bronze Dragon Wyrmling
size: Medium
type: Dragon (Metallic)
alignment: Lawful Good
ac: 15
hp: 39 (6d8 + 12)
hit_dice: 6d8 + 12
speed: 30 ft., Fly 60 ft., Swim 30 ft.
stats: [17, 10, 15, 12, 11, 15]
saves:
  - Dex: +2
  - Wis: +2
skillsaves:
  - Perception: +4
  - Stealth: +2
damage_immunities: Lightning
senses: Blindsight 10 ft., Darkvision 60 ft.; Passive Perception 14
languages: Draconic
cr: 2
traits:
  - name: "Amphibious"
    desc: "The dragon can breathe air and water."
actions:
  - name: "Multiattack"
    desc: "The dragon makes two Rend attacks."
  - name: "Rend"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 8 (1d10 + 3) Slashing damage."
  - name: "Lightning Breath (Recharge 5–6)"
    desc: "Dexterity Saving Throw: DC 12, each creature in a 40-foot-long, 5-footwide Line. Failure: 16 (3d10) Lightning damage. Success: Half damage."
  - name: "Repulsion Breath"
    desc: "Strength Saving Throw: DC 12, each creature in a 30-foot Cone. Failure: The target is pushed up to 30 feet straight away from the dragon and has the Prone condition."
```

#Monster
