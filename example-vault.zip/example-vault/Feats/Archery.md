---
tags:
  - Feat
source: SRD 5.2.1
---

# Archery

**Type:** Fighting Style Feat
**Prerequisite:** A class feature that lets you choose a Fighting Style
**Repeatable:** No

You gain a +2 bonus to attack rolls you make with ranged weapons.

*Paraphrased mechanical summary, written from general knowledge of the SRD rules — treat it as a helpful draft, not a verbatim rules quote.*

#Feat
