---
Type: Humanoid
CR: 4
Size: Medium or Small
tags:
  - Monster
  - Humanoid
source: SRD 5.2.1
---

```statblock
name: Guard Captain
size: Medium or Small
type: Humanoid
alignment: Neutral
ac: 18
hp: 75 (10d8 + 30)
hit_dice: 10d8 + 30
speed: 30 ft.
stats: [18, 14, 16, 12, 14, 13]
skillsaves:
  - Athletics: +6
  - Perception: +4
gear: Breastplate, Javelins (6), Longsword, Shield
senses: Passive Perception 14
languages: Common
cr: 4
actions:
  - name: "Multiattack"
    desc: "The guard makes two attacks, using Javelin or Longsword in any combination."
  - name: "Javelin"
    desc: "Melee or Ranged Attack Roll: +6, reach 5 ft. or range 30/120 ft. Hit: 14 (3d6 + 4) Piercing damage."
  - name: "Longsword"
    desc: "Melee Attack Roll: +6, reach 5 ft. Hit: 15 (2d10 + 4) Slashing damage."
```

#Monster
