---
Type: Beast
CR: 1
Size: Medium
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Swarm of Piranhas
size: Medium
type: Swarm of Tiny Beasts
alignment: Unaligned
ac: 13
hp: 28 (8d8 - 8)
hit_dice: 8d8 - 8
speed: 5 ft., Swim 40 ft.
stats: [13, 16, 9, 1, 7, 2]
damage_resistances: Bludgeoning, Piercing, Slashing
condition_immunities: Charmed, Frightened, Grappled, Paralyzed, Petrified, Prone, Restrained, Stunned
senses: Darkvision 60 ft.; Passive Perception 8
languages: None
cr: 1
traits:
  - name: "Swarm"
    desc: "The swarm can occupy another creature’s space and vice versa, and the swarm can move through any opening large enough for a Tiny piranha. The swarm can’t regain Hit Points or gain Temporary Hit Points."
  - name: "Water Breathing"
    desc: "The swarm can breathe only underwater."
actions:
  - name: "Bites"
    desc: "Melee Attack Roll: +5 (with Advantage if the target doesn’t have all its Hit Points), reach 5 ft. Hit: 8 (2d4 + 3) Piercing damage, or 5 (1d4 + 3) Piercing damage if the swarm is Bloodied."
```

#Monster
