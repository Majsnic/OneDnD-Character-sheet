---
Spell level: 1
School type: Evocation
Casting Time: Bonus Action, which you take immediately after hitting a target with a Melee weapon or an Unarmed Strike
Components:
  - Verbal
Concentration: false
Duration: Instantaneous
Range / Area: Self
Attack / Save: Auto-hit
Damage / Effect: 2d8 Radiant
Upscale: + 1d8
category: 1st level
---
_Level 1 Evocation_

- **Casting time:** Bonus Action, which you take immediately after hitting a target with a Melee weapon or an Unarmed Strike
- **Range:** Self
- **Components:** V
- **Duration:** Instantaneous
- **Attack/Save**: Auto-hit
- **Damage/Effect**: Radiant

The target takes an extra 2d8 Radiant damage from the attack. The damage increases by 1d8 if the target is a Fiend or an Undead.

**_Using a Higher-Level Spell Slot._** The damage increases by 1d8 for each spell slot level above 1.

#Spell
