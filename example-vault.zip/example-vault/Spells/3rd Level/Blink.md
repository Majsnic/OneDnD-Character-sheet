---
Spell level: 3
School type: Transmutation
Casting Time: Action
Components:
  - Verbal
  - Somatic
Concentration: false
Duration: 1 minute
Range / Area: Self
Attack / Save: None
Damage / Effect: Utility
Upscale: 
category: 3rd level
---
_Level 3 Transmutation_

- **Casting time:** Action
- **Range:** Self
- **Components:** V, S
- **Duration:** 1 minute
- **Attack/Save**: None
- **Damage/Effect**: Utility

Roll 1d6 at the end of each of your turns for the duration. On a roll of 4–6, you vanish from your current plane of existence and appear in the Ethereal Plane (the spell ends instantly if you are already on that plane). While on the Ethereal Plane, you can perceive the plane you left, which is cast in shades of gray, but you can’t see anything there more than 60 feet away. You can affect and be affected only by other creatures on the Ethereal Plane, and creatures on the other plane can’t perceive you unless they have a special ability that lets them perceive things on the Ethereal Plane. You return to the other plane at the start of your next turn and when the spell ends if you are on the Ethereal Plane. You return to an unoccupied space of your choice that you can see within 10 feet of the space you left. If no unoccupied space is available within that range, you appear in the nearest unoccupied space.

#Spell
