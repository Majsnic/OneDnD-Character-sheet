---
type: object
tags:
  - Item
  - item/common
  - item/weapon
item_category: Weapon
weapon_category: "Martial Ranged"
damage_dice: "1d8"
damage_type: Piercing
weapon_properties: [Ammunition, Heavy, Two-Handed]
range_normal: 150
range_long: 600
weapon_mastery: Slow
attack_bonus: 0
damage_bonus: 0
cost: "50 GP"
weight_lb: 2
---


###### Longbow
_Martial Ranged Weapon_
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>**1d8 Piercing damage.** Range 150/600 ft. Properties: Heavy, Two-Handed. Cost 50 GP, weight 2 lb.
>
>- **Ammunition.** You can use a weapon that has the Ammunition property to make a ranged attack only if you have ammunition to fire from it.
>- **Heavy.** Small creatures have Disadvantage on attack rolls with this weapon.
>- **Two-Handed.** You must use two hands to attack with this weapon.
>
>**_Slow (Mastery)._** If you hit a creature with this weapon, you can reduce that creature's Speed by 10 feet until the start of your next turn. This isn't cumulative with itself.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
