---
Rarity: Rare
type: object
tags:
  - Item
  - item/rare
  - item/weapon
item_category: Weapon
item_base: "Blowgun"
weapon_category: "Martial Ranged"
damage_dice: "1"
damage_type: Piercing
weapon_properties: [Ammunition, Loading]
range_normal: 25
range_long: 100
weapon_mastery: Vex
requires_attunement: false
attunement_note: ""
attack_bonus: 2
damage_bonus: 2
---


###### +2 Blowgun
_Weapon (blowgun), rare_<span class="sub2">:FasWandMagicSparkles: Magic Item</span>
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>You have a +2 bonus to attack and damage rolls made with this magic weapon.
>
>**1+2 Piercing damage.** Range 25/100 ft. Properties: Loading.
>
>- **Ammunition.** You can use a weapon that has the Ammunition property to make a ranged attack only if you have ammunition to fire from it.
>- **Loading.** You can fire only one piece of ammunition from this weapon when you use an action, Bonus Action, or Reaction to fire it, regardless of the number of attacks you can normally make.
>
>**_Vex (Mastery)._** If you hit a creature with this weapon and deal damage to it, you can give yourself Advantage on your next attack roll against that creature before the end of your next turn.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
