---
Type: Elemental
CR: 2
Size: Medium
tags:
  - Monster
  - Elemental
source: SRD 5.2.1
---

```statblock
name: Azer Sentinel
size: Medium
type: Elemental
alignment: Lawful Neutral
ac: 17
hp: 39 (6d8 + 12)
hit_dice: 6d8 + 12
speed: 30 ft.
stats: [17, 12, 15, 12, 13, 10]
saves:
  - Con: +4
damage_immunities: Fire, Poison
condition_immunities: Poisoned
senses: Passive Perception 11
languages: Primordial (Ignan)
cr: 2
traits:
  - name: "Fire Aura"
    desc: "At the end of each of the azer’s turns, each creature of the azer’s choice in a 5-foot Emanation originating from the azer takes 5 (1d10) Fire damage unless the azer has the Incapacitated condition."
  - name: "Illumination"
    desc: "The azer sheds Bright Light in a 10-foot radius and Dim Light for an additional 10 feet."
actions:
  - name: "Burning Hammer"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 8 (1d10 + 3) Bludgeoning damage plus 3 (1d6) Fire damage."
```

#Monster
