---
Spell level: 6
School type: Conjuration
Casting Time: Action
Components:
  - Verbal
  - Somatic
Concentration: false
Duration: 1 minute
Range / Area: 10 feet
Attack / Save: None
Damage / Effect: Utility
Upscale: 
category: 6th level
---
_Level 6 Conjuration_

- **Casting time:** Action
- **Range:** 10 feet
- **Components:** V, S
- **Duration:** 1 minute
- **Attack/Save**: None
- **Damage/Effect**: Utility

This spell creates a magical link between a Large or larger inanimate plant within range and another plant, at any distance, on the same plane of existence. You must have seen or touched the destination plant at least once before. For the duration, any creature can step into the target plant and exit from the destination plant by using 5 feet of movement.

#Spell
