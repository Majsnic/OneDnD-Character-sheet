---
Type: Fiend
CR: 3
Size: Medium
tags:
  - Monster
  - Fiend
source: SRD 5.2.1
---

```statblock
name: Bearded Devil
size: Medium
type: Fiend (Devil)
alignment: Lawful Evil
ac: 13
hp: 58 (9d8 + 18)
hit_dice: 9d8 + 18
speed: 30 ft.
stats: [16, 15, 15, 9, 11, 14]
saves:
  - Str: +5
  - Con: +4
  - Cha: +4
damage_resistances: Cold
damage_immunities: Fire, Poison
condition_immunities: Frightened, Poisoned
senses: Darkvision 120 ft. (unimpeded by magical Darkness); Passive Perception 10
languages: Infernal; telepathy 120 ft.
cr: 3
traits:
  - name: "Magic Resistance"
    desc: "The devil has Advantage on saving throws against spells and other magical effects."
actions:
  - name: "Multiattack"
    desc: "The devil makes one Beard attack and one Infernal Glaive attack."
  - name: "Beard"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 7 (1d8 + 3) Piercing damage, and the target has the Poisoned condition until the start of the devil’s next turn. Until this poison ends, the target can’t regain Hit Points."
  - name: "Infernal Glaive"
    desc: "Melee Attack Roll: +5, reach 10 ft. Hit: 8 (1d10 + 3) Slashing damage. If the target is a creature and doesn’t already have an infernal wound, it is subjected to the following effect. Constitution Saving Throw: DC 12. Failure: The target receives an infernal wound. While wounded, the target loses 5 (1d10) Hit Points at the start of each of its turns. The wound closes after 1 minute, after a spell restores Hit Points to the target, or after the target or a creature within 5 feet of it takes an action to stanch the wound, doing so by succeeding on a DC 12 Wisdom (Medicine) check."
```

#Monster
