---
Spell level: 3
School type: Evocation
Casting Time: Action
Components:
  - Verbal
  - Somatic
Concentration: false
Duration: 1 hour
Range / Area: 60 feet
Attack / Save: None
Damage / Effect: Utility
Upscale: 
category: 3rd level
---
_Level 3 Evocation_

- **Casting time:** Action
- **Range:** 60 feet
- **Components:** V, S
- **Duration:** 1 hour
- **Attack/Save**: None
- **Damage/Effect**: Utility

For the duration, sunlight spreads from a point within range and fills a 60-foot-radius Sphere. The sunlight’s area is Bright Light and sheds Dim Light for an additional 60 feet. Alternatively, you cast the spell on an object that isn’t being worn or carried, causing the sunlight to fill a 60-foot Emanation originating from that object. Covering that object with something opaque, such as a bowl or helm, blocks the sunlight. If any of this spell’s area overlaps with an area of Darkness created by a spell of level 3 or lower, that other spell is dispelled.

#Spell
