---
type: object
tags:
  - Item
  - item/common
  - item/weapon
item_category: Weapon
weapon_category: "Simple Ranged"
damage_dice: "1d4"
damage_type: Piercing
weapon_properties: [Finesse, Thrown]
range_normal: 20
range_long: 60
attack_bonus: 0
damage_bonus: 0
cost: "5 CP"
weight_lb: 0.25
---


###### Dart
_Simple Ranged Weapon_
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>**1d4 Piercing damage.** Range 20/60 ft. Properties: Finesse. Cost 5 CP, weight 0.25 lb.
>
>- **Finesse.** You can use your Strength or Dexterity modifier for attack and damage rolls with this weapon.
>- **Thrown.** You can throw this weapon to make a ranged attack, using the same ability modifier for the attack and damage rolls that you use for a melee attack with the weapon.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
