---
Spell level: 1
School type: Evocation
Casting Time: Action
Components:
  - Verbal
  - Somatic
Concentration: false
Duration: Instantaneous
Range / Area: Self
Attack / Save: DEX Save
Damage / Effect: 3d6 Fire
Upscale: + 1d6
category: 1st level
---
_Level 1 Evocation_

- **Casting time:** Action
- **Range:** Self
- **Components:** V, S
- **Duration:** Instantaneous
- **Attack/Save**: DEX Save
- **Damage/Effect**: Fire

A thin sheet of flames shoots forth from you. Each creature in a 15-foot Cone makes a Dexterity saving throw, taking 3d6 Fire damage on a failed save or half as much damage on a successful one. Flammable objects in the Cone that aren’t being worn or carried start burning.

**_Using a Higher-Level Spell Slot._** The damage increases by 1d6 for each spell slot level above 1.

#Spell
