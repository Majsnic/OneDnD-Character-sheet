---
tags:
  - Sense
source: SRD 5.2.1
---

# Darkvision

Within a specified range, you can see in dim light as if it were bright light and in darkness as if it were dim light. You discern colors in that darkness only as shades of gray.

*Paraphrased mechanical summary, written from general knowledge of the SRD rules — treat it as a helpful draft, not a verbatim rules quote.*

#Sense
