---
Spell level: 1
School type: Enchantment
Casting Time: Action
Components:
  - Verbal
Concentration: false
Duration: Instantaneous
Range / Area: 60 feet
Attack / Save: WIS Save
Damage / Effect: Prone
Upscale: + 1 creature
category: 1st level
---
_Level 1 Enchantment_

- **Casting time:** Action
- **Range:** 60 feet
- **Components:** V
- **Duration:** Instantaneous
- **Attack/Save**: WIS Save
- **Damage/Effect**: Prone

You speak a one-word command to a creature you can see within range. The target must succeed on a Wisdom saving throw or follow the command on its next turn. Choose the command from these options: Approach. The target moves toward you by the shortest and most direct route, ending its turn if it moves within 5 feet of you. Drop. The target drops whatever it is holding and then ends its turn. Flee. The target spends its turn moving away from you by the fastest available means. Grovel. The target has the Prone condition and then ends its turn. Halt. On its turn, the target doesn’t move and takes no action or Bonus Action.

**_Using a Higher-Level Spell Slot._** You can affect one additional creature for each spell slot level above 1.

#Spell
