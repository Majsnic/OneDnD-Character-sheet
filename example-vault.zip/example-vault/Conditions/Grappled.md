---
tags:
  - Condition
source: SRD 5.2.1
---

# Grappled

Your speed becomes 0, and you can't benefit from any bonus to your speed. The condition ends if the grappler is incapacitated, or if an effect removes you from the grappler's reach.

*Paraphrased mechanical summary, written from general knowledge of the SRD rules — treat it as a helpful draft, not a verbatim rules quote.*

#Condition
