---
Spell level: 1
School type: Enchantment
Casting Time: Action
Components:
  - Verbal
  - Somatic
  - Material
Concentration: true
Duration: 1 minute
Range / Area: 60 feet
Attack / Save: WIS Save
Damage / Effect: Incapacitated
Upscale: 
category: 1st level
---
_Level 1 Enchantment_

- **Casting time:** Action
- **Range:** 60 feet
- **Components:** V, S, M
- **Duration:** 1 minute
- **Attack/Save**: WIS Save
- **Damage/Effect**: Incapacitated

Each creature of your choice in a 5-foot-radius Sphere centered on a point within range must succeed on a Wisdom saving throw or have the Incapacitated condition until the end of its next turn, at which point it must repeat the save. If the target fails the second save, the target has the Unconscious condition for the duration. The spell ends on a target if it takes damage or someone within 5 feet of it takes an action to shake it out of the spell’s effect. Creatures that don’t sleep, such as elves, or that have Immunity to the Exhaustion condition automatically succeed on saves against this spell.

#Spell
