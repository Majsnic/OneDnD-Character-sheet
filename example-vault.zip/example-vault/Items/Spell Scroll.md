---
Rarity: Varies
type: object
tags:
  - Item
  - object/varies
---


###### Spell scroll
_Scroll, varies_<span class="sub2">:FasWandMagicSparkles: Magic Item</span>
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>A _Spell Scroll_ bears the words of a single spell, written in a mystical cipher. If the spell is on your spell list, you can read the scroll and cast its spell without Material components. Otherwise, the scroll is unintelligible. Casting the spell by reading the scroll requires the spell’s normal casting time. Once the spell is cast, the scroll crumbles to dust. If the casting is interrupted, the scroll isn’t lost.
>
>If the spell is on your spell list but of a higher level than you can normally cast, you make an ability check using your spellcasting ability to determine whether you cast the spell. The DC equals 10 plus the spell’s level. On a failed check, the spell disappears from the scroll with no other effect.
>
>The level of the spell on the scroll determines the spell’s saving throw DC and attack bonus, as well as the scroll’s rarity, as shown in the following table.
>
>#### Spell Scroll
>
|**Spell Level**|**Rarity**|**Save DC**|**Attack Bonus**|
|---|---|---|---|
|***Cantrip***|Common|13|+5|
|***1st***|Common|13|+5|
|***2nd***|Uncommon|13|+5|
|***3rd***|Uncommon|15|+7|
|***4th***|Rare|15|+7|
|***5th***|Rare|17|+9|
|***6th***|Very rare|17|+9|
|***7th***|Very rare|18|+10|
|***8th***|Very rare|18|+10|
|**9th**|Legendary|19|+11|
>
>Copying a Scroll into a **Spellbook**. A Wizard spell on a _Spell Scroll_ can be copied into a spellbook. When a spell is copied in this way, the copier must succeed on an Intelligence ([[Arcana]]) check with a DC equal to 10 plus the spell’s level. On a successful check, the spell is copied. Whether the check succeeds or fails, the _Spell Scroll_ is destroyed.
>
>> **VARIANT: SCROLL MISHAPS**
>> 
>> A creature who tries and fails to cast a spell from a _spell scroll_ must make a DC 10 Intelligence saving throw. If the saving throw fails, roll on the Scroll Mishap table.
>> 
>> #### Scroll Mishap
>> 
>> |**d6**|**Result**|
>> |---|---|
>> |***1***|A surge of magical energy deals the caster 1d6 force damage per level of the spell.|
>> |***2***|The spell affects the caster or an ally (determined randomly) instead of the intended target, or it affects a rando m target nearby if the caster was the intended target.|
>> |***3***|The spell affects a random location within the spell’s range.|
>> |***4***|The spell’s effect is contrary to its normal one, but neither harmful nor beneficial. For instance, a [[Fireball]] might produce an area of harmless cold.|
>> |***5***|The caster suffers a minor but bizarre effect related to the spell. Such effects last only as long as the original spell’s duration, or 1d10 minutes for spells that take effect instantaneously. For example, a [[Fireball]] might cause smoke to billow from the caster’s ears for 1d10 minutes.|
>> |***6***|The spell activates after 1d12 hours. If the caster was the intended target, the spell takes effect normally. If the caster was not the intended target, the spell goes off in the general direction of the intended target, up to the spell’s maximum range, if the target has moved away.|
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
