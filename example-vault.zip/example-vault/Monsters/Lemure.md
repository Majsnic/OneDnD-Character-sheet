---
Type: Fiend
CR: 0
Size: Medium
tags:
  - Monster
  - Fiend
source: SRD 5.2.1
---

```statblock
name: Lemure
size: Medium
type: Fiend (Devil)
alignment: Lawful Evil
ac: 9
hp: 9 (2d8)
hit_dice: 2d8
speed: 20 ft.
stats: [10, 5, 11, 1, 11, 3]
damage_resistances: Cold
damage_immunities: Fire, Poison
condition_immunities: Charmed, Frightened, Poisoned
senses: Darkvision 120 ft. (unimpeded by magical Darkness); Passive Perception 10
languages: Understands Infernal but can’t speak
cr: 0
traits:
  - name: "Hellish Restoration"
    desc: "If the lemure dies in the Nine Hells, it revives with all its Hit Points in 1d10 days unless it is killed by a creature under the effects of a Bless spell or its remains are sprinkled with Holy Water."
actions:
  - name: "Vile Slime"
    desc: "Melee Attack Roll: +2, reach 5 ft. Hit: 2 (1d4) Poison damage."
```

#Monster
