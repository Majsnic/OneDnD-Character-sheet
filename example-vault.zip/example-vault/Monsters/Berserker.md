---
Type: Humanoid
CR: 2
Size: Medium or Small
tags:
  - Monster
  - Humanoid
source: SRD 5.2.1
---

```statblock
name: Berserker
size: Medium or Small
type: Humanoid
alignment: Neutral
ac: 13
hp: 67 (9d8 + 27)
hit_dice: 9d8 + 27
speed: 30 ft.
stats: [16, 12, 17, 9, 11, 9]
gear: Greataxe, Hide Armor
senses: Passive Perception 10
languages: Common
cr: 2
traits:
  - name: "Bloodied Frenzy"
    desc: "While Bloodied, the berserker has Advantage on attack rolls and saving throws."
actions:
  - name: "Greataxe"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 9 (1d12 + 3) Slashing damage."
```

#Monster
