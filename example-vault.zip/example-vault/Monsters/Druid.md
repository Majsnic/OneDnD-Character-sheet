---
Type: Humanoid
CR: 2
Size: Medium or Small
tags:
  - Monster
  - Humanoid
source: SRD 5.2.1
---

```statblock
name: Druid
size: Medium or Small
type: Humanoid (Druid)
alignment: Neutral
ac: 13
hp: 44 (8d8 + 8)
hit_dice: 8d8 + 8
speed: 30 ft.
stats: [10, 12, 13, 12, 16, 11]
skillsaves:
  - Medicine: +5
  - Nature: +3
  - Perception: +5
gear: Studded Leather Armor
senses: Passive Perception 15
languages: Common, Druidic, Sylvan
cr: 2
actions:
  - name: "Multiattack"
    desc: "The druid makes two attacks, using Vine Staff or Verdant Wisp in any combination."
  - name: "Vine Staff"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 7 (1d8 + 3) Bludgeoning damage plus 2 (1d4) Poison damage."
  - name: "Verdant Wisp"
    desc: "Ranged Attack Roll: +5, range 90 ft. Hit: 10 (3d6) Radiant damage."
  - name: "Spellcasting"
    desc: "The druid casts one of the following spells, using Wisdom as the spellcasting ability (spell save DC 13): At Will: Druidcraft, Speak with Animals 2/Day Each: Entangle, Thunderwave 1/Day Each: Animal Messenger, Longstrider, Moonbeam"
```

#Monster
