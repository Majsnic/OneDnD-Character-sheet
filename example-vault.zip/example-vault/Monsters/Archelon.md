---
Type: Beast
CR: 4
Size: Huge
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Archelon
size: Huge
type: Beast (Dinosaur)
alignment: Unaligned
ac: 17
hp: 90 (12d12 + 12)
hit_dice: 12d12 + 12
speed: 20 ft., Swim 80 ft.
stats: [18, 16, 13, 4, 14, 6]
skillsaves:
  - Stealth: +5
senses: Passive Perception 12
languages: None
cr: 4
traits:
  - name: "Amphibious"
    desc: "The archelon can breathe air and water."
actions:
  - name: "Multiattack"
    desc: "The archelon makes two Bite attacks."
  - name: "Bite"
    desc: "Melee Attack Roll: +6, reach 5 ft. Hit: 14 (3d6 + 4) Piercing damage."
```

#Monster
