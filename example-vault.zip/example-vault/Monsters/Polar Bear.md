---
Type: Beast
CR: 2
Size: Large
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Polar Bear
size: Large
type: Beast
alignment: Unaligned
ac: 12
hp: 42 (5d10 + 15)
hit_dice: 5d10 + 15
speed: 40 ft., Swim 40 ft.
stats: [20, 14, 16, 2, 13, 7]
skillsaves:
  - Perception: +5
  - Stealth: +4
damage_resistances: Cold
senses: Darkvision 60 ft.; Passive Perception 15
languages: None
cr: 2
actions:
  - name: "Multiattack"
    desc: "The bear makes two Rend attacks."
  - name: "Rend"
    desc: "Melee Attack Roll: +7, reach 5 ft. Hit: 9 (1d8 + 5) Slashing damage."
```

#Monster
