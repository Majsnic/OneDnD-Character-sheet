---
tags:
  - Sense
source: SRD 5.2.1
---

# Truesight

Within a specified range, you can see in normal and magical darkness, see invisible creatures and objects, automatically detect visual illusions and succeed on saving throws against them, and perceive the original form of a shapechanged creature. You can also see into the Ethereal Plane within that range.

*Paraphrased mechanical summary, written from general knowledge of the SRD rules — treat it as a helpful draft, not a verbatim rules quote.*

#Sense
