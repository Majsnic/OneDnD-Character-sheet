---
Type: Celestial
CR: 11
Size: Large
tags:
  - Monster
  - Celestial
source: SRD 5.2.1
---

```statblock
name: Sphinx of Lore
size: Large
type: Celestial
alignment: Lawful Neutral
ac: 17
hp: 170 (20d10 + 60)
hit_dice: 20d10 + 60
speed: 40 ft., Fly 60 ft.
stats: [18, 15, 16, 18, 18, 18]
skillsaves:
  - Arcana: +12
  - History: +12
  - Perception: +8
  - Religion: +12
damage_resistances: Necrotic, Radiant
damage_immunities: Psychic
condition_immunities: Charmed, Frightened
senses: Truesight 120 ft.; Passive Perception 18
languages: Celestial, Common
cr: 11
traits:
  - name: "Inscrutable"
    desc: "No magic can observe the sphinx remotely or detect its thoughts without its permission. Wisdom (Insight) checks made to ascertain its intentions or sincerity are made with Disadvantage."
  - name: "Legendary Resistance (3/Day, or 4/Day in Lair)"
    desc: "If the sphinx fails a saving throw, it can choose to succeed instead."
actions:
  - name: "Multiattack"
    desc: "The sphinx makes three Claw attacks."
  - name: "Claw"
    desc: "Melee Attack Roll: +8, reach 5 ft. Hit: 14 (3d6 + 4) Slashing damage."
  - name: "Mind-Rending Roar (Recharge 5–6)"
    desc: "Wisdom Saving Throw: DC 16, each enemy in a 300-foot Emanation originating from the sphinx. Failure: 35 (10d6) Psychic damage, and the target has the Incapacitated condition until the start of the sphinx’s next turn."
  - name: "Spellcasting"
    desc: "The sphinx casts one of the following spells, requiring no Material components and using Intelligence as the spellcasting ability (spell save DC 16): At Will: Detect Magic, Identify, Mage Hand, Minor Illusion, Prestidigitation 1/Day Each: Dispel Magic, Legend Lore, Locate Object, Plane Shift, Remove Curse, Tongues"
legendaryactions:
  - name: ""
    desc: "Legendary Action Uses: 3 (4 in Lair). Immediately after another creature’s turn, the sphinx can expend a use to take one of the following actions. The sphinx regains all expended uses at the start of each of its turns."
  - name: "Arcane Prowl"
    desc: "The sphinx can teleport up to 30 feet to an unoccupied space it can see, and it makes one Claw attack."
  - name: "Weight of Years"
    desc: "Constitution Saving Throw: DC 16, one creature the sphinx can see within 120 feet. Failure: The target gains 1 Exhaustion level. While the target has any Exhaustion levels, it appears 3d10 years older. Failure or Success: The sphinx can’t take this action again until the start of its next turn."
```

#Monster
