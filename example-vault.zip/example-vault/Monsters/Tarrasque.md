---
Type: Monstrosity
CR: 30
Size: Gargantuan
tags:
  - Monster
  - Monstrosity
source: SRD 5.2.1
---

```statblock
name: Tarrasque
size: Gargantuan
type: Monstrosity (Titan)
alignment: Unaligned
ac: 25
hp: 697 (34d20 + 340)
hit_dice: 34d20 + 340
speed: 60 ft., Burrow 40 ft., Climb 60 ft.
stats: [30, 11, 30, 3, 11, 11]
saves:
  - Dex: +9
  - Int: +5
  - Wis: +9
  - Cha: +9
skillsaves:
  - Perception: +9
damage_resistances: Bludgeoning, Piercing, Slashing
damage_immunities: Fire, Poison
condition_immunities: Charmed, Deafened, Frightened, Paralyzed, Poisoned
senses: Blindsight 120 ft.; Passive Perception 19
languages: None
cr: 30
traits:
  - name: "Legendary Resistance (6/Day)"
    desc: "If the tarrasque fails a saving throw, it can choose to succeed instead."
  - name: "Magic Resistance"
    desc: "The tarrasque has Advantage on saving throws against spells and other magical effects."
  - name: "Reflective Carapace"
    desc: "If the tarrasque is targeted by a Magic Missile spell or a spell that requires a ranged attack roll, roll 1d6. On a 1–5, the tarrasque is unaffected. On a 6, the tarrasque is unaffected and reflects the spell, turning the caster into the target."
  - name: "Siege Monster"
    desc: "The tarrasque deals double damage to objects and structures."
actions:
  - name: "Multiattack"
    desc: "The tarrasque makes one Bite attack and three other attacks, using Claw or Tail in any combination."
  - name: "Bite"
    desc: "Melee Attack Roll: +19, reach 15 ft. Hit: 36 (4d12 + 10) Piercing damage, and the target has the Grappled condition (escape DC 20). Until the grapple ends, the target has the Restrained condition and can’t teleport."
  - name: "Claw"
    desc: "Melee Attack Roll: +19, reach 15 ft. Hit: 28 (4d8 + 10) Slashing damage."
  - name: "Tail"
    desc: "Melee Attack Roll: +19, reach 30 ft. Hit: 23 (3d8 + 10) Bludgeoning damage. If the target is a Huge or smaller creature, it has the Prone condition."
  - name: "Thunderous Bellow (Recharge 5–6)"
    desc: "Constitution Saving Throw: DC 27, each creature and each object that isn’t being worn or carried in a 150-foot Cone. Failure: 78 (12d12) Thunder damage, and the target has the Deafened and Frightened conditions until the end of its next turn. Success: Half damage only."
bonusactions:
  - name: "Swallow"
    desc: "Strength Saving Throw: DC 27, one Large or smaller creature Grappled by the tarrasque (it can have up to six creatures swallowed at a time). Failure: The target is swallowed, and the Grappled condition ends. A swallowed creature has the Blinded and Restrained conditions and can’t teleport, it has Total Cover against attacks and other effects outside the tarrasque, and it takes 56 (16d6) Acid damage at the start of each of the tarrasque’s turns. If the tarrasque takes 60 damage or more on a single turn from a creature inside it, the tarrasque must succeed on a DC 20 Constitution saving throw at the end of that turn or regurgitate all swallowed creatures, each of which falls in a space within 10 feet of the tarrasque and has the Prone condition. If the tarrasque dies, any swallowed creature no longer has the Restrained condition and can escape from the corpse using 20 feet of movement, exiting Prone."
legendaryactions:
  - name: ""
    desc: "Legendary Action Uses: 3. Immediately after another creature’s turn, the tarrasque can expend a use to take one of the following actions. The tarrasque regains all expended uses at the start of each of its turns."
  - name: "Onslaught"
    desc: "The tarrasque moves up to half its Speed, and it makes one Claw or Tail attack."
  - name: "World-Shaking Movement"
    desc: "The tarrasque moves up to its Speed. At the end of this movement, the tarrasque creates an instantaneous shock wave in a 60-foot Emanation originating from itself. Creatures in that area lose Concentration and, if Medium or smaller, have the Prone condition. The tarrasque can’t take this action again until the start of its next turn."
```

#Monster
