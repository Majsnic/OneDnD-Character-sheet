---
Spell level: 1
School type: Divination
Casting Time: Action or Ritual
Components:
  - Verbal
  - Somatic
Concentration: true
Duration: 10 minutes
Range / Area: Self
Attack / Save: None
Damage / Effect: Utility
Upscale: 
category: 1st level
---
_Level 1 Divination_

- **Casting time:** Action or Ritual
- **Range:** Self
- **Components:** V, S
- **Duration:** 10 minutes
- **Attack/Save**: None
- **Damage/Effect**: Utility

For the duration, you sense the presence of magical effects within 30 feet of yourself. If you sense such effects, you can take the Magic action to see a faint aura around any visible creature or object in the area that bears the magic, and if an effect was created by a spell, you learn the spell’s school of magic. The spell is blocked by 1 foot of stone, dirt, or wood; 1 inch of metal; or a thin sheet of lead.

#Spell
