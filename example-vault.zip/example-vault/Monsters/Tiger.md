---
Type: Beast
CR: 1
Size: Large
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Tiger
size: Large
type: Beast
alignment: Unaligned
ac: 13
hp: 30 (4d10 + 8)
hit_dice: 4d10 + 8
speed: 40 ft.
stats: [17, 16, 14, 3, 12, 8]
skillsaves:
  - Perception: +3
  - Stealth: +7
senses: Darkvision 60 ft.; Passive Perception 13
languages: None
cr: 1
actions:
  - name: "Rend"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 10 (2d6 + 3) Slashing damage. If the target is a Large or smaller creature, it has the Prone condition."
bonusactions:
  - name: "Nimble Escape"
    desc: "The tiger takes the Disengage or Hide action."
```

#Monster
