---
Spell level: 1
School type: Illusion
Casting Time: Action
Components:
  - Verbal
  - Somatic
  - Material
Concentration: false
Duration: Instantaneous
Range / Area: Self
Attack / Save: CON Save
Damage / Effect: Blinded
Upscale: 
category: 1st level
---
_Level 1 Illusion_

- **Casting time:** Action
- **Range:** Self
- **Components:** V, S, M
- **Duration:** Instantaneous
- **Attack/Save**: CON Save
- **Damage/Effect**: Blinded

You launch a dazzling array of flashing, colorful light. Each creature in a 15-foot Cone originating from you must succeed on a Constitution saving throw or have the Blinded condition until the end of your next turn.

#Spell
