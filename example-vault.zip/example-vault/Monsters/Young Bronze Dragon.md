---
Type: Dragon
CR: 8
Size: Large
tags:
  - Monster
  - Dragon
source: SRD 5.2.1
---

```statblock
name: Young Bronze Dragon
size: Large
type: Dragon (Metallic)
alignment: Lawful Good
ac: 17
hp: 142 (15d10 + 60)
hit_dice: 15d10 + 60
speed: 40 ft., Fly 80 ft., Swim 40 ft.
stats: [21, 10, 19, 14, 13, 17]
saves:
  - Dex: +3
  - Wis: +4
skillsaves:
  - Insight: +4
  - Perception: +7
  - Stealth: +3
damage_immunities: Lightning
senses: Blindsight 30 ft., Darkvision 120 ft.; Passive Perception 17
languages: Common, Draconic
cr: 8
traits:
  - name: "Amphibious"
    desc: "The dragon can breathe air and water."
actions:
  - name: "Multiattack"
    desc: "The dragon makes three Rend attacks. It can replace one attack with a use of Repulsion Breath."
  - name: "Rend"
    desc: "Melee Attack Roll: +8, reach 10 ft. Hit: 16 (2d10 + 5) Slashing damage."
  - name: "Lightning Breath (Recharge 5–6)"
    desc: "Dexterity Saving Throw: DC 15, each creature in a 60-foot-long, 5-footwide Line. Failure: 49 (9d10) Lightning damage. Success: Half damage."
  - name: "Repulsion Breath"
    desc: "Strength Saving Throw: DC 15, each creature in a 30-foot Cone. Failure: The target is pushed up to 40 feet straight away from the dragon and has the Prone condition."
```

#Monster
