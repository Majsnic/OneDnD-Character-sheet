---
Type: Beast
CR: 1/4
Size: Medium
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Boar
size: Medium
type: Beast
alignment: Unaligned
ac: 11
hp: 13 (2d8 + 4)
hit_dice: 2d8 + 4
speed: 40 ft.
stats: [13, 11, 14, 2, 9, 5]
senses: Passive Perception 9
languages: None
cr: 1/4
traits:
  - name: "Bloodied Fury"
    desc: "While Bloodied, the boar has Advantage on attack rolls."
actions:
  - name: "Gore"
    desc: "Melee Attack Roll: +3, reach 5 ft. Hit: 4 (1d6 + 1) Piercing damage. If the target is a Medium or smaller creature and the boar moved 20+ feet straight toward it immediately before the hit, the target takes an extra 3 (1d6) Piercing damage and has the Prone condition."
```

#Monster
