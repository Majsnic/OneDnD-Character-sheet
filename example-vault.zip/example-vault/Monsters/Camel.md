---
Type: Beast
CR: 1/8
Size: Large
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Camel
size: Large
type: Beast
alignment: Unaligned
ac: 10
hp: 17 (2d10 + 6)
hit_dice: 2d10 + 6
speed: 50 ft.
stats: [15, 8, 17, 2, 11, 5]
saves:
  - Con: +5
senses: Darkvision 60 ft.; Passive Perception 10
languages: None
cr: 1/8
actions:
  - name: "Bite"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 4 (1d4 + 2) Bludgeoning damage."
```

#Monster
