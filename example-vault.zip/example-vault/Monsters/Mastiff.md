---
Type: Beast
CR: 1/8
Size: Medium
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Mastiff
size: Medium
type: Beast
alignment: Unaligned
ac: 12
hp: 5 (1d8 + 1)
hit_dice: 1d8 + 1
speed: 40 ft.
stats: [13, 14, 12, 3, 12, 7]
saves:
  - Wis: +3
skillsaves:
  - Perception: +5
senses: Darkvision 60 ft.; Passive Perception 15
languages: None
cr: 1/8
actions:
  - name: "Bite"
    desc: "Melee Attack Roll: +3, reach 5 ft. Hit: 4 (1d6 + 1) Piercing damage. If the target is a Medium or smaller creature, it has the Prone condition."
```

#Monster
