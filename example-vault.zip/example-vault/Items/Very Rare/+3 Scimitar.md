---
Rarity: Very Rare
type: object
tags:
  - Item
  - item/very-rare
  - item/weapon
item_category: Weapon
item_base: "Scimitar"
weapon_category: "Martial Melee"
damage_dice: "1d6"
damage_type: Slashing
weapon_properties: [Finesse, Light]
weapon_mastery: Nick
requires_attunement: false
attunement_note: ""
attack_bonus: 3
damage_bonus: 3
---


###### +3 Scimitar
_Weapon (scimitar), very rare_<span class="sub2">:FasWandMagicSparkles: Magic Item</span>
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>You have a +3 bonus to attack and damage rolls made with this magic weapon.
>
>**1d6+3 Slashing damage.** Properties: Finesse, Light.
>
>- **Finesse.** You can use your Strength or Dexterity modifier for attack and damage rolls with this weapon.
>- **Light.** You can make an extra attack with a second Light weapon as a Bonus Action (Two-Weapon Fighting) without adding your ability modifier to the extra attack's damage unless it's negative.
>
>**_Nick (Mastery)._** When you take the Attack action and attack with this Light weapon, you can make one of your extra attacks from Two-Weapon Fighting as part of that action instead of as a Bonus Action. You can make this extra attack only once per turn, and if you do, you subtract 1d4 from the damage of the weapon's other attacks this turn.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
