---
Type: Beast
CR: 0
Size: Small
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Giant Fire Beetle
size: Small
type: Beast
alignment: Unaligned
ac: 13
hp: 4 (1d6 + 1)
hit_dice: 1d6 + 1
speed: 30 ft., Climb 30 ft.
stats: [8, 10, 12, 1, 7, 3]
damage_resistances: Fire
senses: Blindsight 30 ft.; Passive Perception 8
languages: None
cr: 0
traits:
  - name: "Illumination"
    desc: "The beetle sheds Bright Light in a 10-foot radius and Dim Light for an additional 10 feet."
actions:
  - name: "Bite"
    desc: "Melee Attack Roll: +1, reach 5 ft. Hit: 1 Fire damage."
```

#Monster
