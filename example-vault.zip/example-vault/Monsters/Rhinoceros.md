---
Type: Beast
CR: 2
Size: Large
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Rhinoceros
size: Large
type: Beast
alignment: Unaligned
ac: 13
hp: 45 (6d10 + 12)
hit_dice: 6d10 + 12
speed: 40 ft.
stats: [21, 8, 15, 2, 12, 6]
senses: Passive Perception 11
languages: None
cr: 2
actions:
  - name: "Gore"
    desc: "Melee Attack Roll: +7, reach 5 ft. Hit: 14 (2d8 + 5) Piercing damage. If target is a Large or smaller creature and the rhinoceros moved 20+ feet straight toward it immediately before the hit, the target takes an extra 9 (2d8) Piercing damage and has the Prone condition."
```

#Monster
