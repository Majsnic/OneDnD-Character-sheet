---
Spell level: 3
School type: Necromancy
Casting Time: 1 minute
Components:
  - Verbal
  - Somatic
  - Material
Concentration: false
Duration: Instantaneous
Range / Area: 10 feet
Attack / Save: None
Damage / Effect: Utility
Upscale: 
category: 3rd level
---
_Level 3 Necromancy_

- **Casting time:** 1 minute
- **Range:** 10 feet
- **Components:** V, S, M
- **Duration:** Instantaneous
- **Attack/Save**: None
- **Damage/Effect**: Utility

Choose a pile of bones or a corpse of a Medium or Small Humanoid within range. The target becomes an Undead creature: a Skeleton if you chose bones or a Zombie if you chose a corpse (see “Monsters” for the stat blocks). On each of your turns, you can take a Bonus Action to mentally command any creature you made with this spell if the creature is within 60 feet of you (if you control multiple creatures, you can command any of them at the same time, issuing the same command to each one). You decide what action the creature will take and where it will move on its next turn, or you can issue a general command, such as to guard a chamber or corridor. If you issue no commands, the creature takes the Dodge action and moves only to avoid harm. Once given an order, the creature continues to follow it until its task is complete. The creature is under your control for 24 hours, after which it stops obeying any command you’ve given it. To maintain control of the creature for another 24 hours, you must cast this spell on the creature again before the current 24-hour period ends. This use of the spell reasserts your control over up to four creatures you have animated with this spell rather than animating a new creature.

**_Using a Higher-Level Spell Slot._** You animate or reassert control over two additional Undead creatures for each spell slot level above 3. Each of the creatures must come from a different corpse or pile of bones.

#Spell
