---
Spell level: 1
School type: Evocation
Casting Time: Action
Components:
  - Verbal
  - Somatic
  - Material
Concentration: false
Duration: Instantaneous
Range / Area: 90 feet
Attack / Save: Ranged
Damage / Effect: Utility
Upscale: + 1d8
category: 1st level
---
_Level 1 Evocation_

- **Casting time:** Action
- **Range:** 90 feet
- **Components:** V, S, M
- **Duration:** Instantaneous
- **Attack/Save**: Ranged
- **Damage/Effect**: Utility

You hurl an orb of energy at a target within range. Choose Acid, Cold, Fire, Lightning, Poison, or Thunder for the type of orb you create, and then make a ranged spell attack against the target. On a hit, the target takes 3d8 damage of the chosen type. If you roll the same number on two or more of the d8s, the orb leaps to a different target of your choice within 30 feet of the target. Make an attack roll against the new target, and make a new damage roll. The orb can’t leap again unless you cast the spell with a level 2+ spell slot.

**_Using a Higher-Level Spell Slot._** The damage increases by 1d8 for each spell slot level above 1. The orb can leap a maximum number of times equal to the level of the slot expended, and a creature can be targeted only once by each casting of this spell.

#Spell
