---
Spell level: 3
School type: Abjuration
Casting Time: Action
Components:
  - Verbal
  - Somatic
Concentration: false
Duration: Instantaneous
Range / Area: Touch
Attack / Save: None
Damage / Effect: Utility
Upscale: 
category: 3rd level
---
_Level 3 Abjuration_

- **Casting time:** Action
- **Range:** Touch
- **Components:** V, S
- **Duration:** Instantaneous
- **Attack/Save**: None
- **Damage/Effect**: Utility

At your touch, all curses affecting one creature or object end. If the object is a cursed magic item, its curse remains, but the spell breaks its owner’s Attunement to the object so it can be removed or discarded.

#Spell
