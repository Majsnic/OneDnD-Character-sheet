---
Type: Beast
CR: 2
Size: Large
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Plesiosaurus
size: Large
type: Beast (Dinosaur)
alignment: Unaligned
ac: 13
hp: 68 (8d10 + 24)
hit_dice: 8d10 + 24
speed: 20 ft., Swim 40 ft.
stats: [18, 15, 16, 2, 12, 5]
skillsaves:
  - Perception: +3
  - Stealth: +4
senses: Passive Perception 13
languages: None
cr: 2
traits:
  - name: "Hold Breath"
    desc: "The plesiosaurus can hold its breath for 1 hour."
actions:
  - name: "Bite"
    desc: "Melee Attack Roll: +6, reach 10 ft. Hit: 11 (2d6 + 4) Piercing damage."
```

#Monster
