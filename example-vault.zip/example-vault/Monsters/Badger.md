---
Type: Beast
CR: 0
Size: Tiny
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Badger
size: Tiny
type: Beast
alignment: Unaligned
ac: 11
hp: 5 (1d4 + 3)
hit_dice: 1d4 + 3
speed: 20 ft., Burrow 5 ft.
stats: [10, 11, 16, 2, 12, 5]
skillsaves:
  - Perception: +3
damage_resistances: Poison
senses: Darkvision 30 ft.; Passive Perception 13
languages: None
cr: 0
actions:
  - name: "Bite"
    desc: "Melee Attack Roll: +2, reach 5 ft. Hit: 1 Piercing damage."
```

#Monster
