---
Type: Undead
CR: 1/2
Size: Medium
tags:
  - Monster
  - Undead
source: SRD 5.2.1
---

```statblock
name: Shadow
size: Medium
type: Undead
alignment: Chaotic Evil
ac: 12
hp: 27 (5d8 + 5)
hit_dice: 5d8 + 5
speed: 40 ft.
stats: [6, 14, 13, 6, 10, 8]
skillsaves:
  - Stealth: +6
damage_vulnerabilities: Radiant
damage_resistances: Acid, Cold, Fire, Lightning, Thunder
damage_immunities: Necrotic, Poison
condition_immunities: Exhaustion, Frightened, Grappled, Paralyzed, Petrified, Poisoned, Prone, Restrained, Unconscious
senses: Darkvision 60 ft.; Passive Perception 10
languages: None
cr: 1/2
traits:
  - name: "Amorphous"
    desc: "The shadow can move through a space as narrow as 1 inch without expending extra movement to do so."
  - name: "Sunlight Weakness"
    desc: "While in sunlight, the shadow has Disadvantage on D20 Tests."
actions:
  - name: "Draining Swipe"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 5 (1d6 + 2) Necrotic damage, and the target’s Strength score decreases by 1d4. The target dies if this reduces that score to 0. If a Humanoid is slain by this attack, a Shadow rises from the corpse 1d4 hours later."
bonusactions:
  - name: "Shadow Stealth"
    desc: "While in Dim Light or Darkness, the shadow takes the Hide action."
```

#Monster
