---
Type: Undead
CR: 1/2
Size: Large
tags:
  - Monster
  - Undead
source: SRD 5.2.1
---

```statblock
name: Warhorse Skeleton
size: Large
type: Undead
alignment: Lawful Evil
ac: 13
hp: 22 (3d10 + 6)
hit_dice: 3d10 + 6
speed: 60 ft.
stats: [18, 12, 15, 2, 8, 5]
damage_vulnerabilities: Bludgeoning
damage_immunities: Poison
condition_immunities: Exhaustion, Poisoned
senses: Darkvision 60 ft.; Passive Perception 9
languages: None
cr: 1/2
actions:
  - name: "Hooves"
    desc: "Melee Attack Roll: +6, reach 5 ft. Hit: 7 (1d6 + 4) Bludgeoning damage. If the target is a Large or smaller creature and the skeleton moved 20+ feet straight toward it immediately before the hit, the target has the Prone condition."
```

#Monster
