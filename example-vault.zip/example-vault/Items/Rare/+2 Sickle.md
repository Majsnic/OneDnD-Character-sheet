---
Rarity: Rare
type: object
tags:
  - Item
  - item/rare
  - item/weapon
item_category: Weapon
item_base: "Sickle"
weapon_category: "Simple Melee"
damage_dice: "1d4"
damage_type: Slashing
weapon_properties: [Light]
weapon_mastery: Nick
requires_attunement: false
attunement_note: ""
attack_bonus: 2
damage_bonus: 2
---


###### +2 Sickle
_Weapon (sickle), rare_<span class="sub2">:FasWandMagicSparkles: Magic Item</span>
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>You have a +2 bonus to attack and damage rolls made with this magic weapon.
>
>**1d4+2 Slashing damage.** Properties: Light.
>
>- **Light.** You can make an extra attack with a second Light weapon as a Bonus Action (Two-Weapon Fighting) without adding your ability modifier to the extra attack's damage unless it's negative.
>
>**_Nick (Mastery)._** When you take the Attack action and attack with this Light weapon, you can make one of your extra attacks from Two-Weapon Fighting as part of that action instead of as a Bonus Action. You can make this extra attack only once per turn, and if you do, you subtract 1d4 from the damage of the weapon's other attacks this turn.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
