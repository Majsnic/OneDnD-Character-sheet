---
Type: Undead
CR: 13
Size: Medium or Small
tags:
  - Monster
  - Undead
source: SRD 5.2.1
---

```statblock
name: Vampire
size: Medium or Small
type: Undead
alignment: Lawful Evil
ac: 16
hp: 195 (23d8 + 92)
hit_dice: 23d8 + 92
speed: 40 ft., Climb 40 ft.
stats: [18, 18, 18, 17, 15, 18]
saves:
  - Dex: +9
  - Con: +9
  - Wis: +7
  - Cha: +9
skillsaves:
  - Perception: +7
  - Stealth: +9
damage_resistances: Necrotic
senses: Darkvision 120 ft.; Passive Perception 17
languages: Common plus two other languages
cr: 13
traits:
  - name: "Legendary Resistance (3/Day, or 4/Day in Lair)"
    desc: "If the vampire fails a saving throw, it can choose to succeed instead."
  - name: "Misty Escape"
    desc: "If the vampire drops to 0 Hit Points outside its resting place, the vampire uses Shape-Shift to become mist (no action required). If it can’t use ShapeShift, it is destroyed. While it has 0 Hit Points in mist form, it can’t return to its vampire form, and it must reach its resting place within 2 hours or be destroyed. Once in its resting place, it returns to its vampire form and has the Paralyzed condition until it regains any Hit Points, and it regains 1 Hit Point after spending 1 hour there."
  - name: "Spider Climb"
    desc: "The vampire can climb difficult surfaces, including along ceilings, without needing to make an ability check."
  - name: "Vampire Weakness"
    desc: "The vampire has these weaknesses: Forbiddance. The vampire can’t enter a residence without an invitation from an occupant."
  - name: "Running Water"
    desc: "The vampire takes 20 Acid damage if it ends its turn in running water."
  - name: "Stake to the Heart"
    desc: "If a weapon that deals Piercing damage is driven into the vampire’s heart while the vampire has the Incapacitated condition in its resting place, the vampire has the Paralyzed condition until the weapon is removed."
  - name: "Sunlight"
    desc: "The vampire takes 20 Radiant damage if it starts its turn in sunlight. While in sunlight, it has Disadvantage on attack rolls and ability checks."
actions:
  - name: "Multiattack (Vampire Form Only)"
    desc: "The vampire makes two Grave Strike attacks and uses Bite."
  - name: "Grave Strike (Vampire Form Only)"
    desc: "Melee Attack Roll: +9, reach 5 ft. Hit: 8 (1d8 + 4) Bludgeoning damage plus 7 (2d6) Necrotic damage. If the target is a Large or smaller creature, it has the Grappled condition (escape DC 14) from one of two hands."
  - name: "Bite (Bat or Vampire Form Only)"
    desc: "Constitution Saving Throw: DC 17, one creature within 5 feet that is willing or that has the Grappled, Incapacitated, or Restrained condition. Failure: 6 (1d4 + 4) Piercing damage plus 13 (3d8) Necrotic damage. The target’s Hit Point maximum decreases by an amount equal to the Necrotic damage taken, and the vampire regains Hit Points equal to that amount. A Humanoid reduced to 0 Hit Points by this damage and then buried rises the following sunset as a Vampire Spawn under the vampire’s control."
bonusactions:
  - name: "Charm (Recharge 5–6)"
    desc: "The vampire casts Charm Person, requiring no spell components and using Charisma as the spellcasting ability (spell save DC 17), and the duration is 24 hours. The Charmed target is a willing recipient of the vampire’s Bite, the damage of which doesn’t end the spell. When the spell ends, the target is unaware it was Charmed by the vampire."
  - name: "Shape-Shift"
    desc: "If the vampire isn’t in sunlight or running water, it shape-shifts into a Tiny bat (Speed 5 ft., Fly Speed 30 ft.) or a Medium cloud of mist (Speed 5 ft., Fly Speed 20 ft. [hover]), or it returns to its vampire form. Anything it is wearing transforms with it. While in bat form, the vampire can’t speak. Its game statistics, other than its size and Speed, are unchanged. While in mist form, the vampire can’t take any actions, speak, or manipulate objects. It is weightless and can enter an enemy’s space and stop there. If air can pass through a space, the mist can do so, but it can’t pass through liquid. It has Resistance to all damage, except the damage it takes from sunlight."
legendaryactions:
  - name: ""
    desc: "Legendary Action Uses: 3 (4 in Lair). Immediately after another creature’s turn, the vampire can expend a use to take one of the following actions. The vampire regains all expended uses at the start of each of its turns."
  - name: "Beguile"
    desc: "The vampire casts Command, requiring no spell components and using Charisma as the spellcasting ability (spell save DC 17). The vampire can’t take this action again until the start of its next turn."
  - name: "Deathless Strike"
    desc: "The vampire moves up to half its Speed, and it makes one Grave Strike attack."
```

#Monster
