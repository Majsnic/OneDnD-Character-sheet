---
Type: Beast
CR: 6
Size: Huge
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Mammoth
size: Huge
type: Beast
alignment: Unaligned
ac: 13
hp: 126 (11d12 + 55)
hit_dice: 11d12 + 55
speed: 50 ft.
stats: [24, 9, 21, 3, 11, 6]
saves:
  - Str: +10
  - Con: +8
senses: Passive Perception 10
languages: None
cr: 6
actions:
  - name: "Multiattack"
    desc: "The mammoth makes two Gore attacks."
  - name: "Gore"
    desc: "Melee Attack Roll: +10, reach 10 ft. Hit: 18 (2d10 + 7) Piercing damage. If the target is a Huge or smaller creature and the mammoth moved 20+ feet straight toward it immediately before the hit, the target has the Prone condition."
bonusactions:
  - name: "Trample"
    desc: "Dexterity Saving Throw: DC 18, one creature within 5 feet that has the Prone condition. Failure: 29 (4d10 + 7) Bludgeoning damage. Success: Half damage."
```

#Monster
