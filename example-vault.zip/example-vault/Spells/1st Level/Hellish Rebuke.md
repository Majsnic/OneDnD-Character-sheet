---
Spell level: 1
School type: Evocation
Casting Time: Reaction*
Components:
  - Verbal
  - Somatic
Concentration: false
Duration: Instantaneous
Range / Area: 60 feet
Attack / Save: DEX Save
Damage / Effect: 2d10 Fire
Upscale: + 1d10
category: 1st level
---
_Level 1 Evocation_

- **Casting time:** Reaction*
- **Range:** 60 feet
- **Components:** V, S
- **Duration:** Instantaneous
- **Attack/Save**: DEX Save
- **Damage/Effect**: Fire

_* - which you take in response to taking damage from a creature that you can see within 60 feet of yourself_

The creature that damaged you is momentarily surrounded by green flames. It makes a Dexterity saving throw, taking 2d10 Fire damage on a failed save or half as much damage on a successful one.

**_Using a Higher-Level Spell Slot._** The damage increases by 1d10 for each spell slot level above 1.

#Spell
