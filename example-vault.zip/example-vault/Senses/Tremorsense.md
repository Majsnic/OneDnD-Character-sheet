---
tags:
  - Sense
source: SRD 5.2.1
---

# Tremorsense

Within a specified range, you can detect and pinpoint the origin of vibrations, as long as you and the source of those vibrations are both in contact with the same surface (such as the ground) or substance (such as water). Tremorsense can't be used to detect flying or incorporeal creatures.

*Paraphrased mechanical summary, written from general knowledge of the SRD rules — treat it as a helpful draft, not a verbatim rules quote.*

#Sense
