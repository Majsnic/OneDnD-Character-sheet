---
tags:
  - Feat
source: SRD 5.2.1
---

# Savage Attacker

**Type:** Origin Feat
**Repeatable:** No

Once per turn, when you hit a target with a weapon attack, you can roll the weapon's damage dice twice and use either total.

*Paraphrased mechanical summary, written from general knowledge of the SRD rules — treat it as a helpful draft, not a verbatim rules quote.*

#Feat
