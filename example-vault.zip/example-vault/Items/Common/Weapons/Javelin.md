---
type: object
tags:
  - Item
  - item/common
  - item/weapon
item_category: Weapon
weapon_category: "Simple Melee"
damage_dice: "1d6"
damage_type: Piercing
weapon_properties: [Thrown]
range_normal: 30
range_long: 120
attack_bonus: 0
damage_bonus: 0
cost: "5 SP"
weight_lb: 2
---


###### Javelin
_Simple Melee Weapon_
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>**1d6 Piercing damage.** Range 30/120 ft. Cost 5 SP, weight 2 lb.
>
>- **Thrown.** You can throw this weapon to make a ranged attack, using the same ability modifier for the attack and damage rolls that you use for a melee attack with the weapon.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
