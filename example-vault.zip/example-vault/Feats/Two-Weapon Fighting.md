---
tags:
  - Feat
source: SRD 5.2.1
---

# Two-Weapon Fighting

**Type:** Fighting Style Feat
**Prerequisite:** A class feature that lets you choose a Fighting Style
**Repeatable:** No

When you engage in two-weapon fighting, you can add your ability modifier to the damage of the second attack.

*Paraphrased mechanical summary, written from general knowledge of the SRD rules — treat it as a helpful draft, not a verbatim rules quote.*

#Feat
