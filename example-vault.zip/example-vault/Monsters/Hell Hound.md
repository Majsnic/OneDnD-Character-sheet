---
Type: Fiend
CR: 3
Size: Medium
tags:
  - Monster
  - Fiend
source: SRD 5.2.1
---

```statblock
name: Hell Hound
size: Medium
type: Fiend
alignment: Lawful Evil
ac: 15
hp: 58 (9d8 + 18)
hit_dice: 9d8 + 18
speed: 50 ft.
stats: [17, 12, 14, 6, 13, 6]
skillsaves:
  - Perception: +5
damage_immunities: Fire
senses: Darkvision 60 ft.; Passive Perception 15
languages: Understands Infernal but can’t speak
cr: 3
traits:
  - name: "Pack Tactics"
    desc: "The hound has Advantage on an attack roll against a creature if at least one of the hound’s allies is within 5 feet of the creature and the ally doesn’t have the Incapacitated condition."
actions:
  - name: "Multiattack"
    desc: "The hound makes two Bite attacks."
  - name: "Bite"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 7 (1d8 + 3) Piercing damage plus 3 (1d6) Fire damage."
  - name: "Fire Breath (Recharge 5–6)"
    desc: "Dexterity Saving Throw: DC 12, each creature in a 15-foot Cone. Failure: 17 (5d6) Fire damage. Success: Half damage."
```

#Monster
