---
Spell level: 1
School type: Transmutation
Casting Time: Reaction*
Components:
  - Verbal
  - Material
Concentration: false
Duration: 1 minute
Range / Area: 60 feet
Attack / Save: None
Damage / Effect: Utility
Upscale: 
category: 1st level
---
_Level 1 Transmutation_

- **Casting time:** Reaction*
- **Range:** 60 feet
- **Components:** V, M
- **Duration:** 1 minute
- **Attack/Save**: None
- **Damage/Effect**: Utility

_* - which you take when you or a creature you can see within 60 feet of you falls_

Choose up to five falling creatures within range. A falling creature’s rate of descent slows to 60 feet per round until the spell ends. If a creature lands before the spell ends, the creature takes no damage from the fall, and the spell ends for that creature.

#Spell
