---
Rarity: Uncommon
type: object
tags:
  - Item
  - item/uncommon
  - item/weapon
item_category: Weapon
item_base: "Mace"
weapon_category: "Simple Melee"
damage_dice: "1d6"
damage_type: Bludgeoning
weapon_properties: []
weapon_mastery: Sap
requires_attunement: false
attunement_note: ""
attack_bonus: 1
damage_bonus: 1
---


###### +1 Mace
_Weapon (mace), uncommon_<span class="sub2">:FasWandMagicSparkles: Magic Item</span>
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>You have a +1 bonus to attack and damage rolls made with this magic weapon.
>
>**1d6+1 Bludgeoning damage.**
>
>**_Sap (Mastery)._** If you hit a creature with this weapon and deal damage to it, that creature has Disadvantage on its next attack roll before the start of your next turn.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
