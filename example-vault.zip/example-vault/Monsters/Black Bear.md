---
Type: Beast
CR: 1/2
Size: Medium
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Black Bear
size: Medium
type: Beast
alignment: Unaligned
ac: 11
hp: 19 (3d8 + 6)
hit_dice: 3d8 + 6
speed: 30 ft., Climb 30 ft., Swim 30 ft.
stats: [15, 12, 14, 2, 12, 7]
skillsaves:
  - Perception: +5
senses: Darkvision 60 ft.; Passive Perception 15
languages: None
cr: 1/2
actions:
  - name: "Multiattack"
    desc: "The bear makes two Rend attacks."
  - name: "Rend"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 5 (1d6 + 2) Slashing damage."
```

#Monster
