---
Type: Giant
CR: 1/2
Size: Small
tags:
  - Monster
  - Giant
source: SRD 5.2.1
---

```statblock
name: Troll Limb
size: Small
type: Giant
alignment: Chaotic Evil
ac: 13
hp: 14 (4d6)
hit_dice: 4d6
speed: 20 ft.
stats: [18, 12, 10, 1, 9, 1]
senses: Darkvision 60 ft.; Passive Perception 9
languages: None
cr: 1/2
traits:
  - name: "Regeneration"
    desc: "The limb regains 5 Hit Points at the start of each of its turns. If the limb takes Acid or Fire damage, this trait doesn’t function on the limb’s next turn. The limb dies only if it starts its turn with 0 Hit Points and doesn’t regenerate."
  - name: "Troll Spawn"
    desc: "The limb uncannily has the same senses as a whole troll. If the limb isn’t destroyed within 24 hours, roll 1d12. On a 12, the limb turns into a Troll. Otherwise, the limb withers away."
actions:
  - name: "Rend"
    desc: "Melee Attack Roll: +6, reach 5 ft. Hit: 9 (2d4 + 4) Slashing damage."
```

#Monster
