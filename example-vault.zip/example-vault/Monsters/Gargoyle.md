---
Type: Elemental
CR: 2
Size: Medium
tags:
  - Monster
  - Elemental
source: SRD 5.2.1
---

```statblock
name: Gargoyle
size: Medium
type: Elemental
alignment: Chaotic Evil
ac: 15
hp: 67 (9d8 + 27)
hit_dice: 9d8 + 27
speed: 30 ft., Fly 60 ft.
stats: [15, 11, 16, 6, 11, 7]
skillsaves:
  - Stealth: +4
damage_immunities: Poison
condition_immunities: Exhaustion, Petrified, Poisoned
senses: Darkvision 60 ft.; Passive Perception 10
languages: Primordial (Terran)
cr: 2
traits:
  - name: "Flyby"
    desc: "The gargoyle doesn’t provoke an Opportunity Attack when it flies out of an enemy’s reach."
actions:
  - name: "Multiattack"
    desc: "The gargoyle makes two Claw attacks."
  - name: "Claw"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 7 (2d4 + 2) Slashing damage."
```

#Monster
