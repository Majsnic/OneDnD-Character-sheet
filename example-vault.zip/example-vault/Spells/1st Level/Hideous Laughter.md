---
Spell level: 1
School type: Enchantment
Casting Time: Action
Components:
  - Verbal
  - Somatic
  - Material
Concentration: true
Duration: 1 minute
Range / Area: 30 feet
Attack / Save: WIS Save
Damage / Effect: Incapacitated
Upscale: + 1 creature
category: 1st level
---
_Level 1 Enchantment_

- **Casting time:** Action
- **Range:** 30 feet
- **Components:** V, S, M
- **Duration:** 1 minute
- **Attack/Save**: WIS Save
- **Damage/Effect**: Incapacitated

One creature of your choice that you can see within range makes a Wisdom saving throw. On a failed save, it has the Prone and Incapacitated conditions for the duration. During that time, it laughs uncontrollably if it’s capable of laughter, and it can’t end the Prone condition on itself. At the end of each of its turns and each time it takes damage, it makes another Wisdom saving throw. The target has Advantage on the save if the save is triggered by damage. On a successful save, the spell ends.

**_Using a Higher-Level Spell Slot._** You can target one additional creature for each spell slot level above 1.

#Spell
