---
Type: Beast
CR: 3
Size: Huge
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Ankylosaurus
size: Huge
type: Beast (Dinosaur)
alignment: Unaligned
ac: 15
hp: 68 (8d12 + 16)
hit_dice: 8d12 + 16
speed: 30 ft.
stats: [19, 11, 15, 2, 12, 5]
saves:
  - Str: +6
senses: Passive Perception 11
languages: None
cr: 3
actions:
  - name: "Multiattack"
    desc: "The ankylosaurus makes two Tail attacks."
  - name: "Tail"
    desc: "Melee Attack Roll: +6, reach 10 ft. Hit: 9 (1d10 + 4) Bludgeoning damage. If the target is a Huge or smaller creature, it has the Prone condition."
```

#Monster
