---
Type: Beast
CR: 1/4
Size: Large
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Draft Horse
size: Large
type: Beast
alignment: Unaligned
ac: 10
hp: 15 (2d10 + 4)
hit_dice: 2d10 + 4
speed: 40 ft.
stats: [18, 10, 15, 2, 11, 7]
senses: Passive Perception 10
languages: None
cr: 1/4
actions:
  - name: "Hooves"
    desc: "Melee Attack Roll: +6, reach 5 ft. Hit: 6 (1d4 + 4) Bludgeoning damage."
```

#Monster
