---
Spell level: 4
School type: Conjuration
Casting Time: Action
Components:
  - Verbal
  - Somatic
Concentration: true
Duration: 10 minutes
Range / Area: 60 feet
Attack / Save: None
Damage / Effect: Utility
Upscale: 
category: 4th level
---
_Level 4 Conjuration_

- **Casting time:** Action
- **Range:** 60 feet
- **Components:** V, S
- **Duration:** 10 minutes
- **Attack/Save**: None
- **Damage/Effect**: Utility

You summon a giant centipede, spider, or wasp (chosen when you cast the spell). It manifests in an unoccupied space you can see within range and uses the Giant Insect stat block. The form you choose determines certain details in its stat block. The creature disappears when it drops to 0 Hit Points or when the spell ends. The creature is an ally to you and your allies. In combat, the creature shares your Initiative count, but it takes its turn immediately after yours. It obeys your verbal commands (no action required by you). If you don’t issue any, it takes the Dodge action and uses its movement to avoid danger.

**_Using a Higher-Level Spell Slot._** Use the spell slot’s level for the spell’s level in the stat block.

#Spell
