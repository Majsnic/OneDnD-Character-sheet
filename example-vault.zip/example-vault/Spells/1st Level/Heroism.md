---
Spell level: 1
School type: Enchantment
Casting Time: Action
Components:
  - Verbal
  - Somatic
Concentration: true
Duration: 1 minute
Range / Area: Touch
Attack / Save: None
Damage / Effect: Temporary Hit Points
Upscale: + 1 creature
category: 1st level
---
_Level 1 Enchantment_

- **Casting time:** Action
- **Range:** Touch
- **Components:** V, S
- **Duration:** 1 minute
- **Attack/Save**: None
- **Damage/Effect**: Temporary Hit Points

A willing creature you touch is imbued with bravery. Until the spell ends, the creature is immune to the Frightened condition and gains Temporary Hit Points equal to your spellcasting ability modifier at the start of each of its turns.

**_Using a Higher-Level Spell Slot._** You can target one additional creature for each spell slot level above 1.

#Spell
