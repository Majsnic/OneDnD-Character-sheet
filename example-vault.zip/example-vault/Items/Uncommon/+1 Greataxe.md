---
Rarity: Uncommon
type: object
tags:
  - Item
  - item/uncommon
  - item/weapon
item_category: Weapon
item_base: "Greataxe"
weapon_category: "Martial Melee"
damage_dice: "1d12"
damage_type: Slashing
weapon_properties: [Heavy, Two-Handed]
weapon_mastery: Cleave
requires_attunement: false
attunement_note: ""
attack_bonus: 1
damage_bonus: 1
---


###### +1 Greataxe
_Weapon (greataxe), uncommon_<span class="sub2">:FasWandMagicSparkles: Magic Item</span>
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>You have a +1 bonus to attack and damage rolls made with this magic weapon.
>
>**1d12+1 Slashing damage.** Properties: Heavy, Two-Handed.
>
>- **Heavy.** Small creatures have Disadvantage on attack rolls with this weapon.
>- **Two-Handed.** You must use two hands to attack with this weapon.
>
>**_Cleave (Mastery)._** If you hit a creature with a melee attack roll using this weapon and deal damage to it, you can make an attack roll with the same weapon against a second creature within 5 feet of the first creature that is also within the weapon's reach. On a hit, the second creature takes the weapon's damage, but don't add your ability modifier to that damage unless it's negative. You can use this property only once per turn.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
