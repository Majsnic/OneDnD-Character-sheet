---
Rarity: Very Rare
type: object
tags:
  - Item
  - item/very-rare
  - item/weapon
item_category: Weapon
item_base: "War Pick"
weapon_category: "Martial Melee"
damage_dice: "1d8"
damage_type: Piercing
weapon_properties: []
weapon_mastery: Sap
requires_attunement: false
attunement_note: ""
attack_bonus: 3
damage_bonus: 3
---


###### +3 War Pick
_Weapon (war pick), very rare_<span class="sub2">:FasWandMagicSparkles: Magic Item</span>
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>You have a +3 bonus to attack and damage rolls made with this magic weapon.
>
>**1d8+3 Piercing damage.**
>
>**_Sap (Mastery)._** If you hit a creature with this weapon and deal damage to it, that creature has Disadvantage on its next attack roll before the start of your next turn.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
