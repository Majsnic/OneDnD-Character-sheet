---
Type: Beast
CR: 1/4
Size: Medium
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Swarm of Rats
size: Medium
type: Swarm of Tiny Beasts
alignment: Unaligned
ac: 10
hp: 14 (4d8 - 4)
hit_dice: 4d8 - 4
speed: 30 ft., Climb 30 ft.
stats: [9, 11, 9, 2, 10, 3]
saves:
  - Dex: +2
damage_resistances: Bludgeoning, Piercing, Slashing
condition_immunities: Charmed, Frightened, Grappled, Paralyzed, Petrified, Prone, Restrained, Stunned
senses: Darkvision 30 ft.; Passive Perception 10
languages: None
cr: 1/4
traits:
  - name: "Swarm"
    desc: "The swarm can occupy another creature’s space and vice versa, and the swarm can move through any opening large enough for a Tiny rat. The swarm can’t regain Hit Points or gain Temporary Hit Points."
actions:
  - name: "Bites"
    desc: "Melee Attack Roll: +2, reach 5 ft. Hit: 5 (2d4) Piercing damage, or 2 (1d4) Piercing damage if the swarm is Bloodied."
```

#Monster
