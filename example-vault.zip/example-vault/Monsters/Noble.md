---
Type: Humanoid
CR: 1/8
Size: Medium or Small
tags:
  - Monster
  - Humanoid
source: SRD 5.2.1
---

```statblock
name: Noble
size: Medium or Small
type: Humanoid
alignment: Neutral
ac: 15
hp: 9 (2d8)
hit_dice: 2d8
speed: 30 ft.
stats: [11, 12, 11, 12, 14, 16]
skillsaves:
  - Deception: +5
  - Insight: +4
  - Persuasion: +5
gear: Breastplate, Rapier
senses: Passive Perception 12
languages: Common plus two other languages
cr: 1/8
actions:
  - name: "Rapier"
    desc: "Melee Attack Roll: +3, reach 5 ft. Hit: 5 (1d8 + 1) Piercing damage."
reactions:
  - name: "Parry"
    desc: "Trigger: The noble is hit by a melee attack roll while holding a weapon. Response: The noble adds 2 to its AC against that attack, possibly causing it to miss."
```

#Monster
