---
type: object
tags:
  - Item
  - item/common
  - item/weapon
item_category: Weapon
weapon_category: "Simple Melee"
damage_dice: "1d6"
damage_type: Bludgeoning
weapon_properties: []
attack_bonus: 0
damage_bonus: 0
cost: "5 GP"
weight_lb: 4
---


###### Mace
_Simple Melee Weapon_
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>**1d6 Bludgeoning damage.** Cost 5 GP, weight 4 lb.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
