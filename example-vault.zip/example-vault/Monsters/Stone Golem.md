---
Type: Construct
CR: 10
Size: Large
tags:
  - Monster
  - Construct
source: SRD 5.2.1
---

```statblock
name: Stone Golem
size: Large
type: Construct
alignment: Unaligned
ac: 18
hp: 220 (21d10 + 105)
hit_dice: 21d10 + 105
speed: 30 ft.
stats: [22, 9, 20, 3, 11, 1]
damage_immunities: Poison, Psychic
condition_immunities: Charmed, Exhaustion, Frightened, Paralyzed, Petrified, Poisoned
senses: Darkvision 120 ft.; Passive Perception 10
languages: Understands Common plus two other languages but can’t speak
cr: 10
traits:
  - name: "Immutable Form"
    desc: "The golem can’t shape-shift."
  - name: "Magic Resistance"
    desc: "The golem has Advantage on saving throws against spells and other magical effects."
actions:
  - name: "Multiattack"
    desc: "The golem makes two attacks, using Slam or Force Bolt in any combination."
  - name: "Slam"
    desc: "Melee Attack Roll: +10, reach 5 ft. Hit: 15 (2d8 + 6) Bludgeoning damage plus 9 (2d8) Force damage."
  - name: "Force Bolt"
    desc: "Ranged Attack Roll: +9, range 120 ft. Hit: 22 (4d10) Force damage."
bonusactions:
  - name: "Slow (Recharge 5–6)"
    desc: "The golem casts the Slow spell, requiring no spell components and using Constitution as the spellcasting ability (spell save DC 17)."
```

#Monster
