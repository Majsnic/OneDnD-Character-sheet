---
Type: Humanoid
CR: 1/2
Size: Medium or Small
tags:
  - Monster
  - Humanoid
source: SRD 5.2.1
---

```statblock
name: Scout
size: Medium or Small
type: Humanoid
alignment: Neutral
ac: 13
hp: 16 (3d8 + 3)
hit_dice: 3d8 + 3
speed: 30 ft.
stats: [11, 14, 12, 11, 13, 11]
skillsaves:
  - Nature: +4
  - Perception: +5
  - Stealth: +6
  - Survival: +5
gear: Leather Armor, Longbow, Shortsword
senses: Passive Perception 15
languages: Common plus one other language
cr: 1/2
actions:
  - name: "Multiattack"
    desc: "The scout makes two attacks, using Shortsword and Longbow in any combination."
  - name: "Shortsword"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 5 (1d6 + 2) Piercing damage."
  - name: "Longbow"
    desc: "Ranged Attack Roll: +4, range 150/600 ft. Hit: 6 (1d8 + 2) Piercing damage."
```

#Monster
