---
Type: Beast
CR: 1/8
Size: Medium
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Giant Weasel
size: Medium
type: Beast
alignment: Unaligned
ac: 13
hp: 9 (2d8)
hit_dice: 2d8
speed: 40 ft., Climb 30 ft.
stats: [11, 17, 10, 4, 12, 5]
skillsaves:
  - Acrobatics: +5
  - Perception: +3
  - Stealth: +5
senses: Darkvision 60 ft.; Passive Perception 13
languages: None
cr: 1/8
actions:
  - name: "Bite"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 5 (1d4 + 3) Piercing damage."
```

#Monster
