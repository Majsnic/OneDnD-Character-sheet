---
Type: Beast
CR: 0
Size: Tiny
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Lizard
size: Tiny
type: Beast
alignment: Unaligned
ac: 10
hp: 2 (1d4)
hit_dice: 1d4
speed: 20 ft., Climb 20 ft.
stats: [2, 11, 10, 1, 8, 3]
senses: Darkvision 30 ft.; Passive Perception 9
languages: None
cr: 0
traits:
  - name: "Spider Climb"
    desc: "The lizard can climb difficult surfaces, including along ceilings, without needing to make an ability check."
actions:
  - name: "Bite"
    desc: "Melee Attack Roll: +2, reach 5 ft. Hit: 1 Piercing damage."
```

#Monster
