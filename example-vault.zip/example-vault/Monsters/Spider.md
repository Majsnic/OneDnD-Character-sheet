---
Type: Beast
CR: 0
Size: Tiny
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Spider
size: Tiny
type: Beast
alignment: Unaligned
ac: 12
hp: 1 (1d4 - 1)
hit_dice: 1d4 - 1
speed: 20 ft., Climb 20 ft.
stats: [2, 14, 8, 1, 10, 2]
skillsaves:
  - Stealth: +4
senses: Darkvision 30 ft.; Passive Perception 10
languages: None
cr: 0
traits:
  - name: "Spider Climb"
    desc: "The spider can climb difficult surfaces, including along ceilings, without needing to make an ability check."
  - name: "Web Walker"
    desc: "The spider ignores movement restrictions caused by webs, and the spider knows the location of any other creature in contact with the same web."
actions:
  - name: "Bite"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 1 Piercing damage plus 2 (1d4) Poison damage."
```

#Monster
