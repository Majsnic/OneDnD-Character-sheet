---
Type: Fiend
CR: 3
Size: Large
tags:
  - Monster
  - Fiend
source: SRD 5.2.1
---

```statblock
name: Nightmare
size: Large
type: Fiend
alignment: Neutral Evil
ac: 13
hp: 68 (8d10 + 24)
hit_dice: 8d10 + 24
speed: 60 ft., Fly 90 ft. (hover)
stats: [18, 15, 16, 10, 13, 15]
damage_immunities: Fire
senses: Passive Perception 11
languages: Understands Abyssal, Common, and Infernal but can’t speak
cr: 3
traits:
  - name: "Confer Fire Resistance"
    desc: "The nightmare can grant Resistance to Fire damage to a rider while it is on the nightmare."
  - name: "Illumination"
    desc: "The nightmare sheds Bright Light in a 10- foot radius and Dim Light for an additional 10 feet."
actions:
  - name: "Hooves"
    desc: "Melee Attack Roll: +6, reach 5 ft. Hit: 13 (2d8 + 4) Bludgeoning damage plus 10 (3d6) Fire damage."
  - name: "Ethereal Stride"
    desc: "The nightmare and up to three willing creatures within 5 feet of it teleport to the Ethereal Plane from the Material Plane or vice versa."
```

#Monster
