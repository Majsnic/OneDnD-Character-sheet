---
Spell level: 1
School type: Abjuration
Casting Time: Bonus Action
Components:
  - Verbal
  - Somatic
  - Material
Concentration: true
Duration: 10 minutes
Range / Area: 60 feet
Attack / Save: None
Damage / Effect: Warding
Upscale: 
category: 1st level
---
_Level 1 Abjuration_

- **Casting time:** Bonus Action
- **Range:** 60 feet
- **Components:** V, S, M
- **Duration:** 10 minutes
- **Attack/Save**: None
- **Damage/Effect**: Warding

A shimmering field surrounds a creature of your choice within range, granting it a +2 bonus to AC for the duration.

#Spell
