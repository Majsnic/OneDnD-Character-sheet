---
Rarity: Uncommon
type: object
tags:
  - Item
  - item/uncommon
  - item/weapon
item_category: Weapon
item_base: "Greatclub"
weapon_category: "Simple Melee"
damage_dice: "1d8"
damage_type: Bludgeoning
weapon_properties: [Two-Handed]
weapon_mastery: Push
requires_attunement: false
attunement_note: ""
attack_bonus: 1
damage_bonus: 1
---


###### +1 Greatclub
_Weapon (greatclub), uncommon_<span class="sub2">:FasWandMagicSparkles: Magic Item</span>
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>You have a +1 bonus to attack and damage rolls made with this magic weapon.
>
>**1d8+1 Bludgeoning damage.** Properties: Two-Handed.
>
>- **Two-Handed.** You must use two hands to attack with this weapon.
>
>**_Push (Mastery)._** If you hit a creature with this weapon and deal damage to it, you can push the creature up to 10 feet straight away from yourself if it is Large or smaller.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
