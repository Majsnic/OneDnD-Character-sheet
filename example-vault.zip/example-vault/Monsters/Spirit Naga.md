---
Type: Fiend
CR: 8
Size: Large
tags:
  - Monster
  - Fiend
source: SRD 5.2.1
---

```statblock
name: Spirit Naga
size: Large
type: Fiend
alignment: Chaotic Evil
ac: 17
hp: 135 (18d10 + 36)
hit_dice: 18d10 + 36
speed: 40 ft.
stats: [18, 17, 14, 16, 15, 16]
saves:
  - Dex: +6
  - Con: +5
  - Wis: +5
  - Cha: +6
damage_immunities: Poison
condition_immunities: Charmed, Poisoned
senses: Darkvision 60 ft.; Passive Perception 12
languages: Abyssal, Common
cr: 8
traits:
  - name: "Fiendish Restoration"
    desc: "If it dies, the naga returns to life in 1d6 days and regains all its Hit Points. Only a Wish spell can prevent this trait from functioning."
actions:
  - name: "Multiattack"
    desc: "The naga makes three attacks, using Bite or Necrotic Ray in any combination."
  - name: "Bite"
    desc: "Melee Attack Roll: +7, reach 10 ft. Hit: 7 (1d6 + 4) Piercing damage plus 14 (4d6) Poison damage."
  - name: "Necrotic Ray"
    desc: "Ranged Attack Roll: +6, range 60 ft. Hit: 21 (6d6) Necrotic damage."
  - name: "Spellcasting"
    desc: "The naga casts one of the following spells, requiring no Somatic or Material components and using Intelligence as the spellcasting ability (spell save DC 14): At Will: Detect Magic, Mage Hand, Minor Illusion, Water Breathing 2/Day Each: Detect Thoughts, Dimension Door, Hold Person (level 3 version), Lightning Bolt (level 4 version)"
```

#Monster
