---
Type: Elemental
CR: 1/2
Size: Small
tags:
  - Monster
  - Elemental
source: SRD 5.2.1
---

```statblock
name: Magma Mephit
size: Small
type: Elemental
alignment: Neutral Evil
ac: 11
hp: 18 (4d6 + 4)
hit_dice: 4d6 + 4
speed: 30 ft., Fly 30 ft.
stats: [8, 12, 12, 7, 10, 10]
skillsaves:
  - Stealth: +3
damage_vulnerabilities: Cold
damage_immunities: Fire, Poison
condition_immunities: Exhaustion, Poisoned
senses: Darkvision 60 ft.; Passive Perception 10
languages: Primordial (Ignan, Terran)
cr: 1/2
traits:
  - name: "Death Burst"
    desc: "The mephit explodes when it dies. Dexterity Saving Throw: DC 11, each creature in a 5-foot Emanation originating from the mephit. Failure: 7 (2d6) Fire damage. Success: Half damage."
actions:
  - name: "Claw"
    desc: "Melee Attack Roll: +3, reach 5 ft. Hit: 3 (1d4 + 1) Slashing damage plus 3 (1d6) Fire damage."
  - name: "Fire Breath (Recharge 6)"
    desc: "Dexterity Saving Throw: DC 11, each creature in a 15-foot Cone. Failure: 7 (2d6) Fire damage. Success: Half damage."
```

#Monster
