---
Type: Monstrosity
CR: 1/8
Size: Tiny
tags:
  - Monster
  - Monstrosity
source: SRD 5.2.1
---

```statblock
name: Stirge
size: Tiny
type: Monstrosity
alignment: Unaligned
ac: 13
hp: 5 (2d4)
hit_dice: 2d4
speed: 10 ft., Fly 40 ft.
stats: [4, 16, 11, 2, 8, 6]
senses: Darkvision 60 ft.; Passive Perception 9
languages: None
cr: 1/8
actions:
  - name: "Proboscis"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 6 (1d6 + 3) Piercing damage, and the stirge attaches to the target. While attached, the stirge can’t make Proboscis attacks, and the target takes 5 (2d4) Necrotic damage at the start of each of the stirge’s turns. The stirge can detach itself by spending 5 feet of its movement. The target or a creature within 5 feet of it can detach the stirge as an action."
```

#Monster
