---
Spell level: 6
School type: Enchantment
Casting Time: Action
Components:
  - Verbal
  - Material
Concentration: false
Duration: 24 hours
Range / Area: 60 feet
Attack / Save: WIS Save
Damage / Effect: Charmed
Upscale: 
category: 6th level
---
_Level 6 Enchantment_

- **Casting time:** Action
- **Range:** 60 feet
- **Components:** V, M
- **Duration:** 24 hours
- **Attack/Save**: WIS Save
- **Damage/Effect**: Charmed

You suggest a course of activity—described in no more than 25 words—to twelve or fewer creatures you can see within range that can hear and understand you. The suggestion must sound achievable and not involve anything that would obviously deal damage to any of the targets or their allies. For example, you could say, “Walk to the village down that road, and help the villagers there harvest crops until sunset.” Or you could say, “Now is not the time for violence. Drop your weapons, and dance! Stop in an hour.” Each target must succeed on a Wisdom saving throw or have the Charmed condition for the duration or until you or your allies deal damage to the target. Each Charmed target pursues the suggestion to the best of its ability. The suggested activity can continue for the entire duration, but if the suggested activity can be completed in a shorter time, the spell ends for a target upon completing it.

**_Using a Higher-Level Spell Slot._** The duration is longer with a spell slot of level 7 (10 days), 8 (30 days), or 9 (366 days).

#Spell
