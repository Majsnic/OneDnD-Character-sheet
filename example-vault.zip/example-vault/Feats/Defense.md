---
tags:
  - Feat
source: SRD 5.2.1
---

# Defense

**Type:** Fighting Style Feat
**Prerequisite:** A class feature that lets you choose a Fighting Style
**Repeatable:** No

While you are wearing armor, you gain a +1 bonus to Armor Class.

*Paraphrased mechanical summary, written from general knowledge of the SRD rules — treat it as a helpful draft, not a verbatim rules quote.*

#Feat
