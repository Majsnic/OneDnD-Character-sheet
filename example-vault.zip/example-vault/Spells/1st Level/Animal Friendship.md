---
Spell level: 1
School type: Enchantment
Casting Time: Action
Components:
  - Verbal
  - Somatic
  - Material
Concentration: false
Duration: 24 hours
Range / Area: 30 feet
Attack / Save: WIS Save
Damage / Effect: Charmed
Upscale: + 1 Beast
category: 1st level
---
_Level 1 Enchantment_

- **Casting time:** Action
- **Range:** 30 feet
- **Components:** V, S, M
- **Duration:** 24 hours
- **Attack/Save**: WIS Save
- **Damage/Effect**: Charmed

Target a Beast that you can see within range. The target must succeed on a Wisdom saving throw or have the Charmed condition for the duration. If you or one of your allies deals damage to the target, the spells ends.

**_Using a Higher-Level Spell Slot._** You can target one additional Beast for each spell slot level above 1.

#Spell
