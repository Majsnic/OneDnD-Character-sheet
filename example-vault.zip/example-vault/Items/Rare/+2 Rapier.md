---
Rarity: Rare
type: object
tags:
  - Item
  - item/rare
  - item/weapon
item_category: Weapon
item_base: "Rapier"
weapon_category: "Martial Melee"
damage_dice: "1d8"
damage_type: Piercing
weapon_properties: [Finesse]
weapon_mastery: Vex
requires_attunement: false
attunement_note: ""
attack_bonus: 2
damage_bonus: 2
---


###### +2 Rapier
_Weapon (rapier), rare_<span class="sub2">:FasWandMagicSparkles: Magic Item</span>
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>You have a +2 bonus to attack and damage rolls made with this magic weapon.
>
>**1d8+2 Piercing damage.** Properties: Finesse.
>
>- **Finesse.** You can use your Strength or Dexterity modifier for attack and damage rolls with this weapon.
>
>**_Vex (Mastery)._** If you hit a creature with this weapon and deal damage to it, you can give yourself Advantage on your next attack roll against that creature before the end of your next turn.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
