---
Spell level: 1
School type: Abjuration
Casting Time: Reaction*
Components:
  - Verbal
  - Somatic
Concentration: false
Duration: 1 round
Range / Area: Self
Attack / Save: None
Damage / Effect: Warding
Upscale: 
category: 1st level
---
_Level 1 Abjuration_

- **Casting time:** Reaction*
- **Range:** Self
- **Components:** V, S
- **Duration:** 1 round
- **Attack/Save**: None
- **Damage/Effect**: Warding

_* - which you take when you are hit by an attack roll or targeted by the Magic Missile spell_

An imperceptible barrier of magical force protects you. Until the start of your next turn, you have a +5 bonus to AC, including against the triggering attack, and you take no damage from Magic Missile.

#Spell
