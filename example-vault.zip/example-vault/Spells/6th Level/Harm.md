---
Spell level: 6
School type: Necromancy
Casting Time: Action
Components:
  - Verbal
  - Somatic
Concentration: false
Duration: Instantaneous
Range / Area: 60 feet
Attack / Save: CON Save
Damage / Effect: 14d6 Necrotic
Upscale: 
category: 6th level
---
_Level 6 Necromancy_

- **Casting time:** Action
- **Range:** 60 feet
- **Components:** V, S
- **Duration:** Instantaneous
- **Attack/Save**: CON Save
- **Damage/Effect**: Necrotic

You unleash virulent magic on a creature you can see within range. The target makes a Constitution saving throw. On a failed save, it takes 14d6 Necrotic damage, and its Hit Point maximum is reduced by an amount equal to the Necrotic damage it took. On a successful save, it takes half as much damage only. This spell can’t reduce a target’s Hit Point maximum below 1.

#Spell
