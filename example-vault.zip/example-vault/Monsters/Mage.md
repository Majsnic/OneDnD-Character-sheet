---
Type: Humanoid
CR: 6
Size: Medium or Small
tags:
  - Monster
  - Humanoid
source: SRD 5.2.1
---

```statblock
name: Mage
size: Medium or Small
type: Humanoid (Wizard)
alignment: Neutral
ac: 15
hp: 81 (18d8)
hit_dice: 18d8
speed: 30 ft.
stats: [9, 14, 11, 17, 12, 11]
saves:
  - Int: +6
  - Wis: +4
skillsaves:
  - Arcana: +6
  - History: +6
  - Perception: +4
gear: Wand
senses: Passive Perception 14
languages: Common plus three other languages
cr: 6
actions:
  - name: "Multiattack"
    desc: "The mage makes three Arcane Burst attacks."
  - name: "Arcane Burst"
    desc: "Melee or Ranged Attack Roll: +6, reach 5 ft. or range 120 ft. Hit: 16 (3d8 + 3) Force damage."
  - name: "Spellcasting"
    desc: "The mage casts one of the following spells, using Intelligence as the spellcasting ability (spell save DC 14): At Will: Detect Magic, Light, Mage Armor (included in AC), Mage Hand, Prestidigitation 2/Day Each: Fireball (level 4 version), Invisibility 1/Day Each: Cone of Cold, Fly"
bonusactions:
  - name: "Misty Step (3/Day)"
    desc: "The mage casts Misty Step, using the same spellcasting ability as Spellcasting."
reactions:
  - name: "Protective Magic (3/Day)"
    desc: "The mage casts Counterspell or Shield in response to the spell’s trigger, using the same spellcasting ability as Spellcasting."
```

#Monster
