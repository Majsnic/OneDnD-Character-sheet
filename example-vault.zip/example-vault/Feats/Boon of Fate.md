---
tags:
  - Feat
source: SRD 5.2.1
---

# Boon of Fate

**Type:** Epic Boon Feat
**Prerequisite:** Character level 19
**Repeatable:** No

When a creature you can see within 60 feet of you succeeds or fails on an attack roll, ability check, or saving throw, you can use your reaction to roll a d4 and apply the result to that roll, possibly changing the outcome. You have a number of uses equal to your proficiency bonus, all of which you regain after a long rest.

*Paraphrased mechanical summary, written from general knowledge of the SRD rules — treat it as a helpful draft, not a verbatim rules quote.*

#Feat
