---
Spell level: 1
School type: Illusion
Casting Time: 1 minute or Ritual
Components:
  - Somatic
  - Material
Concentration: false
Duration: 10 days
Range / Area: Touch
Attack / Save: None
Damage / Effect: Utility
Upscale: 
category: 1st level
---
_Level 1 Illusion_

- **Casting time:** 1 minute or Ritual
- **Range:** Touch
- **Components:** S, M
- **Duration:** 10 days
- **Attack/Save**: None
- **Damage/Effect**: Utility

You write on parchment, paper, or another suitable material and imbue it with an illusion that lasts for the duration. To you and any creatures you designate when you cast the spell, the writing appears normal, seems to be written in your hand, and conveys whatever meaning you intended when you wrote the text. To all others, the writing appears as if it were written in an unknown or magical script that is unintelligible. Alternatively, the illusion can alter the meaning, handwriting, and language of the text, though the language must be one you know. If the spell is dispelled, the original script and the illusion both disappear. A creature that has Truesight can read the hidden message.

#Spell
