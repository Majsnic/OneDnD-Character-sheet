---
Type: Fey
CR: 1/4
Size: Medium
tags:
  - Monster
  - Fey
source: SRD 5.2.1
---

```statblock
name: Blink Dog
size: Medium
type: Fey
alignment: Lawful Good
ac: 13
hp: 22 (4d8 + 4)
hit_dice: 4d8 + 4
speed: 40 ft.
stats: [12, 17, 12, 10, 13, 11]
skillsaves:
  - Perception: +5
  - Stealth: +5
senses: Darkvision 60 ft.; Passive Perception 15
languages: Blink Dog; understands Elvish and Sylvan but can’t speak them
cr: 1/4
actions:
  - name: "Bite"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 5 (1d4 + 3) Piercing damage."
bonusactions:
  - name: "Teleport (Recharge 4–6)"
    desc: "The dog teleports up to 40 feet to an unoccupied space it can see."
```

#Monster
