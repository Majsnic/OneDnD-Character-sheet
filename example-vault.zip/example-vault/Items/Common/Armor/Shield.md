---
type: object
tags:
  - Item
  - item/common
  - item/shield
item_category: Shield
armor_category: Shield
armor_class_bonus: 2
stealth_disadvantage: false
cost: "10 GP"
weight_lb: 6
---


###### Shield
_Shield_
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>**+2 AC** while wielded. Cost 10 GP, weight 6 lb.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
