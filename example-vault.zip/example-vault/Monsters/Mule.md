---
Type: Beast
CR: 1/8
Size: Medium
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Mule
size: Medium
type: Beast
alignment: Unaligned
ac: 10
hp: 11 (2d8 + 2)
hit_dice: 2d8 + 2
speed: 40 ft.
stats: [14, 10, 13, 2, 10, 5]
saves:
  - Str: +4
senses: Passive Perception 10
languages: None
cr: 1/8
traits:
  - name: "Beast of Burden"
    desc: "The mule counts as one size larger for the purpose of determining its carrying capacity."
actions:
  - name: "Hooves"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 4 (1d4 + 2) Bludgeoning damage."
```

#Monster
