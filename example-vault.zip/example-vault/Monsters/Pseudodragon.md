---
Type: Dragon
CR: 1/4
Size: Tiny
tags:
  - Monster
  - Dragon
source: SRD 5.2.1
---

```statblock
name: Pseudodragon
size: Tiny
type: Dragon
alignment: Neutral Good
ac: 14
hp: 10 (3d4 + 3)
hit_dice: 3d4 + 3
speed: 15 ft., Fly 60 ft.
stats: [6, 15, 13, 10, 12, 10]
skillsaves:
  - Perception: +5
  - Stealth: +4
senses: Blindsight 10 ft., Darkvision 60 ft.; Passive Perception 15
languages: Understands Common and Draconic but can’t speak
cr: 1/4
traits:
  - name: "Magic Resistance"
    desc: "The pseudodragon has Advantage on saving throws against spells and other magical effects."
actions:
  - name: "Multiattack"
    desc: "The pseudodragon makes two Bite attacks."
  - name: "Bite"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 4 (1d4 + 2) Piercing damage."
  - name: "Sting"
    desc: "Constitution Saving Throw: DC 12, one creature the pseudodragon can see within 5 feet. Failure: 5 (2d4) Poison damage, and the target has the Poisoned condition for 1 hour. Failure by 5 or More: While Poisoned, the target also has the Unconscious condition, which ends early if the target takes damage or a creature within 5 feet of it takes an action to wake it."
```

#Monster
