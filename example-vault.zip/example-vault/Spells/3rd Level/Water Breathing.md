---
Spell level: 3
School type: Transmutation
Casting Time: Action or Ritual
Components:
  - Verbal
  - Somatic
  - Material
Concentration: false
Duration: 24 hours
Range / Area: 30 feet
Attack / Save: None
Damage / Effect: Utility
Upscale: 
category: 3rd level
---
_Level 3 Transmutation_

- **Casting time:** Action or Ritual
- **Range:** 30 feet
- **Components:** V, S, M
- **Duration:** 24 hours
- **Attack/Save**: None
- **Damage/Effect**: Utility

This spell grants up to ten willing creatures of your choice within range the ability to breathe underwater until the spell ends. Affected creatures also retain their normal mode of respiration.

#Spell
