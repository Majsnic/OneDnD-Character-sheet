---
Type: Fiend
CR: 1/2
Size: Medium
tags:
  - Monster
  - Fiend
source: SRD 5.2.1
---

```statblock
name: Gnoll Warrior
size: Medium
type: Fiend
alignment: Chaotic Evil
ac: 15
hp: 27 (6d8)
hit_dice: 6d8
speed: 30 ft.
stats: [14, 12, 11, 6, 10, 7]
senses: Darkvision 60 ft.; Passive Perception 10
languages: Gnoll
cr: 1/2
actions:
  - name: "Rend"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 5 (1d6 + 2) Piercing damage."
  - name: "Bone Bow"
    desc: "Ranged Attack Roll: +3, range 150/600 ft. Hit: 6 (1d10 + 1) Piercing damage."
bonusactions:
  - name: "Rampage (1/Day)"
    desc: "Immediately after dealing damage to a creature that is already Bloodied, the gnoll moves up to half its Speed, and it makes one Rend attack."
```

#Monster
