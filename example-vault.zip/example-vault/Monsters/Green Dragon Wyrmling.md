---
Type: Dragon
CR: 2
Size: Medium
tags:
  - Monster
  - Dragon
source: SRD 5.2.1
---

```statblock
name: Green Dragon Wyrmling
size: Medium
type: Dragon (Chromatic)
alignment: Lawful Evil
ac: 17
hp: 38 (7d8 + 7)
hit_dice: 7d8 + 7
speed: 30 ft., Fly 60 ft., Swim 30 ft.
stats: [15, 12, 13, 14, 11, 13]
saves:
  - Dex: +3
  - Wis: +2
skillsaves:
  - Perception: +4
  - Stealth: +3
damage_immunities: Poison
condition_immunities: Poisoned
senses: Blindsight 10 ft., Darkvision 60 ft.; Passive Perception 14
languages: Draconic
cr: 2
traits:
  - name: "Amphibious"
    desc: "The dragon can breathe air and water."
actions:
  - name: "Multiattack"
    desc: "The dragon makes two Rend attacks."
  - name: "Rend"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 7 (1d10 + 2) Slashing damage plus 3 (1d6) Poison damage."
  - name: "Poison Breath (Recharge 5–6)"
    desc: "Constitution Saving Throw: DC 11, each creature in a 15-foot Cone. Failure: 21 (6d6) Poison damage. Success: Half damage."
```

#Monster
