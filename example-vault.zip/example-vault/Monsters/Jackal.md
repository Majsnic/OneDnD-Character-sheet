---
Type: Beast
CR: 0
Size: Small
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Jackal
size: Small
type: Beast
alignment: Unaligned
ac: 12
hp: 3 (1d6)
hit_dice: 1d6
speed: 40 ft.
stats: [8, 15, 11, 3, 12, 6]
skillsaves:
  - Perception: +5
  - Stealth: +4
senses: Darkvision 90 ft.; Passive Perception 15
languages: None
cr: 0
actions:
  - name: "Bite"
    desc: "Melee Attack Roll: +1, reach 5 ft. Hit: 1 (1d4 – 1) Piercing damage."
```

#Monster
