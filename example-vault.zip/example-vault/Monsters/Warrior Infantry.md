---
Type: Humanoid
CR: 1/8
Size: Medium or Small
tags:
  - Monster
  - Humanoid
source: SRD 5.2.1
---

```statblock
name: Warrior Infantry
size: Medium or Small
type: Humanoid
alignment: Neutral
ac: 13
hp: 9 (2d8)
hit_dice: 2d8
speed: 30 ft.
stats: [13, 11, 11, 8, 11, 8]
gear: Chain Shirt, Spear
senses: Passive Perception 10
languages: Common
cr: 1/8
traits:
  - name: "Pack Tactics"
    desc: "The warrior has Advantage on an attack roll against a creature if at least one of the warrior’s allies is within 5 feet of the creature and the ally doesn’t have the Incapacitated condition."
actions:
  - name: "Spear"
    desc: "Melee or Ranged Attack Roll: +3, reach 5 ft. or range 20/60 ft. Hit: 4 (1d6 + 1) Piercing damage."
```

#Monster
