---
Type: Monstrosity
CR: 11
Size: Gargantuan
tags:
  - Monster
  - Monstrosity
source: SRD 5.2.1
---

```statblock
name: Roc
size: Gargantuan
type: Monstrosity
alignment: Unaligned
ac: 15
hp: 248 (16d20 + 80)
hit_dice: 16d20 + 80
speed: 20 ft., Fly 120 ft.
stats: [28, 10, 20, 3, 10, 9]
saves:
  - Dex: +4
  - Wis: +4
skillsaves:
  - Perception: +8
senses: Passive Perception 18
languages: None
cr: 11
actions:
  - name: "Multiattack"
    desc: "The roc makes two Beak attacks. It can replace one attack with a Talons attack."
  - name: "Beak"
    desc: "Melee Attack Roll: +13, reach 10 ft. Hit: 28 (3d12 + 9) Piercing damage."
  - name: "Talons"
    desc: "Melee Attack Roll: +13, reach 5 ft. Hit: 23 (4d6 + 9) Slashing damage. If the target is a Huge or smaller creature, it has the Grappled condition (escape DC 19) from both talons, and it has the Restrained condition until the grapple ends."
bonusactions:
  - name: "Swoop (Recharge 5–6)"
    desc: "If the roc has a creature Grappled, the roc flies up to half its Fly Speed without provoking Opportunity Attacks and drops that creature."
```

#Monster
