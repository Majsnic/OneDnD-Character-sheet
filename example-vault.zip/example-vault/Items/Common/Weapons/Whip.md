---
type: object
tags:
  - Item
  - item/common
  - item/weapon
item_category: Weapon
weapon_category: "Martial Melee"
damage_dice: "1d4"
damage_type: Slashing
weapon_properties: [Finesse, Reach]
weapon_mastery: Slow
attack_bonus: 0
damage_bonus: 0
cost: "2 GP"
weight_lb: 3
---


###### Whip
_Martial Melee Weapon_
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>**1d4 Slashing damage.** Properties: Finesse, Reach. Cost 2 GP, weight 3 lb.
>
>- **Finesse.** You can use your Strength or Dexterity modifier for attack and damage rolls with this weapon.
>- **Reach.** This weapon adds 5 feet to your reach when you attack with it.
>
>**_Slow (Mastery)._** If you hit a creature with this weapon, you can reduce that creature's Speed by 10 feet until the start of your next turn. This isn't cumulative with itself.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
