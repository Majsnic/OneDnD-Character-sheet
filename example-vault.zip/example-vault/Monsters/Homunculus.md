---
Type: Construct
CR: 0
Size: Tiny
tags:
  - Monster
  - Construct
source: SRD 5.2.1
---

```statblock
name: Homunculus
size: Tiny
type: Construct
alignment: Neutral
ac: 13
hp: 4 (1d4 + 2)
hit_dice: 1d4 + 2
speed: 20 ft., Fly 40 ft.
stats: [4, 15, 14, 10, 10, 7]
saves:
  - Wis: +2
  - Cha: +0
damage_immunities: Poison
condition_immunities: Charmed, Poisoned
senses: Darkvision 60 ft.; Passive Perception 10
languages: Understands Common plus one other language but can’t speak
cr: 0
traits:
  - name: "Telepathic Bond"
    desc: "While the homunculus is on the same plane of existence as its master, the two of them can communicate telepathically with each other."
actions:
  - name: "Bite"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 1 Piercing damage, and the target is subjected to the following effect. Constitution Saving Throw: DC 12. Failure: The target has the Poisoned condition until the end of the homunculus’s next turn. Failure by 5 or More: The target has the Poisoned condition for 1 minute. While Poisoned, the target has the Unconscious condition, which ends early if the target takes any damage."
```

#Monster
