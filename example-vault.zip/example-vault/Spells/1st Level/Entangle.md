---
Spell level: 1
School type: Conjuration
Casting Time: Action
Components:
  - Verbal
  - Somatic
Concentration: true
Duration: 1 minute
Range / Area: 90 feet
Attack / Save: STR Save
Damage / Effect: Restrained
Upscale: 
category: 1st level
---
_Level 1 Conjuration_

- **Casting time:** Action
- **Range:** 90 feet
- **Components:** V, S
- **Duration:** 1 minute
- **Attack/Save**: STR Save
- **Damage/Effect**: Restrained

Grasping plants sprout from the ground in a 20-foot square within range. For the duration, these plants turn the ground in the area into Difficult Terrain. They disappear when the spell ends. Each creature (other than you) in the area when you cast the spell must succeed on a Strength saving throw or have the Restrained condition until the spell ends. A Restrained creature can take an action to make a Strength (Athletics) check against your spell save DC. On a success, it frees itself from the grasping plants and is no longer Restrained by them.

#Spell
