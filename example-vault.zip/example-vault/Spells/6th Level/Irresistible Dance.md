---
Spell level: 6
School type: Enchantment
Casting Time: Action
Components:
  - Verbal
Concentration: true
Duration: 1 minute
Range / Area: 30 feet
Attack / Save: WIS Save
Damage / Effect: Charmed
Upscale: 
category: 6th level
---
_Level 6 Enchantment_

- **Casting time:** Action
- **Range:** 30 feet
- **Components:** V
- **Duration:** 1 minute
- **Attack/Save**: WIS Save
- **Damage/Effect**: Charmed

One creature that you can see within range must make a Wisdom saving throw. On a successful save, the target dances comically until the end of its next turn, during which it must spend all its movement to dance in place. On a failed save, the target has the Charmed condition for the duration. While Charmed, the target dances comically, must use all its movement to dance in place, and has Disadvantage on Dexterity saving throws and attack rolls, and other creatures have Advantage on attack rolls against it. On each of its turns, the target can take an action to collect itself and repeat the save, ending the spell on itself on a success.

#Spell
