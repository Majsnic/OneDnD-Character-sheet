---
Type: Beast
CR: 1/8
Size: Tiny
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Venomous Snake
size: Tiny
type: Beast
alignment: Unaligned
ac: 12
hp: 5 (2d4)
hit_dice: 2d4
speed: 30 ft., Swim 30 ft.
stats: [2, 15, 11, 1, 10, 3]
senses: Blindsight 10 ft.; Passive Perception 10
languages: None
cr: 1/8
actions:
  - name: "Bite"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 4 (1d4 + 2) Piercing damage plus 3 (1d6) Poison damage."
```

#Monster
