---
Type: Celestial
CR: 10
Size: Large
tags:
  - Monster
  - Celestial
source: SRD 5.2.1
---

```statblock
name: Guardian Naga
size: Large
type: Celestial
alignment: Lawful Good
ac: 18
hp: 136 (16d10 + 48)
hit_dice: 16d10 + 48
speed: 40 ft., Climb 40 ft., Swim 40 ft.
stats: [19, 18, 16, 16, 19, 18]
saves:
  - Dex: +8
  - Con: +7
  - Int: +7
  - Wis: +8
  - Cha: +8
skillsaves:
  - Arcana: +11
  - History: +11
  - Religion: +11
damage_immunities: Poison
condition_immunities: Charmed, Paralyzed, Poisoned, Restrained
senses: Darkvision 60 ft.; Passive Perception 14
languages: Celestial, Common
cr: 10
traits:
  - name: "Celestial Restoration"
    desc: "If the naga dies, it returns to life in 1d6 days and regains all its Hit Points unless Dispel Evil and Good is cast on its remains."
actions:
  - name: "Multiattack"
    desc: "The naga makes two Bite attacks. It can replace any attack with a use of Poisonous Spittle."
  - name: "Bite"
    desc: "Melee Attack Roll: +8, reach 10 ft. Hit: 17 (2d12 + 4) Piercing damage plus 22 (4d10) Poison damage."
  - name: "Poisonous Spittle"
    desc: "Constitution Saving Throw: DC 16, one creature the naga can see within 60 feet. Failure: 31 (7d8) Poison damage, and the target has the Blinded condition until the start of the naga’s next turn. Success: Half damage only."
  - name: "Spellcasting"
    desc: "The naga casts one of the following spells, requiring no Somatic or Material components and using Wisdom as the spellcasting ability (spell save DC 16): At Will: Thaumaturgy 1/Day Each: Clairvoyance, Cure Wounds (level 6 version), Flame Strike (level 6 version), Geas, True Seeing"
```

#Monster
