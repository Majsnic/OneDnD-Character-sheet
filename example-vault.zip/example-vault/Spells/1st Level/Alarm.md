---
Spell level: 1
School type: Abjuration
Casting Time: 1 minute or Ritual
Components:
  - Verbal
  - Somatic
  - Material
Concentration: false
Duration: 8 hours
Range / Area: 30 feet
Attack / Save: None
Damage / Effect: Utility
Upscale: 
category: 1st level
---
_Level 1 Abjuration_

- **Casting time:** 1 minute or Ritual
- **Range:** 30 feet
- **Components:** V, S, M
- **Duration:** 8 hours
- **Attack/Save**: None
- **Damage/Effect**: Utility

You set an alarm against intrusion. Choose a door, a window, or an area within range that is no larger than a 20-foot Cube. Until the spell ends, an alarm alerts you whenever a creature touches or enters the warded area. When you cast the spell, you can designate creatures that won’t set off the alarm. You also choose whether the alarm is audible or mental: Audible Alarm. The alarm produces the sound of a handbell for 10 seconds within 60 feet of the warded area. Mental Alarm. You are alerted by a mental ping if you are within 1 mile of the warded area. This ping awakens you if you’re asleep.

#Spell
