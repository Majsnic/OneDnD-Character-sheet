---
type: object
tags:
  - Item
  - item/common
  - item/weapon
item_category: Weapon
weapon_category: "Martial Ranged"
damage_dice: "1d6"
damage_type: Piercing
weapon_properties: [Ammunition, Light, Loading]
range_normal: 30
range_long: 120
weapon_mastery: Vex
attack_bonus: 0
damage_bonus: 0
cost: "75 GP"
weight_lb: 3
---


###### Hand Crossbow
_Martial Ranged Weapon_
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>**1d6 Piercing damage.** Range 30/120 ft. Properties: Light, Loading. Cost 75 GP, weight 3 lb.
>
>- **Ammunition.** You can use a weapon that has the Ammunition property to make a ranged attack only if you have ammunition to fire from it.
>- **Light.** You can make an extra attack with a second Light weapon as a Bonus Action (Two-Weapon Fighting) without adding your ability modifier to the extra attack's damage unless it's negative.
>- **Loading.** You can fire only one piece of ammunition from this weapon when you use an action, Bonus Action, or Reaction to fire it, regardless of the number of attacks you can normally make.
>
>**_Vex (Mastery)._** If you hit a creature with this weapon and deal damage, you have Advantage on your next attack roll against that same creature before the end of your next turn.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
