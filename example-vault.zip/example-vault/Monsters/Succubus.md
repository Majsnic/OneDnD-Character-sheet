---
Type: Fiend
CR: 4
Size: Medium
tags:
  - Monster
  - Fiend
source: SRD 5.2.1
---

```statblock
name: Succubus
size: Medium
type: Fiend
alignment: Neutral Evil
ac: 15
hp: 71 (13d8 + 13)
hit_dice: 13d8 + 13
speed: 30 ft., Fly 60 ft.
stats: [8, 17, 13, 15, 12, 20]
skillsaves:
  - Deception: +9
  - Insight: +5
  - Perception: +5
  - Persuasion: +9
  - Stealth: +7
damage_resistances: Cold, Fire, Poison, Psychic
senses: Darkvision 60 ft.; Passive Perception 15
languages: Abyssal, Common, Infernal; telepathy 60 ft.
cr: 4
traits:
  - name: "Incubus Form"
    desc: "When the succubus finishes a Long Rest, it can shape-shift into an Incubus, using that stat block instead of this one."
actions:
  - name: "Multiattack"
    desc: "The succubus makes one Fiendish Touch attack and uses Charm or Draining Kiss."
  - name: "Fiendish Touch"
    desc: "Melee Attack Roll: +7, reach 5 ft. Hit: 16 (2d10 + 5) Psychic damage."
  - name: "Charm"
    desc: "The succubus casts Dominate Person (level 8 version), requiring no spell components and using Charisma as the spellcasting ability (spell save DC 15)."
  - name: "Draining Kiss"
    desc: "Constitution Saving Throw: DC 15, one creature Charmed by the succubus within 5 feet. Failure: 13 (3d8) Psychic damage. Success: Half damage. Failure or Success: The target’s Hit Point maximum decreases by an amount equal to the damage taken."
bonusactions:
  - name: "Shape-Shift"
    desc: "The succubus shape-shifts into a Medium or Small Humanoid, or it returns to its true form. Its game statistics are the same in each form, except its Fly Speed is available only in its true form. Any equipment it is wearing or carrying isn’t transformed."
```

#Monster
