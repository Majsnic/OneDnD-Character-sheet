---
Spell level: 1
School type: Divination
Casting Time: Bonus Action
Components:
  - Verbal
Concentration: true
Duration: 1 hour
Range / Area: 90 feet
Attack / Save: Auto-hit
Damage / Effect: 1d6 Force
Upscale: 
category: 1st level
---
_Level 1 Divination_

- **Casting time:** Bonus Action
- **Range:** 90 feet
- **Components:** V
- **Duration:** 1 hour
- **Attack/Save**: Auto-hit
- **Damage/Effect**: Force

You magically mark one creature you can see within range as your quarry. Until the spell ends, you deal an extra 1d6 Force damage to the target whenever you hit it with an attack roll. You also have Advantage on any Wisdom (Perception or Survival) check you make to find it. If the target drops to 0 Hit Points before this spell ends, you can take a Bonus Action to move the mark to a new creature you can see within range.

**_Using a Higher-Level Spell Slot._** Your Concentration can last longer with a spell slot of level 3–4 (up to 8 hours) or 5+ (up to 24 hours).

#Spell
