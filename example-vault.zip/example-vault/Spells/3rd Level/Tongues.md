---
Spell level: 3
School type: Divination
Casting Time: Action
Components:
  - Verbal
  - Material
Concentration: false
Duration: 1 hour
Range / Area: Touch
Attack / Save: None
Damage / Effect: Utility
Upscale: 
category: 3rd level
---
_Level 3 Divination_

- **Casting time:** Action
- **Range:** Touch
- **Components:** V, M
- **Duration:** 1 hour
- **Attack/Save**: None
- **Damage/Effect**: Utility

This spell grants the creature you touch the ability to understand any spoken or signed language that it hears or sees. Moreover, when the target communicates by speaking or signing, any creature that knows at least one language can understand it if that creature can hear the speech or see the signing.

#Spell
