---
Spell level: 1
School type: Evocation
Casting Time: Action
Components:
  - Verbal
Concentration: true
Duration: 1 minute
Range / Area: 60 feet
Attack / Save: DEX Save
Damage / Effect: Invisible
Upscale: 
category: 1st level
---
_Level 1 Evocation_

- **Casting time:** Action
- **Range:** 60 feet
- **Components:** V
- **Duration:** 1 minute
- **Attack/Save**: DEX Save
- **Damage/Effect**: Invisible

Objects in a 20-foot Cube within range are outlined in blue, green, or violet light (your choice). Each creature in the Cube is also outlined if it fails a Dexterity saving throw. For the duration, objects and affected creatures shed Dim Light in a 10-foot radius and can’t benefit from the Invisible condition. Attack rolls against an affected creature or object have Advantage if the attacker can see it.

#Spell
