---
Type: Plant
CR: 0
Size: Medium
tags:
  - Monster
  - Plant
source: SRD 5.2.1
---

```statblock
name: Shrieker Fungus
size: Medium
type: Plant
alignment: Unaligned
ac: 5
hp: 13 (3d8)
hit_dice: 3d8
speed: 5 ft.
stats: [1, 1, 10, 1, 3, 1]
condition_immunities: Blinded, Charmed, Deafened, Frightened
senses: Blindsight 30 ft.; Passive Perception 6
languages: None
cr: 0
reactions:
  - name: "Shriek"
    desc: "Trigger: A creature or a source of Bright Light moves within 30 feet of the shrieker. Response: The shrieker emits a shriek audible within 300 feet of itself for 1 minute or until the shrieker dies."
```

#Monster
