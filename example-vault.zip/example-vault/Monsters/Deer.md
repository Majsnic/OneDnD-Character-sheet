---
Type: Beast
CR: 0
Size: Medium
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Deer
size: Medium
type: Beast
alignment: Unaligned
ac: 13
hp: 4 (1d8)
hit_dice: 1d8
speed: 50 ft.
stats: [11, 16, 11, 2, 14, 5]
skillsaves:
  - Perception: +4
senses: Darkvision 60 ft.; Passive Perception 14
languages: None
cr: 0
traits:
  - name: "Agile"
    desc: "The deer doesn’t provoke an Opportunity Attack when it moves out of an enemy’s reach."
actions:
  - name: "Ram"
    desc: "Melee Attack Roll: +2, reach 5 ft. Hit: 2 (1d4) Bludgeoning damage."
```

#Monster
