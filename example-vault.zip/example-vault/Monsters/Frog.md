---
Type: Beast
CR: 0
Size: Tiny
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Frog
size: Tiny
type: Beast
alignment: Unaligned
ac: 11
hp: 1 (1d4 - 1)
hit_dice: 1d4 - 1
speed: 20 ft., Swim 20 ft.
stats: [1, 13, 8, 1, 8, 3]
skillsaves:
  - Perception: +1
  - Stealth: +3
senses: Darkvision 30 ft.; Passive Perception 11
languages: None
cr: 0
traits:
  - name: "Amphibious"
    desc: "The frog can breathe air and water."
  - name: "Standing Leap"
    desc: "The frog’s Long Jump is up to 10 feet and its High Jump is up to 5 feet with or without a running start."
actions:
  - name: "Bite"
    desc: "Melee Attack Roll: +3, reach 5 ft. Hit: 1 Piercing damage."
```

#Monster
