---
Type: Humanoid
CR: 2
Size: Medium or Small
tags:
  - Monster
  - Humanoid
source: SRD 5.2.1
---

```statblock
name: Cultist Fanatic
size: Medium or Small
type: Humanoid
alignment: Neutral
ac: 13
hp: 44 (8d8 + 8)
hit_dice: 8d8 + 8
speed: 30 ft.
stats: [11, 14, 12, 10, 14, 13]
saves:
  - Wis: +4
skillsaves:
  - Deception: +3
  - Persuasion: +3
  - Religion: +2
gear: Holy Symbol, Leather Armor
senses: Passive Perception 12
languages: Common
cr: 2
actions:
  - name: "Pact Blade"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 6 (1d8 + 2) Slashing damage plus 7 (2d6) Necrotic damage."
  - name: "Spellcasting"
    desc: "The cultist casts one of the following spells, using Wisdom as the spellcasting ability (spell save DC 12, +4 to hit with spell attacks): At Will: Light, Thaumaturgy 2/Day: Command 1/Day: Hold Person"
bonusactions:
  - name: "Spiritual Weapon (2/Day)"
    desc: "The cultist casts the Spiritual Weapon spell, using the same spellcasting ability as Spellcasting."
```

#Monster
