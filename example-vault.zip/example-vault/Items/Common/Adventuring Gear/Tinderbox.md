---
type: object
tags:
  - Item
  - item/common
  - item/gear
item_category: "Adventuring Gear"
cost: "5 SP"
weight_lb: 1
---


###### Tinderbox
_Adventuring Gear_
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>This small container holds flint, fire steel, and tinder used to kindle a fire. Using it to light a torch or other object that catches fire easily takes an action; lighting any other fire takes 1 minute. Cost 5 SP, weight 1 lb.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
