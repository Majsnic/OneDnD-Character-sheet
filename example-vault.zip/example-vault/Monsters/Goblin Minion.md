---
Type: Fey
CR: 1/8
Size: Small
tags:
  - Monster
  - Fey
source: SRD 5.2.1
---

```statblock
name: Goblin Minion
size: Small
type: Fey (Goblinoid)
alignment: Chaotic Neutral
ac: 12
hp: 7 (2d6)
hit_dice: 2d6
speed: 30 ft.
stats: [8, 15, 10, 10, 8, 8]
skillsaves:
  - Stealth: +6
gear: Daggers (3)
senses: Darkvision 60 ft.; Passive Perception 9
languages: Common, Goblin
cr: 1/8
actions:
  - name: "Dagger"
    desc: "Melee or Ranged Attack Roll: +4, reach 5 ft. or range 20/60 ft. Hit: 4 (1d4 + 2) Piercing damage."
bonusactions:
  - name: "Nimble Escape"
    desc: "The goblin takes the Disengage or Hide action."
```

#Monster
