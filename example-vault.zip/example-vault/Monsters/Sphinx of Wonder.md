---
Type: Celestial
CR: 1
Size: Tiny
tags:
  - Monster
  - Celestial
source: SRD 5.2.1
---

```statblock
name: Sphinx of Wonder
size: Tiny
type: Celestial
alignment: Lawful Good
ac: 13
hp: 24 (7d4 + 7)
hit_dice: 7d4 + 7
speed: 20 ft., Fly 40 ft.
stats: [6, 17, 13, 15, 12, 11]
skillsaves:
  - Arcana: +4
  - Religion: +4
  - Stealth: +5
damage_resistances: Necrotic, Psychic, Radiant
senses: Darkvision 60 ft.; Passive Perception 11
languages: Celestial, Common
cr: 1
traits:
  - name: "Magic Resistance"
    desc: "The sphinx has Advantage on saving throws against spells and other magical effects."
actions:
  - name: "Rend"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 5 (1d4 + 3) Slashing damage plus 7 (2d6) Radiant damage."
reactions:
  - name: "Burst of Ingenuity (2/Day)"
    desc: "Trigger: The sphinx or another creature within 30 feet makes an ability check or a saving throw. Response: The sphinx adds 2 to the roll."
```

#Monster
