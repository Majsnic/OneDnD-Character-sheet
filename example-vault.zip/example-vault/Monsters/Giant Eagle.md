---
Type: Celestial
CR: 1
Size: Large
tags:
  - Monster
  - Celestial
source: SRD 5.2.1
---

```statblock
name: Giant Eagle
size: Large
type: Celestial
alignment: Neutral Good
ac: 13
hp: 26 (4d10 + 4)
hit_dice: 4d10 + 4
speed: 10 ft., Fly 80 ft.
stats: [16, 17, 13, 8, 14, 10]
skillsaves:
  - Perception: +6
damage_resistances: Necrotic, Radiant
senses: Passive Perception 16
languages: Celestial; understands Common and Primordial (Auran) but can’t speak them
cr: 1
actions:
  - name: "Multiattack"
    desc: "The eagle makes two Rend attacks."
  - name: "Rend"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 5 (1d4 + 3) Slashing damage plus 3 (1d6) Radiant damage."
```

#Monster
