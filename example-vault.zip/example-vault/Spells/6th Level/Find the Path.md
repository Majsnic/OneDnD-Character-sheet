---
Spell level: 6
School type: Divination
Casting Time: 1 minute
Components:
  - Verbal
  - Somatic
  - Material
Concentration: true
Duration: 1 day
Range / Area: Self
Attack / Save: None
Damage / Effect: Utility
Upscale: 
category: 6th level
---
_Level 6 Divination_

- **Casting time:** 1 minute
- **Range:** Self
- **Components:** V, S, M
- **Duration:** 1 day
- **Attack/Save**: None
- **Damage/Effect**: Utility

You magically sense the most direct physical route to a location you name. You must be familiar with the location, and the spell fails if you name a destination on another plane of existence, a moving destination (such as a mobile fortress), or an unspecific destination (such as “a green dragon’s lair”). For the duration, as long as you are on the same plane of existence as the destination, you know how far it is and in what direction it lies. Whenever you

#Spell
