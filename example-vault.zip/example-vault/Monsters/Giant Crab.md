---
Type: Beast
CR: 1/8
Size: Medium
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Giant Crab
size: Medium
type: Beast
alignment: Unaligned
ac: 15
hp: 13 (3d8)
hit_dice: 3d8
speed: 30 ft., Swim 30 ft.
stats: [13, 13, 11, 1, 9, 3]
skillsaves:
  - Stealth: +3
senses: Blindsight 30 ft.; Passive Perception 9
languages: None
cr: 1/8
traits:
  - name: "Amphibious"
    desc: "The crab can breathe air and water."
actions:
  - name: "Claw"
    desc: "Melee Attack Roll: +3, reach 5 ft. Hit: 4 (1d6 + 1) Bludgeoning damage. If the target is a Medium or smaller creature, it has the Grappled condition (escape DC 11) from one of two claws."
```

#Monster
