---
Type: Dragon
CR: 2
Size: Medium
tags:
  - Monster
  - Dragon
source: SRD 5.2.1
---

```statblock
name: Silver Dragon Wyrmling
size: Medium
type: Dragon (Metallic)
alignment: Lawful Good
ac: 17
hp: 45 (6d8 + 18)
hit_dice: 6d8 + 18
speed: 30 ft., Fly 60 ft.
stats: [19, 10, 17, 12, 11, 15]
saves:
  - Dex: +2
  - Wis: +2
skillsaves:
  - Perception: +4
  - Stealth: +2
damage_immunities: Cold
senses: Blindsight 10 ft., Darkvision 60 ft.; Passive Perception 14
languages: Draconic
cr: 2
actions:
  - name: "Multiattack"
    desc: "The dragon makes two Rend attacks."
  - name: "Rend"
    desc: "Melee Attack Roll: +6, reach 5 ft. Hit: 9 (1d10 + 4) Piercing damage."
  - name: "Cold Breath (Recharge 5–6)"
    desc: "Constitution Saving Throw: DC 13, each creature in a 15-foot Cone. Failure: 18 (4d8) Cold damage. Success: Half damage."
  - name: "Paralyzing Breath"
    desc: "Constitution Saving Throw: DC 13, each creature in a 15-foot Cone. First Failure: The target has the Incapacitated condition until the end of its next turn, when it repeats the save. Second Failure: The target has the Paralyzed condition, and it repeats the save at the end of each of its turns, ending the effect on itself on a success. After 1 minute, it succeeds automatically."
```

#Monster
