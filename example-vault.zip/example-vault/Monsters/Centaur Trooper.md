---
Type: Fey
CR: 2
Size: Large
tags:
  - Monster
  - Fey
source: SRD 5.2.1
---

```statblock
name: Centaur Trooper
size: Large
type: Fey
alignment: Neutral Good
ac: 16
hp: 45 (6d10 + 12)
hit_dice: 6d10 + 12
speed: 50 ft.
stats: [18, 14, 14, 9, 13, 11]
skillsaves:
  - Athletics: +6
  - Perception: +3
gear: Breastplate, Longbow, Pike
senses: Passive Perception 13
languages: Elvish, Sylvan
cr: 2
actions:
  - name: "Multiattack"
    desc: "The centaur makes two attacks, using Pike or Longbow in any combination."
  - name: "Pike"
    desc: "Melee Attack Roll: +6, reach 10 ft. Hit: 9 (1d10 + 4) Piercing damage."
  - name: "Longbow"
    desc: "Ranged Attack Roll: +4, range 150/600 ft. Hit: 6 (1d8 + 2) Piercing damage."
bonusactions:
  - name: "Trampling Charge (Recharge 5–6)"
    desc: "The centaur moves up to its Speed without provoking Opportunity Attacks and can move through the spaces of Medium or smaller creatures. Each creature whose space the centaur enters is targeted once by the following effect. Strength Saving Throw: DC 14. Failure: 7 (1d6 + 4) Bludgeoning damage, and the target has the Prone condition."
```

#Monster
