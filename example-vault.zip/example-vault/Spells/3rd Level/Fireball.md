---
Spell level: 3
School type: Evocation
Casting Time: Action
Components:
  - Verbal
  - Somatic
  - Material
Concentration: false
Duration: Instantaneous
Range / Area: 150 feet
Attack / Save: DEX Save
Damage / Effect: 8d6 Fire
Upscale: + 1d6
category: 3rd level
---
_Level 3 Evocation_

- **Casting time:** Action
- **Range:** 150 feet
- **Components:** V, S, M
- **Duration:** Instantaneous
- **Attack/Save**: DEX Save
- **Damage/Effect**: Fire

A bright streak flashes from you to a point you choose within range and then blossoms with a low roar into a fiery explosion. Each creature in a 20-foot-radius Sphere centered on that point makes a Dexterity saving throw, taking 8d6 Fire damage on a failed save or half as much damage on a successful one. Flammable objects in the area that aren’t being worn or carried start burning.

**_Using a Higher-Level Spell Slot._** The damage increases by 1d6 for each spell slot level above 3.

#Spell
