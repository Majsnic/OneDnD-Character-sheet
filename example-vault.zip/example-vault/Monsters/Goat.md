---
Type: Beast
CR: 0
Size: Medium
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Goat
size: Medium
type: Beast
alignment: Unaligned
ac: 10
hp: 4 (1d8)
hit_dice: 1d8
speed: 40 ft., Climb 30 ft.
stats: [11, 10, 11, 2, 10, 5]
saves:
  - Str: +2
skillsaves:
  - Perception: +2
senses: Darkvision 60 ft.; Passive Perception 12
languages: None
cr: 0
actions:
  - name: "Ram"
    desc: "Melee Attack Roll: +2, reach 5 ft. Hit: 1 Bludgeoning damage, or 2 (1d4) Bludgeoning damage if the goat moved 20+ feet straight toward the target immediately before the hit."
```

#Monster
