---
Spell level: 1
School type: Transmutation
Casting Time: Bonus Action
Components:
  - Verbal
  - Somatic
  - Material
Concentration: false
Duration: 1 minute
Range / Area: Touch
Attack / Save: None
Damage / Effect: Utility
Upscale: + 1 creature
category: 1st level
---
_Level 1 Transmutation_

- **Casting time:** Bonus Action
- **Range:** Touch
- **Components:** V, S, M
- **Duration:** 1 minute
- **Attack/Save**: None
- **Damage/Effect**: Utility

You touch a willing creature. Once on each of its turns until the spell ends, that creature can jump up to 30 feet by spending 10 feet of movement.

**_Using a Higher-Level Spell Slot._** You can target one additional creature for each spell slot level above 1.

#Spell
