---
Type: Beast
CR: 1/4
Size: Medium
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Giant Venomous Snake
size: Medium
type: Beast
alignment: Unaligned
ac: 14
hp: 11 (2d8 + 2)
hit_dice: 2d8 + 2
speed: 40 ft., Swim 40 ft.
stats: [10, 18, 13, 2, 10, 3]
skillsaves:
  - Perception: +2
senses: Blindsight 10 ft.; Passive Perception 12
languages: None
cr: 1/4
actions:
  - name: "Bite"
    desc: "Melee Attack Roll: +6, reach 10 ft. Hit: 6 (1d4 + 4) Piercing damage plus 4 (1d8) Poison damage."
```

#Monster
