---
Type: Dragon
CR: 1/8
Size: Small
tags:
  - Monster
  - Dragon
source: SRD 5.2.1
---

```statblock
name: Kobold Warrior
size: Small
type: Dragon
alignment: Neutral
ac: 14
hp: 7 (3d6 - 3)
hit_dice: 3d6 - 3
speed: 30 ft.
stats: [7, 15, 9, 8, 7, 8]
gear: Daggers (3)
senses: Darkvision 60 ft.; Passive Perception 8
languages: Common, Draconic
cr: 1/8
traits:
  - name: "Pack Tactics"
    desc: "The kobold has Advantage on an attack roll against a creature if at least one of the kobold’s allies is within 5 feet of the creature and the ally doesn’t have the Incapacitated condition."
  - name: "Sunlight Sensitivity"
    desc: "While in sunlight, the kobold has Disadvantage on ability checks and attack rolls."
actions:
  - name: "Dagger"
    desc: "Melee or Ranged Attack Roll: +4, reach 5 ft. or range 20/60 ft. Hit: 4 (1d4 + 2) Piercing damage."
```

#Monster
