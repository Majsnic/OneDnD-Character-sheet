---
Type: Beast
CR: 2
Size: Large
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Allosaurus
size: Large
type: Beast (Dinosaur)
alignment: Unaligned
ac: 13
hp: 51 (6d10 + 18)
hit_dice: 6d10 + 18
speed: 60 ft.
stats: [19, 13, 17, 2, 12, 5]
skillsaves:
  - Perception: +5
senses: Passive Perception 15
languages: None
cr: 2
actions:
  - name: "Bite"
    desc: "Melee Attack Roll: +6, reach 5 ft. Hit: 15 (2d10 + 4) Piercing damage."
  - name: "Claws"
    desc: "Melee Attack Roll: +6, reach 5 ft. Hit: 8 (1d8 + 4) Slashing damage. If the target is a Large or smaller creature and the allosaurus moved 30+ feet straight toward it immediately before the hit, the target has the Prone condition, and the allosaurus can make one Bite attack against it."
```

#Monster
