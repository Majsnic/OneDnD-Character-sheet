---
Type: Beast
CR: 5
Size: Huge
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Giant Crocodile
size: Huge
type: Beast
alignment: Unaligned
ac: 14
hp: 85 (9d12 + 27)
hit_dice: 9d12 + 27
speed: 30 ft., Swim 50 ft.
stats: [21, 9, 17, 2, 10, 7]
skillsaves:
  - Stealth: +5
senses: Passive Perception 10
languages: None
cr: 5
traits:
  - name: "Hold Breath"
    desc: "The crocodile can hold its breath for 1 hour."
actions:
  - name: "Multiattack"
    desc: "The crocodile makes one Bite attack and one Tail attack."
  - name: "Bite"
    desc: "Melee Attack Roll: +8, reach 5 ft. Hit: 21 (3d10 + 5) Piercing damage. If the target is a Large or smaller creature, it has the Grappled condition (escape DC 15). While Grappled, the target has the Restrained condition and can’t be targeted by the crocodile’s Tail."
  - name: "Tail"
    desc: "Melee Attack Roll: +8, reach 10 ft. Hit: 18 (3d8 + 5) Bludgeoning damage. If the target is a Large or smaller creature, it has the Prone condition."
```

#Monster
