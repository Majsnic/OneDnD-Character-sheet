---
type: object
tags:
  - Item
  - item/common
  - item/armor
item_category: Armor
armor_category: Light
armor_class_base: 11
armor_class_dex_cap: null  # unlimited Dex bonus
stealth_disadvantage: false
cost: "10 GP"
weight_lb: 10
---


###### Leather
_Light Armor_
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>**AC 11 + Dex modifier.** Cost 10 GP, weight 10 lb.
>
>Donning this armor takes 1 minute; doffing takes 1 minute.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
