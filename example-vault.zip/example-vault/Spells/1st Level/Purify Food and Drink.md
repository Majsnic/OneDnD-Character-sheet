---
Spell level: 1
School type: Transmutation
Casting Time: Action or Ritual
Components:
  - Verbal
  - Somatic
Concentration: false
Duration: Instantaneous
Range / Area: 10 feet
Attack / Save: None
Damage / Effect: Utility
Upscale: 
category: 1st level
---
_Level 1 Transmutation_

- **Casting time:** Action or Ritual
- **Range:** 10 feet
- **Components:** V, S
- **Duration:** Instantaneous
- **Attack/Save**: None
- **Damage/Effect**: Utility

You remove poison and rot from nonmagical food and drink in a 5-foot-radius Sphere centered on a point within range.

#Spell
