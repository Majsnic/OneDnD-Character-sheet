---
Type: Beast
CR: 0
Size: Tiny
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Piranha
size: Tiny
type: Beast
alignment: Unaligned
ac: 13
hp: 1 (1d4 - 1)
hit_dice: 1d4 - 1
speed: 5 ft., Swim 40 ft.
stats: [2, 16, 9, 1, 7, 2]
senses: Darkvision 60 ft.; Passive Perception 8
languages: None
cr: 0
traits:
  - name: "Water Breathing"
    desc: "The piranha can breathe only underwater."
actions:
  - name: "Bite"
    desc: "Melee Attack Roll: +5 (with Advantage if the target doesn’t have all its Hit Points), reach 5 ft. Hit: 1 Piercing damage."
```

#Monster
