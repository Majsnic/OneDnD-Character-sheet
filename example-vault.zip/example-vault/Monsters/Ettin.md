---
Type: Giant
CR: 4
Size: Large
tags:
  - Monster
  - Giant
source: SRD 5.2.1
---

```statblock
name: Ettin
size: Large
type: Giant
alignment: Chaotic Evil
ac: 12
hp: 85 (10d10 + 30)
hit_dice: 10d10 + 30
speed: 40 ft.
stats: [21, 8, 17, 6, 10, 8]
skillsaves:
  - Perception: +4
condition_immunities: Blinded, Charmed, Deafened, Frightened, Stunned, Unconscious
gear: Battleaxe, Morningstar
senses: Darkvision 60 ft.; Passive Perception 14
languages: Giant
cr: 4
actions:
  - name: "Multiattack"
    desc: "The ettin makes one Battleaxe attack and one Morningstar attack."
  - name: "Battleaxe"
    desc: "Melee Attack Roll: +7, reach 5 ft. Hit: 14 (2d8 + 5) Slashing damage. If the target is a Large or smaller creature, it has the Prone condition."
  - name: "Morningstar"
    desc: "Melee Attack Roll: +7, reach 5 ft. Hit: 14 (2d8 + 5) Piercing damage, and the target has Disadvantage on the next attack roll it makes before the end of its next turn."
```

#Monster
