---
Spell level: 6
School type: Conjuration
Casting Time: Action
Components:
  - Verbal
  - Somatic
  - Material
Concentration: true
Duration: 10 minutes
Range / Area: 120 feet
Attack / Save: DEX Save
Damage / Effect: 7d8 Piercing
Upscale: + 1d8
category: 6th level
---
_Level 6 Conjuration_

- **Casting time:** Action
- **Range:** 120 feet
- **Components:** V, S, M
- **Duration:** 10 minutes
- **Attack/Save**: DEX Save
- **Damage/Effect**: Piercing

You create a wall of tangled brush bristling with needle-sharp thorns. The wall appears within range on a solid surface and lasts for the duration. You choose to make the wall up to 60 feet long, 10 feet high, and 5 feet thick or a circle that has a 20-foot diameter and is up to 20 feet high and 5 feet thick. The wall blocks line of sight. When the wall appears, each creature in its area makes a Dexterity saving throw, taking 7d8 Piercing damage on a failed save or half as much damage on a successful one. A creature can move through the wall, albeit slowly and painfully. For every 1 foot a creature moves through the wall, it must spend 4 feet of movement. Furthermore, the first time a creature enters a space in the wall on a turn or ends its turn there, the creature makes a Dexterity saving throw, taking 7d8 Slashing damage on a failed save or half as much damage on a successful one. A creature makes this save only once per turn.

**_Using a Higher-Level Spell Slot._** Both types of damage increase by 1d8 for each spell slot level above 6.

#Spell
