---
Spell level: 1
School type: Necromancy
Casting Time: Action
Components:
  - Verbal
  - Somatic
Concentration: false
Duration: Instantaneous
Range / Area: 60 feet
Attack / Save: Ranged
Damage / Effect: 2d8 Poison
Upscale: + 1d8
category: 1st level
---
_Level 1 Necromancy_

- **Casting time:** Action
- **Range:** 60 feet
- **Components:** V, S
- **Duration:** Instantaneous
- **Attack/Save**: Ranged
- **Damage/Effect**: Poison

You shoot a greenish ray at a creature within range. Make a ranged spell attack against the target. On a hit, the target takes 2d8 Poison damage and has the Poisoned condition until the end of your next turn.

**_Using a Higher-Level Spell Slot._** The damage increases by 1d8 for each spell slot level above 1.

#Spell
