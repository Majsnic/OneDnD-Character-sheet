---
tags:
  - Condition
source: SRD 5.2.1
---

# Deafened

You can't hear, and you automatically fail any ability check that requires hearing.

*Paraphrased mechanical summary, written from general knowledge of the SRD rules — treat it as a helpful draft, not a verbatim rules quote.*

#Condition
