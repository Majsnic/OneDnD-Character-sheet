---
Type: Celestial
CR: 2
Size: Large
tags:
  - Monster
  - Celestial
source: SRD 5.2.1
---

```statblock
name: Pegasus
size: Large
type: Celestial
alignment: Chaotic Good
ac: 12
hp: 59 (7d10 + 21)
hit_dice: 7d10 + 21
speed: 60 ft., Fly 90 ft.
stats: [18, 15, 16, 10, 15, 13]
saves:
  - Dex: +4
  - Con: +5
  - Wis: +4
  - Cha: +3
skillsaves:
  - Perception: +6
senses: Passive Perception 16
languages: Understands Celestial, Common, Elvish, and Sylvan but can’t speak
cr: 2
actions:
  - name: "Hooves"
    desc: "Melee Attack Roll: +6, reach 5 ft. Hit: 7 (1d6 + 4) Bludgeoning damage plus 5 (2d4) Radiant damage."
```

#Monster
