---
Spell level: 1
School type: Evocation
Casting Time: Action
Components:
  - Verbal
  - Somatic
Concentration: false
Duration: Instantaneous
Range / Area: Self
Attack / Save: CON Save
Damage / Effect: 2d8 Thunder
Upscale: + 1d8
category: 1st level
---
_Level 1 Evocation_

- **Casting time:** Action
- **Range:** Self
- **Components:** V, S
- **Duration:** Instantaneous
- **Attack/Save**: CON Save
- **Damage/Effect**: Thunder

You unleash a wave of thunderous energy. Each creature in a 15-foot Cube originating from you makes a Constitution saving throw. On a failed save, a creature takes 2d8 Thunder damage and is pushed 10 feet away from you. On a successful save, a creature takes half as much damage only. In addition, unsecured objects that are entirely within the Cube are pushed 10 feet away from you, and a thunderous boom is audible within 300 feet.

**_Using a Higher-Level Spell Slot._** The damage increases by 1d8 for each spell slot level above 1.

#Spell
