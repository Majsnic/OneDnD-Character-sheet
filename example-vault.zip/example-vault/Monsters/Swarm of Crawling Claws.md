---
Type: Undead
CR: 3
Size: Medium
tags:
  - Monster
  - Undead
source: SRD 5.2.1
---

```statblock
name: Swarm of Crawling Claws
size: Medium
type: Swarm of Tiny Undead
alignment: Neutral Evil
ac: 12
hp: 49 (11d8)
hit_dice: 11d8
speed: 30 ft., Climb 30 ft.
stats: [14, 14, 11, 5, 10, 4]
damage_resistances: Bludgeoning, Piercing, Slashing
damage_immunities: Necrotic, Poison
condition_immunities: Charmed, Exhaustion, Frightened, Grappled, Incapacitated, Paralyzed, Petrified, Poisoned, Prone, Restrained, Stunned
senses: Blindsight 30 ft.; Passive Perception 10
languages: Understands Common but can’t speak
cr: 3
traits:
  - name: "Swarm"
    desc: "The swarm can occupy another creature’s space and vice versa, and the swarm can move through any opening large enough for a Tiny creature. The swarm can’t regain Hit Points or gain Temporary Hit Points."
actions:
  - name: "Swarm of Grasping Hands"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 20 (4d8 + 2) Necrotic damage, or 11 (2d8 + 2) Necrotic damage if the swarm is Bloodied. If the target is a Medium or smaller creature, it has the Prone condition."
```

#Monster
