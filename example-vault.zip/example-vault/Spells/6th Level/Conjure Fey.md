---
Spell level: 6
School type: Conjuration
Casting Time: Action
Components:
  - Verbal
  - Somatic
Concentration: true
Duration: 10 minutes
Range / Area: 60 feet
Attack / Save: Melee
Damage / Effect: Frightened
Upscale: + 1d12
category: 6th level
---
_Level 6 Conjuration_

- **Casting time:** Action
- **Range:** 60 feet
- **Components:** V, S
- **Duration:** 10 minutes
- **Attack/Save**: Melee
- **Damage/Effect**: Frightened

You conjure a Medium spirit from the Feywild in an unoccupied space you can see within range. The spirit lasts for the duration, and it looks like a Fey creature of your choice. When the spirit appears, you can make one melee spell attack against a creature within 5 feet of it. On a hit, the target takes Psychic damage equal to 3d12 plus your spellcasting ability modifier, and the target has the Frightened condition until the start of your next turn, with both you and the spirit as the source of the fear. As a Bonus Action on your later turns, you can teleport the spirit to an unoccupied space you can see within 30 feet of the space it left and make the attack against a creature within 5 feet of it.

**_Using a Higher-Level Spell Slot._** The damage increases by 1d12 for each spell slot level above 6.

#Spell
