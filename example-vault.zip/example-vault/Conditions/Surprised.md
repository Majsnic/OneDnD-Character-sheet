---
tags:
  - Condition
source: SRD 5.2.1
---

# Surprised

If you're caught off guard at the start of combat, you are considered Surprised: you can't move or take an action on your first turn, and you can't take a reaction until that turn ends.

*Paraphrased mechanical summary, written from general knowledge of the SRD rules — treat it as a helpful draft, not a verbatim rules quote.*

#Condition
