---
Type: Beast
CR: 1
Size: Large
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Dire Wolf
size: Large
type: Beast
alignment: Unaligned
ac: 14
hp: 22 (3d10 + 6)
hit_dice: 3d10 + 6
speed: 50 ft.
stats: [17, 15, 15, 3, 12, 7]
skillsaves:
  - Perception: +5
  - Stealth: +4
senses: Darkvision 60 ft.; Passive Perception 15
languages: None
cr: 1
traits:
  - name: "Pack Tactics"
    desc: "The wolf has Advantage on an attack roll against a creature if at least one of the wolf’s allies is within 5 feet of the creature and the ally doesn’t have the Incapacitated condition."
actions:
  - name: "Bite"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 8 (1d10 + 3) Piercing damage. If the target is a Large or smaller creature, it has the Prone condition."
```

#Monster
