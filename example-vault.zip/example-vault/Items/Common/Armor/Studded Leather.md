---
type: object
tags:
  - Item
  - item/common
  - item/armor
item_category: Armor
armor_category: Light
armor_class_base: 12
armor_class_dex_cap: null  # unlimited Dex bonus
stealth_disadvantage: false
cost: "45 GP"
weight_lb: 13
---


###### Studded Leather
_Light Armor_
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>**AC 12 + Dex modifier.** Cost 45 GP, weight 13 lb.
>
>Donning this armor takes 1 minute; doffing takes 1 minute.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
