---
Spell level: 3
School type: Necromancy
Casting Time: Action
Components:
  - Verbal
  - Somatic
Concentration: true
Duration: 1 minute
Range / Area: Self
Attack / Save: Melee
Damage / Effect: 3d6 Necrotic
Upscale: + 1d6
category: 3rd level
---
_Level 3 Necromancy_

- **Casting time:** Action
- **Range:** Self
- **Components:** V, S
- **Duration:** 1 minute
- **Attack/Save**: Melee
- **Damage/Effect**: Necrotic

The touch of your shadow-wreathed hand can siphon life force from others to heal your wounds. Make a melee spell attack against one creature within reach. On a hit, the target takes 3d6 Necrotic damage, and you regain Hit Points equal to half the amount of Necrotic damage dealt. Until the spell ends, you can make the attack again on each of your turns as a Magic action, targeting the same creature or a different one.

**_Using a Higher-Level Spell Slot._** The damage increases by 1d6 for each spell slot level above 3.

#Spell
