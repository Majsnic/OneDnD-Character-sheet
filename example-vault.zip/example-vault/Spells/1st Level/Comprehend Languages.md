---
Spell level: 1
School type: Divination
Casting Time: Action or Ritual
Components:
  - Verbal
  - Somatic
  - Material
Concentration: false
Duration: 1 hour
Range / Area: Self
Attack / Save: None
Damage / Effect: Utility
Upscale: 
category: 1st level
---
_Level 1 Divination_

- **Casting time:** Action or Ritual
- **Range:** Self
- **Components:** V, S, M
- **Duration:** 1 hour
- **Attack/Save**: None
- **Damage/Effect**: Utility

For the duration, you understand the literal meaning of any language that you hear or see signed. You also understand any written language that you see, but you must be touching the surface on which the words are written. It takes about 1 minute to read one page of text. This spell doesn’t decode symbols or secret messages.

#Spell
