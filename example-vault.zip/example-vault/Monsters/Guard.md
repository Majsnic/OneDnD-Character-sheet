---
Type: Humanoid
CR: 1/8
Size: Medium or Small
tags:
  - Monster
  - Humanoid
source: SRD 5.2.1
---

```statblock
name: Guard
size: Medium or Small
type: Humanoid
alignment: Neutral
ac: 16
hp: 11 (2d8 + 2)
hit_dice: 2d8 + 2
speed: 30 ft.
stats: [13, 12, 12, 10, 11, 10]
skillsaves:
  - Perception: +2
gear: Chain Shirt, Shield, Spear
senses: Passive Perception 12
languages: Common
cr: 1/8
actions:
  - name: "Spear"
    desc: "Melee or Ranged Attack Roll: +3, reach 5 ft. or range 20/60 ft. Hit: 4 (1d6 + 1) Piercing damage."
```

#Monster
