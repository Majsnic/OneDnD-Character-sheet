---
Type: Undead
CR: 1
Size: Medium
tags:
  - Monster
  - Undead
source: SRD 5.2.1
---

```statblock
name: Ghoul
size: Medium
type: Undead
alignment: Chaotic Evil
ac: 12
hp: 22 (5d8)
hit_dice: 5d8
speed: 30 ft.
stats: [13, 15, 10, 7, 10, 6]
damage_immunities: Poison
condition_immunities: Charmed, Exhaustion, Poisoned
senses: Darkvision 60 ft.; Passive Perception 10
languages: Common
cr: 1
actions:
  - name: "Multiattack"
    desc: "The ghoul makes two Bite attacks."
  - name: "Bite"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 5 (1d6 + 2) Piercing damage plus 3 (1d6) Necrotic damage."
  - name: "Claw"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 4 (1d4 + 2) Slashing damage. If the target is a creature that isn’t an Undead or elf, it is subjected to the following effect. Constitution Saving Throw: DC 10. Failure: The target has the Paralyzed condition until the end of its next turn."
```

#Monster
