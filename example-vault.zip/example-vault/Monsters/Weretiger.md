---
Type: Monstrosity
CR: 4
Size: Medium or Small
tags:
  - Monster
  - Monstrosity
source: SRD 5.2.1
---

```statblock
name: Weretiger
size: Medium or Small
type: Monstrosity (Lycanthrope)
alignment: Neutral
ac: 12
hp: 120 (16d8 + 48)
hit_dice: 16d8 + 48
speed: 30 ft., 40 ft. (tiger form only)
stats: [17, 15, 16, 10, 13, 11]
skillsaves:
  - Perception: +5
  - Stealth: +4
gear: Longbow
senses: Darkvision 60 ft.; Passive Perception 15
languages: Common (can’t speak in tiger form)
cr: 4
actions:
  - name: "Multiattack"
    desc: "The weretiger makes two attacks, using Scratch or Longbow in any combination. It can replace one attack with a Bite attack."
  - name: "Bite (Tiger or Hybrid Form Only)"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 12 (2d8 + 3) Piercing damage. If the target is a Humanoid, it is subjected to the following effect. Constitution Saving Throw: DC 13. Failure: The target is cursed. If the cursed target drops to 0 Hit Points, it instead becomes a Weretiger under the GM’s control and has 10 Hit Points. Success: The target is immune to this weretiger’s curse for 24 hours."
  - name: "Scratch"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 10 (2d6 + 3) Slashing damage."
  - name: "Longbow (Humanoid or Hybrid Form Only)"
    desc: "Ranged Attack Roll: +4, range 150/600 ft. Hit: 11 (2d8 + 2) Piercing damage."
bonusactions:
  - name: "Prowl (Tiger or Hybrid Form Only)"
    desc: "The weretiger moves up to its Speed without provoking Opportunity Attacks. At the end of this movement, the weretiger can take the Hide action."
  - name: "Shape-Shift"
    desc: "The weretiger shape-shifts into a Large tiger-humanoid hybrid or a Large tiger, or it returns to its true humanoid form. Its game statistics, other than its size, are the same in each form. Any equipment it is wearing or carrying isn’t transformed."
```

#Monster
