---
Type: Undead
CR: 1/4
Size: Medium
tags:
  - Monster
  - Undead
source: SRD 5.2.1
---

```statblock
name: Zombie
size: Medium
type: Undead
alignment: Neutral Evil
ac: 8
hp: 15 (2d8 + 6)
hit_dice: 2d8 + 6
speed: 20 ft.
stats: [13, 6, 16, 3, 6, 5]
saves:
  - Wis: +0
damage_immunities: Poison
condition_immunities: Exhaustion, Poisoned
senses: Darkvision 60 ft.; Passive Perception 8
languages: Understands Common plus one other language but can’t speak
cr: 1/4
traits:
  - name: "Undead Fortitude"
    desc: "If damage reduces the zombie to 0 Hit Points, it makes a Constitution saving throw (DC 5 plus the damage taken) unless the damage is Radiant or from a Critical Hit. On a successful save, the zombie drops to 1 Hit Point instead."
actions:
  - name: "Slam"
    desc: "Melee Attack Roll: +3, reach 5 ft. Hit: 5 (1d8 + 1) Bludgeoning damage."
```

#Monster
