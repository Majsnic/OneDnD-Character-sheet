---
tags:
  - Feat
source: SRD 5.2.1
---

# Boon of Spell Recall

**Type:** Epic Boon Feat
**Prerequisite:** Character level 19
**Repeatable:** No

A number of times equal to your proficiency bonus, you can use a bonus action to regain one expended spell slot of 5th level or lower. You regain all expended uses of this boon after finishing a long rest.

*Paraphrased mechanical summary, written from general knowledge of the SRD rules — treat it as a helpful draft, not a verbatim rules quote.*

#Feat
