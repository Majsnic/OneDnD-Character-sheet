---
type: object
tags:
  - Item
  - item/common
  - item/weapon
item_category: Weapon
weapon_category: "Martial Melee"
damage_dice: "2d6"
damage_type: Bludgeoning
weapon_properties: [Heavy, Two-Handed]
weapon_mastery: Topple
attack_bonus: 0
damage_bonus: 0
cost: "10 GP"
weight_lb: 10
---


###### Maul
_Martial Melee Weapon_
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>**2d6 Bludgeoning damage.** Properties: Heavy, Two-Handed. Cost 10 GP, weight 10 lb.
>
>- **Heavy.** Small creatures have Disadvantage on attack rolls with this weapon.
>- **Two-Handed.** You must use two hands to attack with this weapon.
>
>**_Topple (Mastery)._** If you hit a creature with this weapon, you can force that creature to make a Constitution saving throw (DC 8 + your proficiency bonus + the ability modifier used for the attack). On a failed save, the creature is knocked Prone.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
