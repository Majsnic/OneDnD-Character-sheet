---
Type: Humanoid
CR: 1/8
Size: Medium or Small
tags:
  - Monster
  - Humanoid
source: SRD 5.2.1
---

```statblock
name: Cultist
size: Medium or Small
type: Humanoid
alignment: Neutral
ac: 12
hp: 9 (2d8)
hit_dice: 2d8
speed: 30 ft.
stats: [11, 12, 10, 10, 11, 10]
saves:
  - Wis: +2
skillsaves:
  - Deception: +2
  - Religion: +2
gear: Leather Armor, Sickle
senses: Passive Perception 10
languages: Common
cr: 1/8
actions:
  - name: "Ritual Sickle"
    desc: "Melee Attack Roll: +3, reach 5 ft. Hit: 3 (1d4 + 1) Slashing damage plus 1 Necrotic damage."
```

#Monster
