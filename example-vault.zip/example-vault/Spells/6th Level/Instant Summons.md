---
Spell level: 6
School type: Conjuration
Casting Time: 1 minute or Ritual
Components:
  - Verbal
  - Somatic
  - Material
Concentration: false
Duration: Until dispelled
Range / Area: Touch
Attack / Save: None
Damage / Effect: Utility
Upscale: 
category: 6th level
---
_Level 6 Conjuration_

- **Casting time:** 1 minute or Ritual
- **Range:** Touch
- **Components:** V, S, M
- **Duration:** Until dispelled
- **Attack/Save**: None
- **Damage/Effect**: Utility

You touch the sapphire used in the casting and an object weighing 10 pounds or less whose longest dimension is 6 feet or less. The spell leaves an Invisible mark on that object and invisibly inscribes the object’s name on the sapphire. Each time you cast this spell, you must use a different sapphire. Thereafter, you can take a Magic action to speak the object’s name and crush the sapphire. The object instantly appears in your hand regardless of physical or planar distances, and the spell ends. If another creature is holding or carrying the object, crushing the sapphire doesn’t transport it, but instead you learn who that creature is and where that creature is currently located.

#Spell
