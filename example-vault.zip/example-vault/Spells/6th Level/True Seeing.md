---
Spell level: 6
School type: Divination
Casting Time: Action
Components:
  - Verbal
  - Somatic
  - Material
Concentration: false
Duration: 1 hour
Range / Area: Touch
Attack / Save: None
Damage / Effect: Utility
Upscale: 
category: 6th level
---
_Level 6 Divination_

- **Casting time:** Action
- **Range:** Touch
- **Components:** V, S, M
- **Duration:** 1 hour
- **Attack/Save**: None
- **Damage/Effect**: Utility

For the duration, the willing creature you touch has Truesight with a range of 120 feet.

#Spell
