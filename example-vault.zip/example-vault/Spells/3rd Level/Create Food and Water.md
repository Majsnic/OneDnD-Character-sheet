---
Spell level: 3
School type: Conjuration
Casting Time: Action
Components:
  - Verbal
  - Somatic
Concentration: false
Duration: Instantaneous
Range / Area: 30 feet
Attack / Save: None
Damage / Effect: Utility
Upscale: 
category: 3rd level
---
_Level 3 Conjuration_

- **Casting time:** Action
- **Range:** 30 feet
- **Components:** V, S
- **Duration:** Instantaneous
- **Attack/Save**: None
- **Damage/Effect**: Utility

You create 45 pounds of food and 30 gallons of fresh water on the ground or in containers within range—both useful in fending off the hazards of malnutrition and dehydration. The food is bland but nourishing and looks like a food of your choice, and the water is clean. The food spoils after 24 hours if uneaten.

#Spell
