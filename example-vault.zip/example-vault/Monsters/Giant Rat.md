---
Type: Beast
CR: 1/8
Size: Small
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Giant Rat
size: Small
type: Beast
alignment: Unaligned
ac: 13
hp: 7 (2d6)
hit_dice: 2d6
speed: 30 ft., Climb 30 ft.
stats: [7, 16, 11, 2, 10, 4]
saves:
  - Dex: +5
skillsaves:
  - Perception: +2
senses: Darkvision 60 ft.; Passive Perception 12
languages: None
cr: 1/8
traits:
  - name: "Pack Tactics"
    desc: "The rat has Advantage on an attack roll against a creature if at least one of the rat’s allies is within 5 feet of the creature and the ally doesn’t have the Incapacitated condition."
actions:
  - name: "Bite"
    desc: "Melee Attack Roll: +5, reach 5 feet. Hit: 5 (1d4 + 3) Piercing damage."
```

#Monster
