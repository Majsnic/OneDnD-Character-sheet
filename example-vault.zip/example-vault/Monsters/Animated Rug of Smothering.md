---
Type: Construct
CR: 2
Size: Large
tags:
  - Monster
  - Construct
source: SRD 5.2.1
---

```statblock
name: Animated Rug of Smothering
size: Large
type: Construct
alignment: Unaligned
ac: 12
hp: 27 (5d10)
hit_dice: 5d10
speed: 10 ft.
stats: [17, 14, 10, 1, 3, 1]
damage_immunities: Poison, Psychic
condition_immunities: Charmed, Deafened, Exhaustion, Frightened, Paralyzed, Petrified, Poisoned
senses: Blindsight 60 ft.; Passive Perception 6
languages: None
cr: 2
actions:
  - name: "Smother"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 10 (2d6 + 3) Bludgeoning damage. If the target is a Medium or smaller creature, the rug can give it the Grappled condition (escape DC 13) instead of dealing damage. Until the grapple ends, the target has the Blinded and Restrained conditions, is suffocating, and takes 10 (2d6 + 3) Bludgeoning damage at the start of each of its turns. The rug can smother only one creature at a time. While grappling the target, the rug can’t take this action, the rug halves the damage it takes (round down), and the target takes the same amount of damage."
```

#Monster
