---
Spell level: 1
School type: Evocation
Casting Time: Action
Components:
  - Verbal
  - Somatic
Concentration: false
Duration: Instantaneous
Range / Area: 120 feet
Attack / Save: Auto-hit
Damage / Effect: 1d4+1 Force
Upscale: + 1 dart
category: 1st level
---
_Level 1 Evocation_

- **Casting time:** Action
- **Range:** 120 feet
- **Components:** V, S
- **Duration:** Instantaneous
- **Attack/Save**: Auto-hit
- **Damage/Effect**: Force

You create three glowing darts of magical force. Each dart strikes a creature of your choice that you can see within range. A dart deals 1d4 + 1 Force damage to its target. The darts all strike simultaneously, and you can direct them to hit one creature or several.

**_Using a Higher-Level Spell Slot._** The spell creates one more dart for each spell slot level above 1.

#Spell
