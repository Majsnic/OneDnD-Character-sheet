---
Spell level: 3
School type: Conjuration
Casting Time: Action
Components:
  - Verbal
  - Somatic
Concentration: true
Duration: 10 minutes
Range / Area: 60 feet
Attack / Save: DEX Save
Damage / Effect: 3d10 Slashing
Upscale: + 1d10
category: 3rd level
---
_Level 3 Conjuration_

- **Casting time:** Action
- **Range:** 60 feet
- **Components:** V, S
- **Duration:** 10 minutes
- **Attack/Save**: DEX Save
- **Damage/Effect**: Slashing

You conjure nature spirits that appear as a Large pack of spectral, intangible animals in an unoccupied space you can see within range. The pack lasts for the duration, and you choose the spirits’ animal form, such as wolves, serpents, or birds. You have Advantage on Strength saving throws while you’re within 5 feet of the pack, and when you move on your turn, you can also move the pack up to 30 feet to an unoccupied space you can see. Whenever the pack moves within 10 feet of a creature you can see and whenever a creature you can see enters a space within 10 feet of the pack or ends its turn there, you can force that creature to make a Dexterity saving throw. On a failed save, the creature takes 3d10 Slashing damage. A creature makes this save only once per turn.

**_Using a Higher-Level Spell Slot._** The damage increases by 1d10 for each spell slot level above 3.

#Spell
