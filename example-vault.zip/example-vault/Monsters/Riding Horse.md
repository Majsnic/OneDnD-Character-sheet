---
Type: Beast
CR: 1/4
Size: Large
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Riding Horse
size: Large
type: Beast
alignment: Unaligned
ac: 11
hp: 13 (2d10 + 2)
hit_dice: 2d10 + 2
speed: 60 ft.
stats: [16, 13, 12, 2, 11, 7]
senses: Passive Perception 10
languages: None
cr: 1/4
actions:
  - name: "Hooves"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 7 (1d8 + 3) Bludgeoning damage."
```

#Monster
