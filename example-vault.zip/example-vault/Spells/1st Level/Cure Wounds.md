---
Spell level: 1
School type: Abjuration
Casting Time: Action
Components:
  - Verbal
  - Somatic
Concentration: false
Duration: Instantaneous
Range / Area: Touch
Attack / Save: None
Damage / Effect: 2d8 Healing + spellcasting ability modifier
Upscale: + 2d8
category: 1st level
---
_Level 1 Abjuration_

- **Casting time:** Action
- **Range:** Touch
- **Components:** V, S
- **Duration:** Instantaneous
- **Attack/Save**: None
- **Damage/Effect**: Healing

A creature you touch regains a number of Hit Points equal to 2d8 plus your spellcasting ability modifier.

**_Using a Higher-Level Spell Slot._** The healing increases by 2d8 for each spell slot level above 1.

#Spell
