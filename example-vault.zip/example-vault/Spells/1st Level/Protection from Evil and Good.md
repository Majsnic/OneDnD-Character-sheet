---
Spell level: 1
School type: Abjuration
Casting Time: Action
Components:
  - Verbal
  - Somatic
  - Material
Concentration: false
Duration: Concentration up to 10 minutes
Range / Area: Touch
Attack / Save: None
Damage / Effect: Frightened
Upscale: 
category: 1st level
---
_Level 1 Abjuration_

- **Casting time:** Action
- **Range:** Touch
- **Components:** V, S, M
- **Duration:** Concentration up to 10 minutes
- **Attack/Save**: None
- **Damage/Effect**: Frightened

Until the spell ends, one willing creature you touch is protected against creatures that are Aberrations, Celestials, Elementals, Fey, Fiends, or Undead. The protection grants several benefits. Creatures of those types have Disadvantage on attack rolls against the target. The target also can’t be possessed by or gain the Charmed or Frightened conditions from them. If the target is already possessed, Charmed, or Frightened by such a creature, the target has Advantage on any new saving throw against the relevant effect.

#Spell
