---
Type: Beast
CR: 0
Size: Tiny
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Hawk
size: Tiny
type: Beast
alignment: Unaligned
ac: 13
hp: 1 (1d4 - 1)
hit_dice: 1d4 - 1
speed: 10 ft., Fly 60 ft.
stats: [5, 16, 8, 2, 14, 6]
skillsaves:
  - Perception: +6
senses: Passive Perception 16
languages: None
cr: 0
actions:
  - name: "Talons"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 1 Slashing damage."
```

#Monster
