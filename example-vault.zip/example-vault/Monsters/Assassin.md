---
Type: Humanoid
CR: 8
Size: Medium or Small
tags:
  - Monster
  - Humanoid
source: SRD 5.2.1
---

```statblock
name: Assassin
size: Medium or Small
type: Humanoid
alignment: Neutral
ac: 16
hp: 97 (15d8 + 30)
hit_dice: 15d8 + 30
speed: 30 ft.
stats: [11, 18, 14, 16, 11, 10]
saves:
  - Dex: +7
  - Int: +6
skillsaves:
  - Acrobatics: +7
  - Perception: +6
  - Stealth: +10
damage_resistances: Poison
gear: Light Crossbow, Shortsword, Studded Leather Armor
senses: Passive Perception 16
languages: Common, Thieves’ Cant
cr: 8
traits:
  - name: "Evasion"
    desc: "If the assassin is subjected to an effect that allows it to make a Dexterity saving throw to take only half damage, the assassin instead takes no damage if it succeeds on the save and only half damage if it fails. It can’t use this trait if it has the Incapacitated condition."
actions:
  - name: "Multiattack"
    desc: "The assassin makes three attacks, using Shortsword or Light Crossbow in any combination."
  - name: "Shortsword"
    desc: "Melee Attack Roll: +7, reach 5 ft. Hit: 7 (1d6 + 4) Piercing damage plus 17 (5d6) Poison damage, and the target has the Poisoned condition until the start of the assassin’s next turn."
  - name: "Light Crossbow"
    desc: "Ranged Attack Roll: +7, range 80/320 ft. Hit: 8 (1d8 + 4) Piercing damage plus 21 (6d6) Poison damage."
bonusactions:
  - name: "Cunning Action"
    desc: "The assassin takes the Dash, Disengage, or Hide action."
```

#Monster
