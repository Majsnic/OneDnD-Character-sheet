---
Type: Humanoid
CR: 2
Size: Medium or Small
tags:
  - Monster
  - Humanoid
source: SRD 5.2.1
---

```statblock
name: Priest
size: Medium or Small
type: Humanoid (Cleric)
alignment: Neutral
ac: 13
hp: 38 (7d8 + 7)
hit_dice: 7d8 + 7
speed: 30 ft.
stats: [16, 10, 12, 13, 16, 13]
skillsaves:
  - Medicine: +7
  - Perception: +5
  - Religion: +5
gear: Chain Shirt, Holy Symbol, Mace
senses: Passive Perception 15
languages: Common plus one other language
cr: 2
actions:
  - name: "Multiattack"
    desc: "The priest makes two attacks, using Mace or Radiant Flame in any combination."
  - name: "Mace"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 6 (1d6 + 3) Bludgeoning damage plus 5 (2d4) Radiant damage."
  - name: "Radiant Flame"
    desc: "Ranged Attack Roll: +5, range 60 ft. Hit: 11 (2d10) Radiant damage."
  - name: "Spellcasting"
    desc: "The priest casts one of the following spells, using Wisdom as the spellcasting ability (spell save DC 13): At Will: Light, Thaumaturgy 1/Day: Spirit Guardians"
bonusactions:
  - name: "Divine Aid (3/Day)"
    desc: "The priest casts Bless, Dispel Magic, Healing Word, or Lesser Restoration, using the same spellcasting ability as Spellcasting."
```

#Monster
