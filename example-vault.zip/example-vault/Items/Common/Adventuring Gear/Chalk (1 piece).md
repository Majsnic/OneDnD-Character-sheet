---
type: object
tags:
  - Item
  - item/common
  - item/gear
item_category: "Adventuring Gear"
cost: "1 CP"
---


###### Chalk (1 piece)
_Adventuring Gear_
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>A small piece of chalk, useful for marking walls, floors, or objects. Cost 1 CP, negligible weight.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
