---
Type: Beast
CR: 1
Size: Large
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Brown Bear
size: Large
type: Beast
alignment: Unaligned
ac: 11
hp: 22 (3d10 + 6)
hit_dice: 3d10 + 6
speed: 40 ft., Climb 30 ft.
stats: [17, 12, 15, 2, 13, 7]
skillsaves:
  - Perception: +3
senses: Darkvision 60 ft.; Passive Perception 13
languages: None
cr: 1
actions:
  - name: "Multiattack"
    desc: "The bear makes one Bite attack and one Claw attack."
  - name: "Bite"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 7 (1d8 + 3) Piercing damage."
  - name: "Claw"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 5 (1d4 + 3) Slashing damage. If the target is a Large or smaller creature, it has the Prone condition."
```

#Monster
