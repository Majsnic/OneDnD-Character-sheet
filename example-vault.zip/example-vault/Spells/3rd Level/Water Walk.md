---
Spell level: 3
School type: Transmutation
Casting Time: Action or Ritual
Components:
  - Verbal
  - Somatic
  - Material
Concentration: false
Duration: 1 hour
Range / Area: 30 feet
Attack / Save: None
Damage / Effect: Utility
Upscale: 
category: 3rd level
---
_Level 3 Transmutation_

- **Casting time:** Action or Ritual
- **Range:** 30 feet
- **Components:** V, S, M
- **Duration:** 1 hour
- **Attack/Save**: None
- **Damage/Effect**: Utility

This spell grants the ability to move across any liquid surface—such as water, acid, mud, snow, quicksand, or lava—as if it were harmless solid ground (creatures crossing molten lava can still take damage from the heat). Up to ten willing creatures of your choice within range gain this ability for the duration. An affected target must take a Bonus Action to pass from the liquid’s surface into the liquid itself and vice versa, but if the target falls into the liquid, the target passes through the surface into the liquid below.

#Spell
