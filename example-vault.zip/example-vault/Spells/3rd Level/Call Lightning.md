---
Spell level: 3
School type: Conjuration
Casting Time: Action
Components:
  - Verbal
  - Somatic
Concentration: true
Duration: 10 minutes
Range / Area: 120 feet
Attack / Save: DEX Save
Damage / Effect: 3d10 Lightning
Upscale: + 1d10
category: 3rd level
---
_Level 3 Conjuration_

- **Casting time:** Action
- **Range:** 120 feet
- **Components:** V, S
- **Duration:** 10 minutes
- **Attack/Save**: DEX Save
- **Damage/Effect**: Lightning

A storm cloud appears at a point within range that you can see above yourself. It takes the shape of a Cylinder that is 10 feet tall with a 60-foot radius. When you cast the spell, choose a point you can see under the cloud. A lightning bolt shoots from the cloud to that point. Each creature within 5 feet of that point makes a Dexterity saving throw, taking 3d10 Lightning damage on a failed save or half as much damage on a successful one. Until the spell ends, you can take a Magic action to call down lightning in that way again, targeting the same point or a different one. If you’re outdoors in a storm when you cast this spell, the spell gives you control over that storm instead of creating a new one. Under such conditions, the spell’s damage increases by 1d10.

**_Using a Higher-Level Spell Slot._** The damage increases by 1d10 for each spell slot level above 3.

#Spell
