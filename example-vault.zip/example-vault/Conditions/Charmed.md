---
tags:
  - Condition
source: SRD 5.2.1
---

# Charmed

You can't attack the charmer or target it with harmful abilities or magical effects. The charmer has advantage on any ability check it makes to interact socially with you.

*Paraphrased mechanical summary, written from general knowledge of the SRD rules — treat it as a helpful draft, not a verbatim rules quote.*

#Condition
