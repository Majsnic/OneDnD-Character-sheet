---
Spell level: 4
School type: Conjuration
Casting Time: Action
Components:
  - Verbal
  - Somatic
  - Material
Concentration: false
Duration: 8 hours
Range / Area: 30 feet
Attack / Save: DEX Save
Damage / Effect: 4d8 Force
Upscale: 
category: 4th level
---
_Level 4 Conjuration_

- **Casting time:** Action
- **Range:** 30 feet
- **Components:** V, S, M
- **Duration:** 8 hours
- **Attack/Save**: DEX Save
- **Damage/Effect**: Force

You conjure a phantom watchdog in an unoccupied space that you can see within range. The hound remains for the duration or until the two of you are more than 300 feet apart from each other. No one but you can see the hound, and it is intangible and invulnerable. When a Small or larger creature comes within 30 feet of it without first speaking the password that you specify when you cast this spell, the hound starts barking loudly. The hound has Truesight with a range of 30 feet. At the start of each of your turns, the hound attempts to bite one enemy within 5 feet of it. That enemy must succeed on a Dexterity saving throw or take 4d8 Force damage. On your later turns, you can take a Magic action to move the hound up to 30 feet.

#Spell
