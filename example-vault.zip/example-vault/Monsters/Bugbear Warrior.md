---
Type: Fey
CR: 1
Size: Medium
tags:
  - Monster
  - Fey
source: SRD 5.2.1
---

```statblock
name: Bugbear Warrior
size: Medium
type: Fey (Goblinoid)
alignment: Chaotic Evil
ac: 14
hp: 33 (6d8 + 6)
hit_dice: 6d8 + 6
speed: 30 ft.
stats: [15, 14, 13, 8, 11, 9]
skillsaves:
  - Stealth: +6
  - Survival: +2
gear: Hide Armor, Light Hammers (3)
senses: Darkvision 60 ft.; Passive Perception 10
languages: Common, Goblin
cr: 1
traits:
  - name: "Abduct"
    desc: "The bugbear needn’t spend extra movement to move a creature it is grappling."
actions:
  - name: "Grab"
    desc: "Melee Attack Roll: +4, reach 10 ft. Hit: 9 (2d6 + 2) Bludgeoning damage. If the target is a Medium or smaller creature, it has the Grappled condition (escape DC 12)."
  - name: "Light Hammer"
    desc: "Melee or Ranged Attack Roll: +4 (with Advantage if the target is Grappled by the bugbear), reach 10 ft. or range 20/60 ft. Hit: 9 (3d4 + 2) Bludgeoning damage."
```

#Monster
