---
Spell level: 1
School type: Evocation
Casting Time: Action
Components:
  - Verbal
  - Somatic
Concentration: false
Duration: 1 round
Range / Area: 120 feet
Attack / Save: Ranged
Damage / Effect: 4d6 Radiant
Upscale: + 1d6
category: 1st level
---
_Level 1 Evocation_

- **Casting time:** Action
- **Range:** 120 feet
- **Components:** V, S
- **Duration:** 1 round
- **Attack/Save**: Ranged
- **Damage/Effect**: Radiant

You hurl a bolt of light toward a creature within range. Make a ranged spell attack against the target. On a hit, it takes 4d6 Radiant damage, and the next attack roll made against it before the end of your next turn has Advantage.

**_Using a Higher-Level Spell Slot._** The damage increases by 1d6 for each spell slot level above 1.

#Spell
