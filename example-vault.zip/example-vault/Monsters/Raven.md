---
Type: Beast
CR: 0
Size: Tiny
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Raven
size: Tiny
type: Beast
alignment: Unaligned
ac: 12
hp: 2 (1d4)
hit_dice: 1d4
speed: 10 ft., Fly 50 ft.
stats: [2, 14, 10, 5, 13, 6]
skillsaves:
  - Perception: +3
senses: Passive Perception 13
languages: None
cr: 0
traits:
  - name: "Mimicry"
    desc: "The raven can mimic simple sounds it has heard, such as a whisper or chitter. A hearer can discern the sounds are imitations with a successful DC 10 Wisdom (Insight) check."
actions:
  - name: "Beak"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 1 Piercing damage."
```

#Monster
