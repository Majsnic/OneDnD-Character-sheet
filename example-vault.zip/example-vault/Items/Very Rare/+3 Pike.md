---
Rarity: Very Rare
type: object
tags:
  - Item
  - item/very-rare
  - item/weapon
item_category: Weapon
item_base: "Pike"
weapon_category: "Martial Melee"
damage_dice: "1d10"
damage_type: Piercing
weapon_properties: [Heavy, Reach, Two-Handed]
weapon_mastery: Push
requires_attunement: false
attunement_note: ""
attack_bonus: 3
damage_bonus: 3
---


###### +3 Pike
_Weapon (pike), very rare_<span class="sub2">:FasWandMagicSparkles: Magic Item</span>
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>You have a +3 bonus to attack and damage rolls made with this magic weapon.
>
>**1d10+3 Piercing damage.** Properties: Heavy, Reach, Two-Handed.
>
>- **Heavy.** Small creatures have Disadvantage on attack rolls with this weapon.
>- **Reach.** This weapon adds 5 feet to your reach when you attack with it.
>- **Two-Handed.** You must use two hands to attack with this weapon.
>
>**_Push (Mastery)._** If you hit a creature with this weapon and deal damage to it, you can push the creature up to 10 feet straight away from yourself if it is Large or smaller.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
