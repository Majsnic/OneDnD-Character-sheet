---
Type: Dragon
CR: 10
Size: Large
tags:
  - Monster
  - Dragon
source: SRD 5.2.1
---

```statblock
name: Young Red Dragon
size: Large
type: Dragon (Chromatic)
alignment: Chaotic Evil
ac: 18
hp: 178 (17d10 + 85)
hit_dice: 17d10 + 85
speed: 40 ft., Climb 40 ft., Fly 80 ft.
stats: [23, 10, 21, 14, 11, 19]
saves:
  - Dex: +4
  - Wis: +4
skillsaves:
  - Perception: +8
  - Stealth: +4
damage_immunities: Fire
senses: Blindsight 30 ft., Darkvision 120 ft.; Passive Perception 18
languages: Common, Draconic
cr: 10
actions:
  - name: "Multiattack"
    desc: "The dragon makes three Rend attacks."
  - name: "Rend"
    desc: "Melee Attack Roll: +10, reach 10 ft. Hit: 13 (2d6 + 6) Slashing damage plus 3 (1d6) Fire damage."
  - name: "Fire Breath (Recharge 5–6)"
    desc: "Dexterity Saving Throw: DC 17, each creature in a 30-foot Cone. Failure: 56 (16d6) Fire damage. Success: Half damage."
```

#Monster
