---
type: object
tags:
  - Item
  - item/common
  - item/weapon
item_category: Weapon
weapon_category: "Martial Melee"
damage_dice: "1d10"
damage_type: Piercing
weapon_properties: [Heavy, Reach, Two-Handed]
weapon_mastery: Push
attack_bonus: 0
damage_bonus: 0
cost: "5 GP"
weight_lb: 18
---


###### Pike
_Martial Melee Weapon_
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>**1d10 Piercing damage.** Properties: Heavy, Reach, Two-Handed. Cost 5 GP, weight 18 lb.
>
>- **Heavy.** Small creatures have Disadvantage on attack rolls with this weapon.
>- **Reach.** This weapon adds 5 feet to your reach when you attack with it.
>- **Two-Handed.** You must use two hands to attack with this weapon.
>
>**_Push (Mastery)._** If you hit a creature with this weapon, you can push that creature up to 10 feet straight away from yourself if it's Large or smaller.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
