---
Type: Fiend
CR: 9
Size: Large
tags:
  - Monster
  - Fiend
source: SRD 5.2.1
---

```statblock
name: Glabrezu
size: Large
type: Fiend (Demon)
alignment: Chaotic Evil
ac: 17
hp: 189 (18d10 + 90)
hit_dice: 18d10 + 90
speed: 40 ft.
stats: [20, 15, 21, 19, 17, 16]
saves:
  - Str: +9
  - Con: +9
  - Wis: +7
  - Cha: +7
skillsaves:
  - Deception: +7
  - Perception: +7
damage_resistances: Cold, Fire, Lightning
damage_immunities: Poison
condition_immunities: Poisoned
senses: Truesight 120 ft.; Passive Perception 17
languages: Abyssal; telepathy 120 ft.
cr: 9
traits:
  - name: "Demonic Restoration"
    desc: "If the glabrezu dies outside the Abyss, its body dissolves into ichor, and it gains a new body instantly, reviving with all its Hit Points somewhere in the Abyss."
  - name: "Magic Resistance"
    desc: "The glabrezu has Advantage on saving throws against spells and other magical effects."
actions:
  - name: "Multiattack"
    desc: "The glabrezu makes two Pincer attacks and uses Pummel or Spellcasting."
  - name: "Pincer"
    desc: "Melee Attack Roll: +9, reach 10 ft. Hit: 16 (2d10 + 5) Slashing damage. If the target is a Medium or smaller creature, it has the Grappled condition (escape DC 15) from one of two pincers."
  - name: "Pummel"
    desc: "Dexterity Saving Throw: DC 17, one creature Grappled by the glabrezu. Failure: 15 (3d6 + 5) Bludgeoning damage. Success: Half damage."
  - name: "Spellcasting"
    desc: "The glabrezu casts one of the following spells, requiring no Material components and using Intelligence as the spellcasting ability (spell save DC 16): At Will: Darkness, Detect Magic, Dispel Magic 1/Day Each: Confusion, Fly, Power Word Stun"
```

#Monster
