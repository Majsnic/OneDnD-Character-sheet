---
Spell level: 1
School type: Transmutation
Casting Time: Bonus Action
Components:
  - Verbal
  - Somatic
Concentration: true
Duration: 10 minutes
Range / Area: Self
Attack / Save: None
Damage / Effect: Utility
Upscale: 
category: 1st level
---
_Level 1 Transmutation_

- **Casting time:** Bonus Action
- **Range:** Self
- **Components:** V, S
- **Duration:** 10 minutes
- **Attack/Save**: None
- **Damage/Effect**: Utility

You take the Dash action, and until the spell ends, you can take that action again as a Bonus Action.

#Spell
