---
Spell level: 3
School type: Transmutation
Casting Time: Action
Components:
  - Verbal
  - Somatic
Concentration: false
Duration: 10 minutes
Range / Area: Self
Attack / Save: None
Damage / Effect: Utility
Upscale: 
category: 3rd level
---
_Level 3 Transmutation_

- **Casting time:** Action
- **Range:** Self
- **Components:** V, S
- **Duration:** 10 minutes
- **Attack/Save**: None
- **Damage/Effect**: Utility

You imbue plants in an immobile 30-foot Emanation with limited sentience and animation, giving them the ability to communicate with you and follow your simple commands. You can question plants about events in the spell’s area within the past day, gaining information about creatures that have passed, weather, and other circumstances. You can also turn Difficult Terrain caused by plant growth (such as thickets and undergrowth) into ordinary terrain that lasts for the duration. Or you can turn ordinary terrain where plants are present into Difficult Terrain that lasts for the duration. The spell doesn’t enable plants to uproot themselves and move about, but they can move their branches, tendrils, and stalks for you. If a Plant creature is in the area, you can communicate with it as if you shared a common language.

#Spell
