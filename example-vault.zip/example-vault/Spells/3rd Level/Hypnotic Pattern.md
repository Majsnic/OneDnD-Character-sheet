---
Spell level: 3
School type: Illusion
Casting Time: Action
Components:
  - Somatic
  - Material
Concentration: true
Duration: 1 minute
Range / Area: 120 feet
Attack / Save: WIS Save
Damage / Effect: Charmed
Upscale: 
category: 3rd level
---
_Level 3 Illusion_

- **Casting time:** Action
- **Range:** 120 feet
- **Components:** S, M
- **Duration:** 1 minute
- **Attack/Save**: WIS Save
- **Damage/Effect**: Charmed

You create a twisting pattern of colors in a 30-foot Cube within range. The pattern appears for a moment and vanishes. Each creature in the area who can see the pattern must succeed on a Wisdom saving throw or have the Charmed condition for the duration. While Charmed, the creature has the Incapacitated condition and a Speed of 0. The spell ends for an affected creature if it takes any damage or if someone else uses an action to shake the creature out of its stupor.

#Spell
