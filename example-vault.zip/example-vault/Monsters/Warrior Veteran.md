---
Type: Humanoid
CR: 3
Size: Medium or Small
tags:
  - Monster
  - Humanoid
source: SRD 5.2.1
---

```statblock
name: Warrior Veteran
size: Medium or Small
type: Humanoid
alignment: Neutral
ac: 17
hp: 65 (10d8 + 20)
hit_dice: 10d8 + 20
speed: 30 ft.
stats: [16, 13, 14, 10, 11, 10]
skillsaves:
  - Athletics: +5
  - Perception: +2
gear: Greatsword, Heavy Crossbow, Splint Armor
senses: Passive Perception 12
languages: Common plus one other language
cr: 3
actions:
  - name: "Multiattack"
    desc: "The warrior makes two Greatsword or Heavy Crossbow attacks."
  - name: "Greatsword"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 10 (2d6 + 3) Slashing damage."
  - name: "Heavy Crossbow"
    desc: "Ranged Attack Roll: +3, range 100/400 ft. Hit: 12 (2d10 + 1) Piercing damage."
reactions:
  - name: "Parry"
    desc: "Trigger: The warrior is hit by a melee attack roll while holding a weapon. Response: The warrior adds 2 to its AC against that attack, possibly causing it to miss."
```

#Monster
