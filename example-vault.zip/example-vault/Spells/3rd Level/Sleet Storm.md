---
Spell level: 3
School type: Conjuration
Casting Time: Action
Components:
  - Verbal
  - Somatic
  - Material
Concentration: true
Duration: 1 minute
Range / Area: 150 feet
Attack / Save: DEX Save
Damage / Effect: Prone
Upscale: 
category: 3rd level
---
_Level 3 Conjuration_

- **Casting time:** Action
- **Range:** 150 feet
- **Components:** V, S, M
- **Duration:** 1 minute
- **Attack/Save**: DEX Save
- **Damage/Effect**: Prone

Until the spell ends, sleet falls in a 40-foot-tall, 20-foot-radius Cylinder centered on a point you choose within range. The area is Heavily Obscured, and exposed flames in the area are doused. Ground in the Cylinder is Difficult Terrain. When a creature enters the Cylinder for the first time on a turn or starts its turn there, it must succeed on a Dexterity saving throw or have the Prone condition and lose Concentration.

#Spell
