---
Type: Undead
CR: 2
Size: Large
tags:
  - Monster
  - Undead
source: SRD 5.2.1
---

```statblock
name: Ogre Zombie
size: Large
type: Undead
alignment: Neutral Evil
ac: 8
hp: 85 (9d10 + 36)
hit_dice: 9d10 + 36
speed: 30 ft.
stats: [19, 6, 18, 3, 6, 5]
saves:
  - Wis: +0
damage_immunities: Poison
condition_immunities: Exhaustion, Poisoned
senses: Darkvision 60 ft.; Passive Perception 8
languages: Understands Common and Giant but can’t speak
cr: 2
traits:
  - name: "Undead Fortitude"
    desc: "If damage reduces the zombie to 0 Hit Points, it makes a Constitution saving throw (DC 5 plus the damage taken) unless the damage is Radiant or from a Critical Hit. On a successful save, the zombie drops to 1 Hit Point instead."
actions:
  - name: "Slam"
    desc: "Melee Attack Roll: +6, reach 5 ft. Hit: 13 (2d8 + 4) Bludgeoning damage."
```

#Monster
