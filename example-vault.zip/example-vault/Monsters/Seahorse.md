---
Type: Beast
CR: 0
Size: Tiny
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Seahorse
size: Tiny
type: Beast
alignment: Unaligned
ac: 12
hp: 1 (1d4 - 1)
hit_dice: 1d4 - 1
speed: 5 ft., Swim 20 ft.
stats: [1, 12, 8, 1, 10, 2]
skillsaves:
  - Perception: +2
  - Stealth: +5
senses: Passive Perception 12
languages: None
cr: 0
traits:
  - name: "Water Breathing"
    desc: "The seahorse can breathe only underwater."
actions:
  - name: "Bubble Dash"
    desc: "While underwater, the seahorse moves up to its Swim Speed without provoking Opportunity Attacks."
```

#Monster
