---
Spell level: 1
School type: Conjuration
Casting Time: Action
Components:
  - Somatic
  - Material
Concentration: false
Duration: Instantaneous
Range / Area: 60 feet
Attack / Save: Ranged
Damage / Effect: 1d10 Piercing
Upscale: + 1d6
category: 1st level
---
_Level 1 Conjuration_

- **Casting time:** Action
- **Range:** 60 feet
- **Components:** S, M
- **Duration:** Instantaneous
- **Attack/Save**: Ranged
- **Damage/Effect**: Piercing

You create a shard of ice and fling it at one creature within range. Make a ranged spell attack against the target. On a hit, the target takes 1d10 Piercing damage. Hit or miss, the shard then explodes. The target and each creature within 5 feet of it must succeed on a Dexterity saving throw or take 2d6 Cold damage.

**_Using a Higher-Level Spell Slot._** The Cold damage increases by 1d6 for each spell slot level above 1.

#Spell
