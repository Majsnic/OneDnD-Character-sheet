---
tags:
  - Condition
source: SRD 5.2.1
---

# Restrained

Your speed becomes 0. Attack rolls against you have advantage, and your own attack rolls have disadvantage. You have disadvantage on Dexterity saving throws.

*Paraphrased mechanical summary, written from general knowledge of the SRD rules — treat it as a helpful draft, not a verbatim rules quote.*

#Condition
