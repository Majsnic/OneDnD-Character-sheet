---
Type: Construct
CR: 1/4
Size: Small
tags:
  - Monster
  - Construct
source: SRD 5.2.1
---

```statblock
name: Animated Flying Sword
size: Small
type: Construct
alignment: Unaligned
ac: 17
hp: 14 (4d6)
hit_dice: 4d6
speed: 5 ft., Fly 50 ft. (hover)
stats: [12, 15, 11, 1, 5, 1]
saves:
  - Dex: +4
damage_immunities: Poison, Psychic
condition_immunities: Charmed, Deafened, Exhaustion, Frightened, Paralyzed, Petrified, Poisoned
senses: Blindsight 60 ft.; Passive Perception 7
languages: None
cr: 1/4
actions:
  - name: "Slash"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 6 (1d8 + 2) Slashing damage."
```

#Monster
