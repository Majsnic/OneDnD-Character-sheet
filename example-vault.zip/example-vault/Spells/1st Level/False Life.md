---
Spell level: 1
School type: Necromancy
Casting Time: Action
Components:
  - Verbal
  - Somatic
  - Material
Concentration: false
Duration: Instantaneous
Range / Area: Self
Attack / Save: None
Damage / Effect: Temporary Hit Points
Upscale: 
category: 1st level
---
_Level 1 Necromancy_

- **Casting time:** Action
- **Range:** Self
- **Components:** V, S, M
- **Duration:** Instantaneous
- **Attack/Save**: None
- **Damage/Effect**: Temporary Hit Points

You gain 2d4 + 4 Temporary Hit Points.

**_Using a Higher-Level Spell Slot._** You gain 5 additional Temporary Hit Points for each spell slot level above 1.

#Spell
