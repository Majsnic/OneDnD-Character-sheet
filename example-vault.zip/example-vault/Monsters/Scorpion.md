---
Type: Beast
CR: 0
Size: Tiny
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Scorpion
size: Tiny
type: Beast
alignment: Unaligned
ac: 11
hp: 1 (1d4 - 1)
hit_dice: 1d4 - 1
speed: 10 ft.
stats: [2, 11, 8, 1, 8, 2]
senses: Blindsight 10 ft.; Passive Perception 9
languages: None
cr: 0
actions:
  - name: "Sting"
    desc: "Melee Attack Roll: +2, reach 5 ft. Hit: 1 Piercing damage plus 3 (1d6) Poison damage."
```

#Monster
