---
Rarity: Uncommon
type: object
tags:
  - Item
  - item/uncommon
  - item/weapon
item_category: Weapon
item_base: "Heavy Crossbow"
weapon_category: "Martial Ranged"
damage_dice: "1d10"
damage_type: Piercing
weapon_properties: [Ammunition, Heavy, Loading, Two-Handed]
range_normal: 100
range_long: 400
weapon_mastery: Push
requires_attunement: false
attunement_note: ""
attack_bonus: 1
damage_bonus: 1
---


###### +1 Heavy Crossbow
_Weapon (heavy crossbow), uncommon_<span class="sub2">:FasWandMagicSparkles: Magic Item</span>
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>You have a +1 bonus to attack and damage rolls made with this magic weapon.
>
>**1d10+1 Piercing damage.** Range 100/400 ft. Properties: Heavy, Loading, Two-Handed.
>
>- **Ammunition.** You can use a weapon that has the Ammunition property to make a ranged attack only if you have ammunition to fire from it.
>- **Heavy.** Small creatures have Disadvantage on attack rolls with this weapon.
>- **Loading.** You can fire only one piece of ammunition from this weapon when you use an action, Bonus Action, or Reaction to fire it, regardless of the number of attacks you can normally make.
>- **Two-Handed.** You must use two hands to attack with this weapon.
>
>**_Push (Mastery)._** If you hit a creature with this weapon and deal damage to it, you can push the creature up to 10 feet straight away from yourself if it is Large or smaller.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
