---
Type: Humanoid
CR: 0
Size: Medium or Small
tags:
  - Monster
  - Humanoid
source: SRD 5.2.1
---

```statblock
name: Commoner
size: Medium or Small
type: Humanoid
alignment: Neutral
ac: 10
hp: 4 (1d8)
hit_dice: 1d8
speed: 30 ft.
stats: [10, 10, 10, 10, 10, 10]
gear: Club
senses: Passive Perception 10
languages: Common
cr: 0
traits:
  - name: "Training"
    desc: "The commoner has proficiency in one skill of the GM’s choice and has Advantage whenever it makes an ability check using that skill."
actions:
  - name: "Club"
    desc: "Melee Attack Roll: +2, reach 5 ft. Hit: 2 (1d4) Bludgeoning damage."
```

#Monster
