---
Type: Beast
CR: 2
Size: Large
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Saber-Toothed Tiger
size: Large
type: Beast
alignment: Unaligned
ac: 13
hp: 52 (7d10 + 14)
hit_dice: 7d10 + 14
speed: 40 ft.
stats: [18, 17, 15, 3, 12, 8]
saves:
  - Str: +6
  - Dex: +5
skillsaves:
  - Perception: +5
  - Stealth: +7
senses: Darkvision 60 ft.; Passive Perception 15
languages: None
cr: 2
traits:
  - name: "Running Leap"
    desc: "With a 10-foot running start, the tiger can Long Jump up to 25 feet."
actions:
  - name: "Multiattack"
    desc: "The tiger makes two Rend attacks."
  - name: "Rend"
    desc: "Melee Attack Roll: +6, reach 5 ft. Hit: 11 (2d6 + 4) Slashing damage."
bonusactions:
  - name: "Nimble Escape"
    desc: "The tiger takes the Disengage or Hide action."
```

#Monster
