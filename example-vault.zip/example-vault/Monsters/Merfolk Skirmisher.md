---
Type: Elemental
CR: 1/8
Size: Medium
tags:
  - Monster
  - Elemental
source: SRD 5.2.1
---

```statblock
name: Merfolk Skirmisher
size: Medium
type: Elemental
alignment: Neutral
ac: 11
hp: 11 (2d8 + 2)
hit_dice: 2d8 + 2
speed: 10 ft., Swim 40 ft.
stats: [10, 13, 12, 11, 14, 12]
senses: Passive Perception 12
languages: Common, Primordial (Aquan)
cr: 1/8
traits:
  - name: "Amphibious"
    desc: "The merfolk can breathe air and water."
actions:
  - name: "Ocean Spear"
    desc: "Melee or Ranged Attack Roll: +2, reach 5 ft. or range 20/60 ft. Hit: 3 (1d6) Piercing damage plus 2 (1d4) Cold damage. If the target is a creature, its Speed decreases by 10 feet until the end of its next turn. Hit or Miss: The spear magically returns to the merfolk’s hand immediately after a ranged attack."
```

#Monster
