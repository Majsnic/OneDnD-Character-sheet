---
tags:
  - Feat
source: SRD 5.2.1
---

# Magic Initiate

**Type:** Origin Feat
**Repeatable:** Yes

Pick a class — Cleric, Druid, or Wizard. You learn two cantrips of your choice from that class's spell list, plus one 1st-level spell from the same list. You can cast the chosen 1st-level spell once without expending a spell slot, regaining that use after a long rest, and you can also cast it normally using any spell slots you have. Your spellcasting ability for these spells is tied to the class you picked (Wisdom for Cleric or Druid, Intelligence for Wizard). This feat can be taken more than once, choosing a different class's list each time.

*Paraphrased mechanical summary, written from general knowledge of the SRD rules — treat it as a helpful draft, not a verbatim rules quote.*

#Feat
