---
Spell level: 1
School type: Conjuration
Casting Time: Action
Components:
  - Verbal
  - Somatic
Concentration: true
Duration: 1 hour
Range / Area: 120 feet
Attack / Save: None
Damage / Effect: Utility
Upscale: + 20 feet for each spell slot level above 1
category: 1st level
---
_Level 1 Conjuration_

- **Casting time:** Action
- **Range:** 120 feet
- **Components:** V, S
- **Duration:** 1 hour
- **Attack/Save**: None
- **Damage/Effect**: Utility

You create a 20-foot-radius Sphere of fog centered on a point within range. The Sphere is Heavily Obscured. It lasts for the duration or until a strong wind (such as one created by Gust of Wind) disperses it.

**_Using a Higher-Level Spell Slot._** The fog’s radius increases by 20 feet for each spell slot level above 1.

#Spell
