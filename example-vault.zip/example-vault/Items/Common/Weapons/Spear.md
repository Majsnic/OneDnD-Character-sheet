---
type: object
tags:
  - Item
  - item/common
  - item/weapon
item_category: Weapon
weapon_category: "Simple Melee"
damage_dice: "1d6"
damage_type: Piercing
weapon_properties: [Thrown, Versatile]
range_normal: 20
range_long: 60
versatile_dice: "1d8"
attack_bonus: 0
damage_bonus: 0
cost: "1 GP"
weight_lb: 3
---


###### Spear
_Simple Melee Weapon_
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>**1d6 Piercing damage.** Range 20/60 ft. Versatile (1d8). Cost 1 GP, weight 3 lb.
>
>- **Thrown.** You can throw this weapon to make a ranged attack, using the same ability modifier for the attack and damage rolls that you use for a melee attack with the weapon.
>- **Versatile.** This weapon can be used with one or two hands. A damage value in parentheses appears with the property - the weapon deals that damage when used with two hands to make a melee attack.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
