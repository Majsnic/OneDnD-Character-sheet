---
type: object
tags:
  - Item
  - item/common
  - item/weapon
item_category: Weapon
weapon_category: "Simple Melee"
damage_dice: "1d4"
damage_type: Piercing
weapon_properties: [Finesse, Light, Thrown]
range_normal: 20
range_long: 60
weapon_mastery: Nick
attack_bonus: 0
damage_bonus: 0
cost: "2 GP"
weight_lb: 1
---


###### Dagger
_Simple Melee Weapon_
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>**1d4 Piercing damage.** Range 20/60 ft. Properties: Finesse, Light. Cost 2 GP, weight 1 lb.
>
>- **Finesse.** You can use your Strength or Dexterity modifier for attack and damage rolls with this weapon.
>- **Light.** You can make an extra attack with a second Light weapon as a Bonus Action (Two-Weapon Fighting) without adding your ability modifier to the extra attack's damage unless it's negative.
>- **Thrown.** You can throw this weapon to make a ranged attack, using the same ability modifier for the attack and damage rolls that you use for a melee attack with the weapon.
>
>**_Nick (Mastery)._** You can make the extra attack granted by this weapon's Light property as part of the Attack action instead of as a Bonus Action, but only once per turn.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
