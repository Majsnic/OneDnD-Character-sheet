---
Type: Monstrosity
CR: 3
Size: Medium
tags:
  - Monster
  - Monstrosity
source: SRD 5.2.1
---

```statblock
name: Basilisk
size: Medium
type: Monstrosity
alignment: Unaligned
ac: 15
hp: 52 (8d8 + 16)
hit_dice: 8d8 + 16
speed: 20 ft.
stats: [16, 8, 15, 2, 8, 7]
senses: Darkvision 60 ft.; Passive Perception 9
languages: None
cr: 3
actions:
  - name: "Bite"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 10 (2d6 + 3) Piercing damage plus 7 (2d6) Poison damage."
bonusactions:
  - name: "Petrifying Gaze (Recharge 4–6)"
    desc: "Constitution Saving Throw: DC 12, each creature in a 30-foot Cone. If the basilisk sees its reflection in the Cone, the basilisk must make this save. First Failure: The target has the Restrained condition and repeats the save at the end of its next turn if it is still Restrained, ending the effect on itself on a success. Second Failure: The target has the Petrified condition instead of the Restrained condition."
```

#Monster
