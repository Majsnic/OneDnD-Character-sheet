---
Spell level: 4
School type: Illusion
Casting Time: Action
Components:
  - Verbal
  - Somatic
Concentration: true
Duration: 1 minute
Range / Area: Touch
Attack / Save: None
Damage / Effect: Invisible
Upscale: 
category: 4th level
---
_Level 4 Illusion_

- **Casting time:** Action
- **Range:** Touch
- **Components:** V, S
- **Duration:** 1 minute
- **Attack/Save**: None
- **Damage/Effect**: Invisible

A creature you touch has the Invisible condition until the spell ends.

#Spell
