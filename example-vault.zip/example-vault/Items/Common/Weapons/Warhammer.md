---
type: object
tags:
  - Item
  - item/common
  - item/weapon
item_category: Weapon
weapon_category: "Martial Melee"
damage_dice: "1d8"
damage_type: Bludgeoning
weapon_properties: [Versatile]
versatile_dice: "1d10"
weapon_mastery: Push
attack_bonus: 0
damage_bonus: 0
cost: "15 GP"
weight_lb: 2
---


###### Warhammer
_Martial Melee Weapon_
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>**1d8 Bludgeoning damage.** Versatile (1d10). Cost 15 GP, weight 2 lb.
>
>- **Versatile.** This weapon can be used with one or two hands. A damage value in parentheses appears with the property - the weapon deals that damage when used with two hands to make a melee attack.
>
>**_Push (Mastery)._** If you hit a creature with this weapon, you can push that creature up to 10 feet straight away from yourself if it's Large or smaller.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
