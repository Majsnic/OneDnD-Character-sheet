---
type: object
tags:
  - Item
  - item/common
  - item/weapon
item_category: Weapon
weapon_category: "Martial Melee"
damage_dice: "1d8"
damage_type: Piercing
weapon_properties: [Finesse]
weapon_mastery: Vex
attack_bonus: 0
damage_bonus: 0
cost: "25 GP"
weight_lb: 2
---


###### Rapier
_Martial Melee Weapon_
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>**1d8 Piercing damage.** Properties: Finesse. Cost 25 GP, weight 2 lb.
>
>- **Finesse.** You can use your Strength or Dexterity modifier for attack and damage rolls with this weapon.
>
>**_Vex (Mastery)._** If you hit a creature with this weapon and deal damage, you have Advantage on your next attack roll against that same creature before the end of your next turn.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
