---
tags:
  - Condition
source: SRD 5.2.1
---

# Frightened

You have disadvantage on ability checks and attack rolls while the source of your fear is within line of sight. You can't willingly move closer to that source.

*Paraphrased mechanical summary, written from general knowledge of the SRD rules — treat it as a helpful draft, not a verbatim rules quote.*

#Condition
