---
type: object
tags:
  - Item
  - item/common
  - item/armor
item_category: Armor
armor_category: Heavy
armor_class_base: 16
armor_class_dex_cap: 0  # no Dex bonus applies
strength_requirement: 13
stealth_disadvantage: true
cost: "75 GP"
weight_lb: 55
---


###### Chain Mail
_Heavy Armor_
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>**AC 16.** No Dex modifier applies. Cost 75 GP, weight 55 lb.
>
>- **Strength 13 required.** If you don't meet this requirement, your Speed is reduced by 10 feet.
>- **Stealth Disadvantage.** You have Disadvantage on Dexterity (Stealth) checks while wearing this armor.
>
>Donning or doffing this armor takes 10 minutes (5 with help).
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
