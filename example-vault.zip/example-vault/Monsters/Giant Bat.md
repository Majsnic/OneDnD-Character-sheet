---
Type: Beast
CR: 1/4
Size: Large
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Giant Bat
size: Large
type: Beast
alignment: Unaligned
ac: 13
hp: 22 (4d10)
hit_dice: 4d10
speed: 10 ft., Fly 60 ft.
stats: [15, 16, 11, 2, 12, 6]
senses: Blindsight 120 ft.; Passive Perception 11
languages: None
cr: 1/4
actions:
  - name: "Bite"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 6 (1d6 + 3) Piercing damage."
```

#Monster
