---
Type: Fey
CR: 1/2
Size: Medium
tags:
  - Monster
  - Fey
source: SRD 5.2.1
---

```statblock
name: Satyr
size: Medium
type: Fey
alignment: Chaotic Neutral
ac: 13
hp: 31 (7d8)
hit_dice: 7d8
speed: 40 ft.
stats: [12, 16, 11, 12, 10, 14]
skillsaves:
  - Perception: +2
  - Performance: +6
  - Stealth: +5
senses: Passive Perception 12
languages: Common, Elvish, Sylvan
cr: 1/2
traits:
  - name: "Magic Resistance"
    desc: "The satyr has Advantage on saving throws against spells and other magical effects."
actions:
  - name: "Hooves"
    desc: "Melee Attack Roll: +5, reach 5 ft. Hit: 5 (1d4 + 3) Bludgeoning damage. If the target is a Medium or smaller creature, the satyr pushes the target up to 10 feet straight away from itself."
  - name: "Mockery"
    desc: "Wisdom Saving Throw: DC 12, one creature the satyr can see within 90 feet. Failure: 5 (1d6 + 2) Psychic damage."
```

#Monster
