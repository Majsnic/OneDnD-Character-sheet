---
Type: Monstrosity
CR: 1
Size: Medium
tags:
  - Monster
  - Monstrosity
source: SRD 5.2.1
---

```statblock
name: Harpy
size: Medium
type: Monstrosity
alignment: Chaotic Evil
ac: 11
hp: 38 (7d8 + 7)
hit_dice: 7d8 + 7
speed: 20 ft., Fly 40 ft.
stats: [12, 13, 12, 7, 10, 13]
senses: Passive Perception 10
languages: Common
cr: 1
actions:
  - name: "Claw"
    desc: "Melee Attack Roll: +3, reach 5 ft. Hit: 6 (2d4 + 1) Slashing damage."
  - name: "Luring Song"
    desc: "The harpy sings a magical melody, which lasts until the harpy’s Concentration ends on it. Wisdom Saving Throw: DC 11, each Humanoid and Giant in a 300-foot Emanation originating from the harpy when the song starts. Failure: The target has the Charmed condition until the song ends and repeats the save at the end of each of its turns. While Charmed, the target has the Incapacitated condition and ignores the Luring Song of other harpies. If the target is more than 5 feet from the harpy, the target moves on its turn toward the harpy by the most direct route, trying to get within 5 feet of the harpy. It doesn’t avoid Opportunity Attacks; however, before moving into damaging terrain (such as lava or a pit) and whenever it takes damage from a source other than the harpy, the target repeats the save. Success: The target is immune to this harpy’s Luring Song for 24 hours."
```

#Monster
