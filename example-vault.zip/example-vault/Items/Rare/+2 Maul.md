---
Rarity: Rare
type: object
tags:
  - Item
  - item/rare
  - item/weapon
item_category: Weapon
item_base: "Maul"
weapon_category: "Martial Melee"
damage_dice: "2d6"
damage_type: Bludgeoning
weapon_properties: [Heavy, Two-Handed]
weapon_mastery: Topple
requires_attunement: false
attunement_note: ""
attack_bonus: 2
damage_bonus: 2
---


###### +2 Maul
_Weapon (maul), rare_<span class="sub2">:FasWandMagicSparkles: Magic Item</span>
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>You have a +2 bonus to attack and damage rolls made with this magic weapon.
>
>**2d6+2 Bludgeoning damage.** Properties: Heavy, Two-Handed.
>
>- **Heavy.** Small creatures have Disadvantage on attack rolls with this weapon.
>- **Two-Handed.** You must use two hands to attack with this weapon.
>
>**_Topple (Mastery)._** If you hit a creature with this weapon and deal damage to it, you can force the creature to make a Constitution saving throw (DC = 8 + your proficiency bonus + the ability modifier used for the attack roll). On a failed save, the creature has the Prone condition.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
