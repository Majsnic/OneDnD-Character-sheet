---
Type: Beast
CR: 7
Size: Huge
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Giant Ape
size: Huge
type: Beast
alignment: Unaligned
ac: 12
hp: 168 (16d12 + 64)
hit_dice: 16d12 + 64
speed: 40 ft., Climb 40 ft.
stats: [23, 14, 18, 5, 12, 7]
skillsaves:
  - Athletics: +9
  - Perception: +4
  - Survival: +4
senses: Passive Perception 14
languages: None
cr: 7
actions:
  - name: "Multiattack"
    desc: "The ape makes two Fist attacks."
  - name: "Fist"
    desc: "Melee Attack Roll: +9, reach 10 ft. Hit: 22 (3d10 + 6) Bludgeoning damage."
  - name: "Boulder Toss (Recharge 6)"
    desc: "The ape hurls a boulder at a point it can see within 90 feet. Dexterity Saving Throw: DC 17, each creature in a 5-foot-radius Sphere centered on that point. Failure: 24 (7d6) Bludgeoning damage. If the target is a Large or smaller creature, it has the Prone condition. Success: Half damage only."
bonusactions:
  - name: "Leap"
    desc: "The ape jumps up to 30 feet by spending 10 feet of movement."
```

#Monster
