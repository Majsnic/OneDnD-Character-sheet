---
Type: Fiend
CR: 8
Size: Large
tags:
  - Monster
  - Fiend
source: SRD 5.2.1
---

```statblock
name: Hezrou
size: Large
type: Fiend (Demon)
alignment: Chaotic Evil
ac: 18
hp: 157 (15d10 + 75)
hit_dice: 15d10 + 75
speed: 30 ft.
stats: [19, 17, 20, 5, 12, 13]
saves:
  - Str: +7
  - Con: +8
  - Wis: +4
damage_resistances: Cold, Fire, Lightning
damage_immunities: Poison
condition_immunities: Poisoned
senses: Darkvision 120 ft.; Passive Perception 11
languages: Abyssal; telepathy 120 ft.
cr: 8
traits:
  - name: "Demonic Restoration"
    desc: "If the hezrou dies outside the Abyss, its body dissolves into ichor, and it gains a new body instantly, reviving with all its Hit Points somewhere in the Abyss."
  - name: "Magic Resistance"
    desc: "The hezrou has Advantage on saving throws against spells and other magical effects."
  - name: "Stench"
    desc: "Constitution Saving Throw: DC 16, any creature that starts its turn in a 10-foot Emanation originating from the hezrou. Failure: The target has the Poisoned condition until the start of its next turn."
actions:
  - name: "Multiattack"
    desc: "The hezrou makes three Rend attacks."
  - name: "Rend"
    desc: "Melee Attack Roll: +7, reach 5 ft. Hit: 6 (1d4 + 4) Slashing damage plus 9 (2d8) Poison damage."
bonusactions:
  - name: "Leap"
    desc: "The hezrou jumps up to 30 feet by spending 10 feet of movement."
```

#Monster
