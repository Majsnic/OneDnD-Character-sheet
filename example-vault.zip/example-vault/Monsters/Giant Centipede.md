---
Type: Beast
CR: 1/4
Size: Small
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Giant Centipede
size: Small
type: Beast
alignment: Unaligned
ac: 14
hp: 9 (2d6 + 2)
hit_dice: 2d6 + 2
speed: 30 ft., Climb 30 ft.
stats: [5, 14, 12, 1, 7, 3]
senses: Blindsight 30 ft.; Passive Perception 8
languages: None
cr: 1/4
actions:
  - name: "Bite"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 4 (1d4 + 2) Piercing damage, and the target has the Poisoned condition until the start of the centipede’s next turn."
```

#Monster
