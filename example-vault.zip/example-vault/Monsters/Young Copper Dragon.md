---
Type: Dragon
CR: 7
Size: Large
tags:
  - Monster
  - Dragon
source: SRD 5.2.1
---

```statblock
name: Young Copper Dragon
size: Large
type: Dragon (Metallic)
alignment: Chaotic Good
ac: 17
hp: 119 (14d10 + 42)
hit_dice: 14d10 + 42
speed: 40 ft., Climb 40 ft., Fly 80 ft.
stats: [19, 12, 17, 16, 13, 15]
saves:
  - Dex: +4
  - Wis: +4
skillsaves:
  - Deception: +5
  - Perception: +7
  - Stealth: +4
damage_immunities: Acid
senses: Blindsight 30 ft., Darkvision 120 ft.; Passive Perception 17
languages: Common, Draconic
cr: 7
actions:
  - name: "Multiattack"
    desc: "The dragon makes three Rend attacks. It can replace one attack with a use of Slowing Breath."
  - name: "Rend"
    desc: "Melee Attack Roll: +7, reach 10 ft. Hit: 15 (2d10 + 4) Slashing damage."
  - name: "Acid Breath (Recharge 5–6)"
    desc: "Dexterity Saving Throw: DC 14, each creature in a 40-foot-long, 5-footwide Line. Failure: 40 (9d8) Acid damage. Success: Half damage."
  - name: "Slowing Breath"
    desc: "Constitution Saving Throw: DC 14, each creature in a 30-foot Cone. Failure: The target can’t take Reactions; its Speed is halved; and it can take either an action or a Bonus Action on its turn, not both. This effect lasts until the end of its next turn."
```

#Monster
