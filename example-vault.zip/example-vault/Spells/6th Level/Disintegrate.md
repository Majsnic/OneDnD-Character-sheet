---
Spell level: 6
School type: Transmutation
Casting Time: Action
Components:
  - Verbal
  - Somatic
  - Material
Concentration: false
Duration: Instantaneous
Range / Area: 60 feet
Attack / Save: DEX Save
Damage / Effect: 10d6+40 Force
Upscale: + 3d6
category: 6th level
---
_Level 6 Transmutation_

- **Casting time:** Action
- **Range:** 60 feet
- **Components:** V, S, M
- **Duration:** Instantaneous
- **Attack/Save**: DEX Save
- **Damage/Effect**: Force

You launch a green ray at a target you can see within range. The target can be a creature, a nonmagical object, or a creation of magical force, such as the wall created by Wall of Force. A creature targeted by this spell makes a Dexterity saving throw. On a failed save, the target takes 10d6 + 40 Force damage. If this damage reduces it to 0 Hit Points, it and everything nonmagical it is wearing and carrying are disintegrated into gray dust. The target can be revived only by a True Resurrection or a Wish spell. This spell automatically disintegrates a Large or smaller nonmagical object or a creation of magical force. If such a target is Huge or larger, this spell disintegrates a 10-foot-Cube portion of it.

**_Using a Higher-Level Spell Slot._** The damage increases by 3d6 for each spell slot level above 6.

#Spell
