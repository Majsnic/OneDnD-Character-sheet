---
tags:
  - Condition
source: SRD 5.2.1
---

# Prone

Your only movement option is to crawl, unless you stand up and end the condition. You have disadvantage on attack rolls. An attack roll against you has advantage if the attacker is within 5 feet of you, otherwise disadvantage.

*Paraphrased mechanical summary, written from general knowledge of the SRD rules — treat it as a helpful draft, not a verbatim rules quote.*

#Condition
