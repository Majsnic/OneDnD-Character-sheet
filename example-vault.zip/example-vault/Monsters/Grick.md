---
Type: Aberration
CR: 2
Size: Medium
tags:
  - Monster
  - Aberration
source: SRD 5.2.1
---

```statblock
name: Grick
size: Medium
type: Aberration
alignment: Unaligned
ac: 14
hp: 54 (12d8)
hit_dice: 12d8
speed: 30 ft., Climb 30 ft.
stats: [14, 14, 11, 3, 14, 5]
skillsaves:
  - Stealth: +4
senses: Darkvision 60 ft.; Passive Perception 12
languages: None
cr: 2
actions:
  - name: "Multiattack"
    desc: "The grick makes one Beak attack and one Tentacles attack."
  - name: "Beak"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 9 (2d6 + 2) Piercing damage."
  - name: "Tentacles"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 7 (1d10 + 2) Slashing damage. If the target is a Medium or smaller creature, it has the Grappled condition (escape DC 12) from all four tentacles."
```

#Monster
