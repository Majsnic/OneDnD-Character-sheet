---
Type: Beast
CR: 1/8
Size: Small
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Blood Hawk
size: Small
type: Beast
alignment: Unaligned
ac: 12
hp: 7 (2d6)
hit_dice: 2d6
speed: 10 ft., Fly 60 ft.
stats: [6, 14, 10, 3, 14, 5]
skillsaves:
  - Perception: +6
senses: Passive Perception 16
languages: None
cr: 1/8
traits:
  - name: "Pack Tactics"
    desc: "The hawk has Advantage on an attack roll against a creature if at least one of the hawk’s allies is within 5 feet of the creature and the ally doesn’t have the Incapacitated condition."
actions:
  - name: "Beak"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 4 (1d4 + 2) Piercing damage, or 6 (1d8 + 2) Piercing damage if the target is Bloodied."
```

#Monster
