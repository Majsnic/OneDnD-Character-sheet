---
Spell level: 3
School type: Illusion
Casting Time: Action
Components:
  - Verbal
  - Somatic
  - Material
Concentration: true
Duration: 1 minute
Range / Area: Self
Attack / Save: WIS Save
Damage / Effect: Frightened
Upscale: 
category: 3rd level
---
_Level 3 Illusion_

- **Casting time:** Action
- **Range:** Self
- **Components:** V, S, M
- **Duration:** 1 minute
- **Attack/Save**: WIS Save
- **Damage/Effect**: Frightened

Each creature in a 30-foot Cone must succeed on a Wisdom saving throw or drop whatever it is holding and have the Frightened condition for the duration. A Frightened creature takes the Dash action and moves away from you by the safest route on each of its turns unless there is nowhere to move. If the creature ends its turn in a space where it doesn’t have line of sight to you, the creature makes a Wisdom saving throw. On a successful save, the spell ends on that creature.

#Spell
