---
Type: Beast
CR: 1/4
Size: Medium
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Giant Badger
size: Medium
type: Beast
alignment: Unaligned
ac: 13
hp: 15 (2d8 + 6)
hit_dice: 2d8 + 6
speed: 30 ft., Burrow 10 ft.
stats: [13, 10, 17, 2, 12, 5]
skillsaves:
  - Perception: +3
damage_resistances: Poison
senses: Darkvision 60 ft.; Passive Perception 13
languages: None
cr: 1/4
actions:
  - name: "Bite"
    desc: "Melee Attack Roll: +3, reach 5 ft. Hit: 6 (2d4 + 1) Piercing damage."
```

#Monster
