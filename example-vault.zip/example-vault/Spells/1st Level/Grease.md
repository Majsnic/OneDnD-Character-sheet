---
Spell level: 1
School type: Conjuration
Casting Time: Action
Components:
  - Verbal
  - Somatic
  - Material
Concentration: false
Duration: 1 minute
Range / Area: 60 feet
Attack / Save: DEX Save
Damage / Effect: Prone
Upscale: 
category: 1st level
---
_Level 1 Conjuration_

- **Casting time:** Action
- **Range:** 60 feet
- **Components:** V, S, M
- **Duration:** 1 minute
- **Attack/Save**: DEX Save
- **Damage/Effect**: Prone

Nonflammable grease covers the ground in a 10- foot square centered on a point within range and turns it into Difficult Terrain for the duration. When the grease appears, each creature standing in its area must succeed on a Dexterity saving throw or have the Prone condition. A creature that enters the area or ends its turn there must also succeed on that save or fall Prone.

#Spell
