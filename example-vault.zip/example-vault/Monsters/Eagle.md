---
Type: Beast
CR: 0
Size: Small
tags:
  - Monster
  - Beast
source: SRD 5.2.1
---

```statblock
name: Eagle
size: Small
type: Beast
alignment: Unaligned
ac: 12
hp: 4 (1d6 + 1)
hit_dice: 1d6 + 1
speed: 10 ft., Fly 60 ft.
stats: [6, 15, 12, 2, 14, 7]
skillsaves:
  - Perception: +6
senses: Passive Perception 16
languages: None
cr: 0
actions:
  - name: "Talons"
    desc: "Melee Attack Roll: +4, reach 5 feet. Hit: 4 (1d4 + 2) Slashing damage."
```

#Monster
