---
Spell level: 1
School type: Divination
Casting Time: Action or Ritual
Components:
  - Verbal
  - Somatic
Concentration: false
Duration: 10 minutes
Range / Area: Self
Attack / Save: None
Damage / Effect: Utility
Upscale: 
category: 1st level
---
_Level 1 Divination_

- **Casting time:** Action or Ritual
- **Range:** Self
- **Components:** V, S
- **Duration:** 10 minutes
- **Attack/Save**: None
- **Damage/Effect**: Utility

For the duration, you can comprehend and verbally communicate with Beasts, and you can use any of the Influence action’s skill options with them. Most Beasts have little to say about topics that don’t pertain to survival or companionship, but at minimum, a Beast can give you information about nearby locations and monsters, including whatever it has perceived within the past day.

#Spell
