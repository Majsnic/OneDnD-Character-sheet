---
Rarity: Rare
type: object
tags:
  - Item
  - item/rare
item_category: Armor
item_base: "Any armor"
requires_attunement: false
attunement_note: ""
armor_category: Medium
armor_class_base: 12
armor_class_bonus: 2
---


###### +2 Armor
_Armor (light, medium, or heavy), rare_<span class="sub2">:FasWandMagicSparkles: Magic Item</span>
___

> [!quote|no-t]
>![[object.png|right wm-sm]]
>While wearing this armor, you gain a +2 bonus to Armor Class.
>
>The 2024 rules' generic pattern for magic armor: pick the mundane armor type it's made from (light, medium, or heavy - AC formula, Dex cap, Strength requirement, and Stealth disadvantage all come from that base armor), and it gains a flat +2 AC bonus on top.
<span class="clearfix"></span>

> [!column|flex 3]
> > [!hint]- PEOPLE
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Name
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/NPC")
> >         - file.hasLink(this.file)
> > ```
>
>> [!note]- HISTORY
> > ```base
> > properties:
> >   file.name:
> >     displayName: Name
> > views:
> >   - type: table
> >     name: Session Notes
> >     filters:
> >       and:
> >         - file.inFolder("Dungeons & Dragons/01. Campaign/1. Master Plan/Diary")
> >         - file.hasLink(this.file)
> > ```
