---
Type: Monstrosity
CR: 1/2
Size: Small
tags:
  - Monster
  - Monstrosity
source: SRD 5.2.1
---

```statblock
name: Cockatrice
size: Small
type: Monstrosity
alignment: Unaligned
ac: 11
hp: 22 (5d6 + 5)
hit_dice: 5d6 + 5
speed: 20 ft., Fly 40 ft.
stats: [6, 12, 12, 2, 13, 5]
condition_immunities: Petrified
senses: Darkvision 60 ft.; Passive Perception 11
languages: None
cr: 1/2
actions:
  - name: "Petrifying Bite"
    desc: "Melee Attack Roll: +3, reach 5 ft. Hit: 3 (1d4 + 1) Piercing damage. If the target is a creature, it is subjected to the following effect. Constitution Saving Throw: DC 11. First Failure: The target has the Restrained condition. The target repeats the save at the end of its next turn if it is still Restrained, ending the effect on itself on a success. Second Failure: The target has the Petrified condition, instead of the Restrained condition, for 24 hours."
```

#Monster
