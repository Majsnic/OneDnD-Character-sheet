---
Type: Monstrosity
CR: 1/8
Size: Tiny
tags:
  - Monster
  - Monstrosity
source: SRD 5.2.1
---

```statblock
name: Flying Snake
size: Tiny
type: Monstrosity
alignment: Unaligned
ac: 14
hp: 5 (2d4)
hit_dice: 2d4
speed: 30 ft., Fly 60 ft., Swim 30 ft.
stats: [4, 15, 11, 2, 12, 5]
senses: Blindsight 10 ft.; Passive Perception 11
languages: None
cr: 1/8
traits:
  - name: "Flyby"
    desc: "The snake doesn’t provoke an Opportunity Attack when it flies out of an enemy’s reach."
actions:
  - name: "Bite"
    desc: "Melee Attack Roll: +4, reach 5 ft. Hit: 1 Piercing damage plus 5 (2d4) Poison damage."
```

#Monster
