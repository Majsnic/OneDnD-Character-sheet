---
Type: Dragon
CR: 9
Size: Large
tags:
  - Monster
  - Dragon
source: SRD 5.2.1
---

```statblock
name: Young Blue Dragon
size: Large
type: Dragon (Chromatic)
alignment: Lawful Evil
ac: 18
hp: 152 (16d10 + 64)
hit_dice: 16d10 + 64
speed: 40 ft., Burrow 20 ft., Fly 80 ft.
stats: [21, 10, 19, 14, 13, 17]
saves:
  - Dex: +4
  - Wis: +5
skillsaves:
  - Perception: +9
  - Stealth: +4
damage_immunities: Lightning
senses: Blindsight 30 ft., Darkvision 120 ft.; Passive Perception 19
languages: Common, Draconic
cr: 9
actions:
  - name: "Multiattack"
    desc: "The dragon makes three Rend attacks."
  - name: "Rend"
    desc: "Melee Attack Roll: +9, reach 10 ft. Hit: 12 (2d6 + 5) Slashing damage plus 5 (1d10) Lightning damage."
  - name: "Lightning Breath (Recharge 5–6)"
    desc: "Dexterity Saving Throw: DC 16, each creature in a 60-foot-long, 5-footwide Line. Failure: 55 (10d10) Lightning damage. Success: Half damage."
```

#Monster
